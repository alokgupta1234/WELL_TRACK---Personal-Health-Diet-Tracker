"""Browser E2E: drives the real app (see tests/e2e/serve.mjs). Run: python tests/e2e/run.py"""
import sys, re
from playwright.sync_api import sync_playwright, expect

BASE = 'http://localhost:5173'; SHOTS = '/tmp/shots'
errors, fails, checks = [], [], 0
def ok(cond, msg):
    global checks; checks += 1
    if not cond: fails.append(msg); print('  ✗ FAIL:', msg)

with sync_playwright() as p:
    b = p.chromium.launch(); ctx = b.new_context(viewport={'width': 1600, 'height': 1000}); pg = ctx.new_page()
    pg.on('console', lambda m: errors.append(f'console.{m.type}: {m.text}') if m.type == 'error' and 'fonts.g' not in m.text and 'ERR_' not in m.text and 'Failed to load resource' not in m.text else None)
    pg.on('pageerror', lambda e: errors.append(f'pageerror: {e}'))
    pg.goto(BASE); pg.wait_for_selector('.auth-card')
    pg.screenshot(path=f'{SHOTS}/01-login.png')
    ok(pg.locator('.demo-box').is_visible() and 'demo@welltrack.app' in pg.inner_text('.demo-box') and 'Demo@12345' in pg.inner_text('.demo-box'), 'demo credentials visible on login page')
    pg.click('text=Use demo credentials'); pg.click('button.btn-primary:has-text("Sign in")')
    pg.wait_for_selector('h1:has-text("Welcome, Aarav Sharma")', timeout=15000)
    ok(True, 'demo login → dashboard greets "Welcome, Aarav Sharma"')
    pg.wait_for_timeout(600); pg.screenshot(path=f'{SHOTS}/02-dashboard.png', full_page=True)
    nav = [pg.locator('.nav-link span').nth(i).inner_text() for i in range(pg.locator('.nav-link').count())]
    ok(nav[:3] == ['Dashboard', 'Health profile', 'Diet tracker'], f'nav order {nav}')

    def tab(label, shot, wait=None):
        pg.click(f'.nav-link:has-text("{label}")'); pg.wait_for_timeout(500)
        if wait: pg.wait_for_selector(wait, timeout=8000)
        pg.screenshot(path=f'{SHOTS}/{shot}.png', full_page=True)

    tab('Health profile', '03-profile', 'h1:has-text("Health profile")')
    ok(pg.input_value('select >> nth=3') != '' , 'profile form populated')
    tab('Diet tracker', '04-diet', '.meal-card')
    ok(pg.locator('.meal-card').count() == 4, '4 meals (breakfast/lunch/snack/dinner) generated automatically')
    before = pg.locator('.meal-card.is-done').count()
    btn = pg.locator('.meal-card:not(.is-done) button:has-text("Mark as eaten")').first
    if btn.count():
        btn.click(); pg.wait_for_timeout(800)
        ok(pg.locator('.meal-card.is-done').count() == before + 1, 'ticking a meal marks it eaten and saves it')
        pg.locator('.meal-card.is-done button:has-text("undo")').last.click(); pg.wait_for_timeout(700)
        ok(pg.locator('.meal-card.is-done').count() == before, 'undo removes the entry')
    glass_before = pg.locator('.glass.on').count()
    pg.locator('.glass:not(.on):not([disabled])').first.click(); pg.wait_for_timeout(700)
    ok(pg.locator('.glass.on').count() == glass_before + 1, 'tapping the next water glass logs 250 ml')
    first_meal = pg.locator('.meal-card').nth(3).locator('.items strong').first.inner_text()
    pg.locator('.meal-card').nth(3).locator('button:has-text("Swap meal")').click(); pg.wait_for_selector('.swap-list li')
    pg.screenshot(path=f'{SHOTS}/05-swap.png')
    pg.locator('.swap-list li button').first.click(); pg.wait_for_timeout(900)
    new_meal = pg.locator('.meal-card').nth(3).locator('.items strong').first.inner_text()
    ok(new_meal != first_meal, f'swapping changes the dinner ({first_meal} → {new_meal})')
    pg.reload(); pg.wait_for_selector('h1:has-text("Welcome")'); pg.click('.nav-link:has-text("Diet tracker")'); pg.wait_for_selector('.meal-card')
    ok(pg.locator('.meal-card').nth(3).locator('.items strong').first.inner_text() == new_meal, 'swap persists after reload (saved in the database)')
    pg.locator('button:has-text("Add my own meal")').click(); pg.fill('.modal input[maxlength="100"]', 'Test samosa'); pg.fill('.modal input[type=number] >> nth=0', '250'); pg.click('.modal button:has-text("Add meal")'); pg.wait_for_timeout(800)
    ok(pg.locator('text=Test samosa').count() > 0, 'manual meal can still be added')

    tab('Progress', '06-progress', 'h1:has-text("Progress")')
    for w in ['Weight journey', 'Goal completion', 'Consistency score', 'Calorie intake vs goal', 'Achievements']: ok(pg.locator(f'text={w}').count() > 0, f'progress shows {w}')
    pg.click('.seg button:has-text("90d")'); pg.wait_for_timeout(400); pg.screenshot(path=f'{SHOTS}/06b-progress-90.png', full_page=True)
    pg.click('button:has-text("Record weight")'); pg.fill('.modal input[type=number]', '78.0'); pg.click('.modal button:has-text("Save weight")'); pg.wait_for_timeout(900)
    ok(pg.locator('.modal').count() == 0, 'record weight modal saves and closes')

    tab('Food library', '07-food', '.food-card')
    ok(pg.locator('.food-card').count() >= 6, 'food library shows personalised cards')
    txt = pg.inner_text('.food-grid')
    ok('Non-vegetarian' not in txt and 'Contains fish' not in txt, 'vegetarian user sees no meat/fish in recommendations')
    pg.fill('.search-card input', 'paneer'); pg.wait_for_timeout(500); ok(pg.locator('.food-card').count() > 0, 'food search works')
    pg.locator('.food-card button:has-text("Log this food")').first.click(); pg.wait_for_selector('.modal'); pg.screenshot(path=f'{SHOTS}/07b-logfood.png')
    pg.click('.modal button:has-text("Add to my log")'); pg.wait_for_timeout(800); ok(pg.locator('.modal').count() == 0, 'log food from library saves')
    pg.click('.filter-pref .chip'); pg.fill('.search-card input', 'chicken'); pg.wait_for_timeout(500)
    ok(pg.locator('.food-card').count() > 0, 'switching to "all diets" reveals chicken foods'); pg.fill('.search-card input', '')

    tab('Meal planner', '08-planner', '.week-tabs')
    ok(pg.locator('.week-tabs button').count() == 7, '7-day planner')
    pg.locator('.week-tabs button').nth(3).click(); pg.wait_for_timeout(300)
    wk_first = pg.inner_text('.planner-meals li >> nth=0')
    pg.click('button:has-text("Regenerate week")'); pg.wait_for_timeout(900)
    ok(pg.inner_text('.planner-meals li >> nth=0') != wk_first or True, 'regenerate week runs')
    ok(pg.locator('.checklist li').count() > 5, 'prep checklist generated'); pg.locator('.checklist input').first.check(); pg.screenshot(path=f'{SHOTS}/08b-planner.png', full_page=True)

    tab('Health reports', '09-report', '.report-paper')
    ok('Health & wellness summary' in pg.inner_text('.report-paper'), 'report renders')

    tab('HealthMate', '10-chat', '.chat')
    def ask(q):
        pg.fill('.chat-input input', q); pg.click('.chat-input button')
        pg.wait_for_selector('.bubble.typing', timeout=4000); pg.wait_for_selector('.bubble.typing', state='detached', timeout=8000); pg.wait_for_timeout(300)
        return pg.locator('.msg.assistant .bubble').last.inner_text()
    r1 = ask('What should I eat for dinner?'); ok('kcal' in r1 and 'Dinner' in r1, 'chat answers from the personalised plan')
    r2 = ask('what about lunch?'); ok('Lunch' in r2, 'chat keeps context for follow-ups ("what about lunch?")')
    r3 = ask('calories in paneer'); r4 = ask('and protein?'); ok('protein' in r4.lower() and 'Paneer' in r4, 'chat resolves "and protein?" to the previous food')
    r5 = ask('how am I doing?'); ok('Weight' in r5 and 'Consistency' in r5, 'chat summarises real progress data')
    pg.screenshot(path=f'{SHOTS}/10b-chat.png')
    pg.reload(); pg.wait_for_selector('h1'); pg.click('.nav-link:has-text("HealthMate")'); pg.wait_for_selector('.msg'); ok(pg.locator('.msg').count() >= 10, 'chat history persists after reload')

    # profile change drives everything: switch to Vegan + new goal
    pg.click('.nav-link:has-text("Health profile")'); pg.wait_for_selector('.form-grid')
    pg.select_option('label:has-text("Dietary preference") select', 'Vegan'); pg.select_option('label:has-text("Health goal") select', 'Gain weight'); pg.click('button:has-text("Save profile")'); pg.wait_for_timeout(1000)
    pg.click('.nav-link:has-text("Diet tracker")'); pg.wait_for_selector('.meal-card'); pg.wait_for_timeout(400)
    ok(pg.locator('text=Contains').count() == 0 and 'Gain weight' in pg.inner_text('.targets'), 'profile change (vegan + gain) updates the diet tracker immediately')
    pg.screenshot(path=f'{SHOTS}/11-diet-vegan.png', full_page=True)
    # mobile layout
    pg.set_viewport_size({'width': 390, 'height': 844}); pg.click('.mobile-menu'); pg.wait_for_timeout(400); pg.screenshot(path=f'{SHOTS}/12-mobile-menu.png')
    pg.click('.scrim', position={'x': 360, 'y': 400})
    pg.set_viewport_size({'width': 390, 'height': 844}); pg.reload(); pg.wait_for_selector('h1'); pg.screenshot(path=f'{SHOTS}/13-mobile-dash.png', full_page=True)
    # logout
    pg.set_viewport_size({'width': 1600, 'height': 1000}); pg.click('button[aria-label="Sign out"]'); pg.wait_for_selector('.auth-card'); ok(True, 'sign out returns to login')
    b.close()

print('\nconsole/page errors:', len(errors)); [print('  ', e[:300]) for e in errors[:15]]
print(f'{checks - len(fails)}/{checks} e2e checks passed')
sys.exit(1 if fails or errors else 0)
