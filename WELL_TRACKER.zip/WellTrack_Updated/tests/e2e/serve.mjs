// E2E harness: real Express API (in-memory DB stand-in) + real React frontend served with an on-the-fly JSX transform.
// Not used in production. Start:  node tests/e2e/serve.mjs   then open http://localhost:5173
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { installFakeMongoose } from '../../server/test/fakeMongoose.mjs';
import { jsxPlugin } from '../../scripts/jsx-loader.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const require = createRequire(root + '/package.json');
const babel = require('@babel/core');

installFakeMongoose();
Object.assign(process.env, { PORT: '5000', MONGO_URI: 'mongodb://x/x', CLIENT_ORIGIN: 'http://localhost:5173', JWT_SECRET: 'e2e-secret-e2e-secret-e2e-secret-e2e', SEED_DEMO: 'true' });
await import('../../server/src/server.js');

const TYPES = { '.js': 'text/javascript', '.mjs': 'text/javascript', '.jsx': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.html': 'text/html' };
const reactKeys = Object.keys(require('react')).filter(k => /^[A-Za-z_$][\w$]*$/.test(k));
const iconIndex = fs.readFileSync(root + '/node_modules/lucide-react/dist/esm/icons/index.js', 'utf8');
const iconFile = {};
const mainIndex = fs.readFileSync(root + '/node_modules/lucide-react/dist/esm/lucide-react.js', 'utf8');
for (const m of (iconIndex + '\n' + mainIndex.replaceAll("'./icons/", "'./")).matchAll(/export \{([^}]+)\} from '\.\/([^']+)'/g)) for (const n of m[1].matchAll(/default as (\w+)/g)) iconFile[n[1]] = m[2];
function lucideShim() {
  const names = new Set();
  const walk = d => fs.readdirSync(d, { withFileTypes: true }).forEach(f => { const p = path.join(d, f.name); if (f.isDirectory()) walk(p); else if (/\.(jsx|js)$/.test(f.name)) for (const m of fs.readFileSync(p, 'utf8').matchAll(/import \{([^}]+)\} from 'lucide-react'/g)) m[1].split(',').map(s => s.trim()).filter(Boolean).forEach(n => names.add(n.split(' as ')[0])); });
  walk(root + '/src');
  return [...names].map(n => `export { default as ${n} } from '/node_modules/lucide-react/dist/esm/icons/${iconFile[n] || 'missing-' + n}';`).join('\n');
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://x'); let p = decodeURIComponent(url.pathname);
  const send = (body, type, code = 200) => { res.writeHead(code, { 'Content-Type': type, 'Cache-Control': 'no-store' }); res.end(body); };
  try {
    if (p === '/' || p === '/index.html') {
      let html = fs.readFileSync(root + '/index.html', 'utf8');
      html = html.replace('</head>', `<script type="importmap">{"imports":{"react":"/__shim/react.js","react-dom/client":"/__shim/react-dom-client.js","lucide-react":"/__shim/lucide.js"}}</script>
<link rel="stylesheet" href="/src/styles.css"><script src="/node_modules/react/umd/react.development.js"></script><script src="/node_modules/react-dom/umd/react-dom.development.js"></script></head>`);
      return send(html, TYPES['.html']);
    }
    if (p === '/__shim/react.js') return send(`const R = window.React; export default R;\n${reactKeys.map(k => `export const ${k} = R.${k};`).join('\n')}`, TYPES['.js']);
    if (p === '/__shim/react-dom-client.js') return send('export const createRoot = window.ReactDOM.createRoot; export const hydrateRoot = window.ReactDOM.hydrateRoot;', TYPES['.js']);
    if (p === '/__shim/lucide.js') return send(lucideShim(), TYPES['.js']);
    let file = p.startsWith('/datasets/') ? path.join(root, 'public', p) : path.join(root, p);
    if (!file.startsWith(root) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) return send('not found', 'text/plain', 404);
    const ext = path.extname(file);
    if (ext === '.jsx') {
      let code = fs.readFileSync(file, 'utf8').replace(/^import ['"]\.\/styles\.css['"];?\s*$/m, '');
      if (!/import\s+React\b/.test(code)) code = "import React from 'react';\n" + code;
      const out = babel.transformSync(code, { filename: file, babelrc: false, configFile: false, sourceType: 'module', parserOpts: { plugins: ['jsx'] }, plugins: [jsxPlugin] });
      return send(out.code, TYPES['.js']);
    }
    return send(fs.readFileSync(file), TYPES[ext] || 'application/octet-stream');
  } catch (e) { console.error(e); send(String(e), 'text/plain', 500); }
});
server.listen(5173, () => console.log('E2E frontend on http://localhost:5173'));
