// Server-side render smoke test: renders the login screen and every page with realistic data and checks the output.
// Run:  node --import ./scripts/register-jsx.mjs tests/smoke.mjs
import fs from 'node:fs';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';

globalThis.window = { location: { search: '', pathname: '/' }, history: { replaceState() {} }, print() {} };
globalThis.localStorage = { _d: {}, getItem(k) { return this._d[k] ?? null; }, setItem(k, v) { this._d[k] = String(v); }, removeItem(k) { delete this._d[k]; } };
const root = new URL('..', import.meta.url).pathname;
const E = await import('../shared/engine.mjs');
const D = await import('../shared/demo.mjs');
const { default: App } = await import('../src/App.jsx');
const pages = {
  overview: (await import('../src/pages/Dashboard.jsx')).default, health: (await import('../src/pages/HealthProfile.jsx')).default,
  meals: (await import('../src/pages/DietTracker.jsx')).default, progress: (await import('../src/pages/Progress.jsx')).default,
  foods: (await import('../src/pages/FoodLibrary.jsx')).default, planner: (await import('../src/pages/MealPlanner.jsx')).default,
  reports: (await import('../src/pages/Reports.jsx')).default, healthmate: (await import('../src/pages/HealthMate.jsx')).default,
};
const M = await import('../src/Modals.jsx');
const { NAV } = await import('../src/meta.js');
const foods = JSON.parse(fs.readFileSync(root + 'public/datasets/foods-clean.json', 'utf8'));

let failures = 0, checks = 0;
const ok = (cond, msg) => { checks++; if (!cond) { failures++; console.error('  ✗ FAIL:', msg); } };

function makeApp({ user, profile, entries, foodsList = foods, planPrefs = { seed: 0, picks: {} }, dateKey }) {
  const today = E.todayKey();
  const targets = E.computeTargets(profile);
  const planOf = d => E.planForDate(profile, d, { seed: planPrefs.seed, picksByDate: planPrefs.picks });
  const planToday = planOf(today), planDay = planOf(dateKey || today);
  const summary = E.summarize(profile, entries, today, planToday);
  const noop = () => {};
  const actions = new Proxy({}, { get: () => noop });
  return { user, profile, targets, entries, summary, planToday, planDay, planPrefs, today, dateKey: dateKey || today, setDateKey: noop, foods: foodsList, foodQuery: '', setFoodQuery: noop, actions, go: noop, aiMode: false,
    chatCtx: { user, profile, summary, planDay: planToday, foods: foodsList, todayEntries: entries.filter(e => e.dateKey === today), dateKey: today, now: new Date() } };
}
const demo = D.buildDemoData(E.todayKey(), 14);
const demoEntries = demo.entries.map((e, i) => ({ ...e, _id: 'e' + i, createdAt: e.createdAt.toISOString() }));
const scenarios = {
  'demo user (90 days of data)': makeApp({ user: { id: 'u1', name: D.DEMO_NAME, email: D.DEMO_EMAIL }, profile: { ...demo.profile }, entries: demoEntries }),
  'brand-new user (empty profile, no data)': makeApp({ user: { id: 'u2', name: 'Priya', email: 'p@x.com' }, profile: { age: '', gender: 'Prefer not to say', heightCm: '', weightKg: '', targetWeightKg: '', activityLevel: 'Moderately active', dietaryPreference: 'No preference', goal: 'Maintain weight', calorieGoal: 2000, waterGoalMl: 2000, customTargets: false, dietExtras: [] }, entries: [] }),
  'vegan, gluten+nut free, gain, custom targets': makeApp({ user: { id: 'u3', name: 'Sam Lee', email: 's@x.com' }, profile: { age: 22, gender: 'Female', heightCm: 165, weightKg: 52, targetWeightKg: 56, activityLevel: 'Very active', dietaryPreference: 'Vegan', goal: 'Gain weight', calorieGoal: 2600, waterGoalMl: 2500, customTargets: true, dietExtras: ['no-gluten', 'no-nuts'] }, entries: demoEntries.slice(0, 40) }),
  'pescatarian + food data missing': makeApp({ user: { id: 'u4', name: 'Raj', email: 'r@x.com' }, profile: { ...demo.profile, dietaryPreference: 'Pescatarian', goal: 'Build healthier habits', dietExtras: [] }, entries: demoEntries, foodsList: [] }),
  'diet tracker on a past day': makeApp({ user: { id: 'u5', name: 'Aarav', email: 'a@x.com' }, profile: { ...demo.profile }, entries: demoEntries, dateKey: E.addDays(E.todayKey(), -3) }),
};

for (const [label, app] of Object.entries(scenarios)) {
  console.log('•', label);
  for (const [id, Page] of Object.entries(pages)) {
    let html = '';
    try { html = renderToStaticMarkup(React.createElement(Page, { app })); } catch (e) { ok(false, `${id} crashed: ${e.message}\n${e.stack.split('\n').slice(0, 4).join('\n')}`); continue; }
    ok(html.length > 800, `${id} rendered too little (${html.length})`);
    ok(!/NaN|undefined|\[object Object\]|Infinity/.test(html), `${id} contains NaN/undefined: ${(html.match(/.{40}(NaN|undefined|\[object Object\]|Infinity).{20}/) || [''])[0]}`);
  }
}
// ───── specific content checks
const A = scenarios['demo user (90 days of data)'];
const dash = renderToStaticMarkup(React.createElement(pages.overview, { app: A }));
ok(dash.includes('Welcome, Aarav Sharma'), 'dashboard greets the logged-in user by name');
ok(!dash.includes('Your Fitness at a Glance'), 'old heading removed');
const meals = renderToStaticMarkup(React.createElement(pages.meals, { app: A }));
for (const w of ['Breakfast', 'Lunch', 'Evening snack', 'Dinner', 'Water plan', 'Nutrition breakdown', 'Mark as eaten']) ok(meals.includes(w), `diet tracker shows "${w}"`);
const prog = renderToStaticMarkup(React.createElement(pages.progress, { app: A }));
for (const w of ['Weight journey', 'Goal completion', 'Consistency score', 'Macronutrient balance', 'Achievements', 'Insights for you']) ok(prog.includes(w), `progress shows "${w}"`);
const rep = renderToStaticMarkup(React.createElement(pages.reports, { app: A }));
for (const w of ['Health &amp; wellness summary', 'Current BMI', 'Calorie target', 'Recent tracking', 'not a diagnosis']) ok(rep.includes(w), `report keeps "${w}"`);
const chat = renderToStaticMarkup(React.createElement(pages.healthmate, { app: A }));
ok(chat.includes('HealthMate') && chat.includes('Send'), 'chat renders');
// navigation order: Dashboard → Health profile → Diet tracker
const order = NAV.map(n => n.label);
ok(order[0] === 'Dashboard' && order[1] === 'Health profile' && order[2] === 'Diet tracker', `nav order is ${order.slice(0, 4).join(' → ')}`);
// login page shows demo credentials
const login = renderToStaticMarkup(React.createElement(App));
ok(login.includes(D.DEMO_EMAIL) && login.includes(D.DEMO_PASSWORD), 'login page displays demo email + password');
// diet filters in the food library for different preferences
const veg = E.searchFoods(foods, { ...demo.profile, dietaryPreference: 'Vegetarian' }, { limit: 2000 });
ok(veg.items.length > 100 && veg.items.every(f => ['vegan', 'veg'].includes(f.diet)), 'vegetarian → only vegetarian/vegan foods');
const vegan = E.searchFoods(foods, { ...demo.profile, dietaryPreference: 'Vegan' }, { limit: 2000 });
ok(vegan.items.every(f => f.diet === 'vegan'), 'vegan → only vegan foods');
const nonveg = E.searchFoods(foods, { ...demo.profile, dietaryPreference: 'Non-vegetarian' }, { limit: 2000 });
ok(nonveg.items.some(f => f.diet === 'nonveg') && nonveg.items.some(f => f.diet === 'veg'), 'non-veg → both veg and non-veg foods');
const egg = E.searchFoods(foods, { ...demo.profile, dietaryPreference: 'Eggitarian' }, { limit: 2000 });
ok(egg.items.some(f => f.diet === 'egg') && !egg.items.some(f => ['nonveg', 'fish'].includes(f.diet)), 'eggitarian → egg ok, no meat/fish');
const gf = E.searchFoods(foods, { ...demo.profile, dietaryPreference: 'No preference', dietExtras: ['no-gluten'] }, { limit: 2000 });
ok(!gf.items.some(f => (f.contains || []).includes('gluten')), 'gluten-free removes gluten foods');
// planner: respects diet for a full week for several profiles
for (const pref of ['Vegan', 'Vegetarian', 'Eggitarian', 'Pescatarian', 'Non-vegetarian', 'No preference']) {
  const wk = E.buildWeekPlan({ ...demo.profile, dietaryPreference: pref, dietExtras: [] }, E.todayKey());
  const allowed = E.allowedDiets(pref);
  ok(wk.every(d => d.slots.every(s => s.items.length && s.items.every(i => allowed.includes(i.diet)))), `weekly plan fits "${pref}"`);
  ok(wk.every(d => Math.abs(d.deltaKcal) <= d.targets.calories * 0.15), `weekly plan calories within 15% of target for "${pref}" (${wk.map(d => d.deltaKcal).join(',')})`);
}
// modals render
const sw = renderToStaticMarkup(React.createElement(M.SwapModal, { onClose() {}, onPick() {}, ctx: { profile: demo.profile, targets: A.targets, planPrefs: A.planPrefs, dateKey: E.todayKey(), slot: 'dinner' } }));
ok(sw.includes('Use this'), 'swap modal lists alternatives');
const lf = renderToStaticMarkup(React.createElement(M.LogFoodModal, { onClose() {}, onSave() {}, food: foods.find(f => f.recommend), today: E.todayKey() }));
ok(lf.includes('Add to my log'), 'log-food modal renders');
for (const C of [M.ActivityModal, M.WeightModal, M.MealModal]) ok(renderToStaticMarkup(React.createElement(C, { onClose() {}, onSave() {}, dateKey: E.todayKey() })).length > 200, `${C.name} renders`);

console.log(`\n${checks - failures}/${checks} checks passed`);
process.exit(failures ? 1 : 0);
