// Test helper: lets plain Node import .jsx files (used by tests/smoke.mjs). Not used by the app itself – Vite does that.
import { register } from 'node:module';
register('./jsx-loader.mjs', import.meta.url);
