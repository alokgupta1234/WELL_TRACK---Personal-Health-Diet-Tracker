import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const babel = require('@babel/core');

export function jsxPlugin({ types: t }) {
  const nameOf = n => {
    if (t.isJSXIdentifier(n)) return /^[a-z]/.test(n.name) ? t.stringLiteral(n.name) : t.identifier(n.name);
    if (t.isJSXMemberExpression(n)) return t.memberExpression(memberObj(n.object), t.identifier(n.property.name));
    return t.stringLiteral(`${n.namespace.name}:${n.name.name}`);
  };
  const memberObj = n => (t.isJSXMemberExpression(n) ? t.memberExpression(memberObj(n.object), t.identifier(n.property.name)) : t.identifier(n.name));
  const key = k => (t.isValidIdentifier(k) ? t.identifier(k) : t.stringLiteral(k));
  const text = s => {
    const lines = s.split(/\r\n|\n|\r/); let out = '';
    lines.forEach((l, i) => { let x = l.replace(/\t/g, ' '); if (i !== 0) x = x.replace(/^[ ]+/, ''); if (i !== lines.length - 1) x = x.replace(/[ ]+$/, ''); if (x) { if (i !== lines.length - 1 && out) out += ' '; out += x; } });
    return out;
  };
  const build = (path, tag, attrs, children) => {
    const props = attrs.length ? t.objectExpression(attrs.map(a => {
      if (t.isJSXSpreadAttribute(a)) return t.spreadElement(a.argument);
      const k = t.isJSXNamespacedName(a.name) ? `${a.name.namespace.name}:${a.name.name.name}` : a.name.name;
      let v = a.value;
      if (v == null) v = t.booleanLiteral(true); else if (t.isJSXExpressionContainer(v)) v = v.expression; else if (t.isStringLiteral(v)) v = t.stringLiteral(v.value);
      return t.objectProperty(key(k), v);
    })) : t.nullLiteral();
    const kids = [];
    for (const c of children) {
      if (t.isJSXText(c)) { const s = text(c.value); if (s) kids.push(t.stringLiteral(s)); }
      else if (t.isJSXExpressionContainer(c)) { if (!t.isJSXEmptyExpression(c.expression)) kids.push(c.expression); }
      else if (t.isJSXSpreadChild(c)) kids.push(t.spreadElement(c.expression));
      else kids.push(c);
    }
    path.replaceWith(t.callExpression(t.memberExpression(t.identifier('React'), t.identifier('createElement')), [tag, props, ...kids]));
  };
  return { visitor: {
    JSXElement: { exit(path) { const o = path.node.openingElement; build(path, nameOf(o.name), o.attributes, path.node.children); } },
    JSXFragment: { exit(path) { build(path, t.memberExpression(t.identifier('React'), t.identifier('Fragment')), [], path.node.children); } },
  } };
}

export async function load(url, context, nextLoad) {
  if (!url.endsWith('.jsx')) return nextLoad(url, context);
  let code = await readFile(fileURLToPath(url), 'utf8');
  if (!/import\s+React\b/.test(code)) code = "import React from 'react';\n" + code;
  const out = babel.transformSync(code, { filename: fileURLToPath(url), babelrc: false, configFile: false, sourceType: 'module', parserOpts: { plugins: ['jsx'] }, plugins: [jsxPlugin], compact: false });
  return { format: 'module', source: out.code, shortCircuit: true };
}
