"""
Builds public/datasets/foods-clean.json from datasets/Food_Nutrition_dataset.csv
(+ the small hand-checked starter list in src/data/foods.json).

Run from the project root:   python scripts/build-food-dataset.py

What this fixes compared with the old importer
----------------------------------------------
* The Kaggle CSV stores nutrients PER SERVING (the serving mass differs per row),
  not per 100 g. We estimate the serving mass (water + macros) and derive per-100 g.
* Diet tags (vegan / vegetarian / egg / fish / non-veg) come from name rules that
  cover meat, fish, dairy, egg, honey, gelatin, ... instead of a tiny word list.
* Rows whose numbers are physically impossible are flagged "serving-only" and are
  never used for recommendations.
"""
import csv, json, re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "datasets" / "Food_Nutrition_dataset.csv"
STARTER = ROOT / "src" / "data" / "foods.json"
OUT = ROOT / "public" / "datasets" / "foods-clean.json"

def has(name, words):
    return any(re.search(r"\b" + w, name) for w in words)

MEAT = ["beef", "pork", "chicken", "turkey", "lamb", "mutton", "veal", "ham\\b", "bacon", "sausage", "salami",
        "pepperoni", "hot dog", "frankfurter", "bologna", "meatball", "steak", "ribs?\\b", "goat", "duck", "goose",
        "venison", "bison", "rabbit", "liver", "kidney", "tongue", "gizzard", "pate\\b", "jerky", "chorizo",
        "pastrami", "gyro", "kebab", "carne", "pollo", "brisket", "tripe", "oxtail", "ground beef", "burger",
        "lard\\b", "tallow", "gelatin", "bone broth", "meat\\b", "nuggets?", "tenders?", "wings?\\b", "drumstick",
        "poultry", "squab", "quail", "pheasant", "hamburger", "cheeseburger", "franks?\\b", "bratwurst", "prosciutto", "mortadella"]
FISH = ["fish", "salmon", "tuna", "cod\\b", "tilapia", "trout", "sardine", "anchov", "mackerel", "herring", "haddock",
        "halibut", "bass\\b", "catfish", "pollock", "snapper", "perch", "swordfish", "carp\\b", "eel\\b", "shrimp",
        "prawn", "crab", "lobster", "crawfish", "crayfish", "clam", "oyster", "mussel", "scallop", "squid",
        "octopus", "calamari", "roe\\b", "caviar", "shellfish", "sushi", "lox\\b", "sashimi", "abalone", "whelk"]
VEG_OVERRIDE = ["meatless", "vegetarian", "veggie", "vegan", "meat substitute", "imitation", "plant based",
                "plant-based", "soy", "tofu", "seitan", "tempeh", "nut butter", "peanut butter", "butternut",
                "butter bean", "butter lettuce", "buttercup", "peanut", "eggplant", "fish oil free"]
EGG = ["egg\\b", "eggs\\b", "omelet", "omelette", "frittata", "quiche", "mayonnaise", "mayo\\b", "meringue",
       "custard", "eggnog", "hollandaise", "aioli", "mousse"]
DAIRY = ["milk", "cheese", "yogurt", "yoghurt", "butter\\b", "cream\\b", "whey", "casein", "ghee", "paneer", "curd",
         "kefir", "pudding", "ice cream", "gelato", "latte", "cappuccino", "cheesecake", "lassi", "buttermilk",
         "milkshake", "cheddar", "mozzarella", "parmesan", "ricotta", "brie", "feta", "gouda", "swiss", "provolone",
         "cottage", "queso", "requeijao", "frappuccino", "mocha", "custard", "chantilly", "fondue", "alfredo"]
NOT_DAIRY = ["coconut milk", "coconut cream", "almond milk", "soy milk", "oat milk", "rice milk", "cashew milk",
             "hemp milk", "cream of tartar", "cream of wheat", "cream of rice", "cream soda", "peanut butter",
             "almond butter", "cocoa butter", "shea butter", "apple butter", "butter bean", "butternut",
             "nut butter", "sunflower butter", "tahini", "vegan", "dairy free", "non dairy", "nondairy",
             "milk chocolate free", "soymilk", "coconut yogurt", "rice cream", "sour cream substitute"]
BAKED_VEG = ["cake", "cookie", "brownie", "muffin", "pastry", "donut", "doughnut", "waffle", "pancake", "pie\\b",
             "croissant", "scone", "biscuit", "cupcake", "tart\\b", "danish", "eclair", "cobbler", "crumble",
             "banana bread", "zucchini bread", "cornbread", "pumpkin bread", "sweet bread", "pizza", "milk chocolate", "caramel", "fudge", "toffee", "candy", "bagel", "brioche"]
HONEY = ["honey"]
GLUTEN = ["wheat", "bread", "pasta", "noodle", "spaghetti", "macaroni", "flour", "cracker", "cake", "cookie",
          "biscuit", "couscous", "barley", "rye\\b", "bulgur", "semolina", "seitan", "pizza", "tortilla", "bun\\b",
          "bagel", "pita", "croissant", "muffin", "pancake", "waffle", "pretzel", "cereal", "cracker", "dumpling",
          "ramen", "lasagna", "ravioli", "pie\\b", "pastry", "donut", "doughnut", "toast", "sandwich", "burger",
          "breaded", "battered", "malt", "beer", "stuffing", "granola", "roti", "chapati", "naan", "paratha", "farro"]
NUTS = ["almond", "walnut", "cashew", "pecan", "pistachio", "hazelnut", "macadamia", "peanut", "brazil nut",
        "pine nut", "nut\\b", "nuts\\b", "nutella", "marzipan", "praline", "trail mix", "gianduja"]
SOY = ["soy", "tofu", "tempeh", "edamame", "miso", "natto"]
ALCOHOL = ["wine", "beer", "vodka", "whiskey", "whisky", "rum\\b", "gin\\b", "brandy", "liqueur", "liquor", "cocktail",
           "margarita", "martini", "tequila", "bourbon", "cider", "champagne", "sake\\b", "ale\\b", "lager",
           "stout", "bitters", "mojito", "sangria", "schnapps", "mead\\b"]

CAT_RULES = [
    ("Beverages", ["juice", "soda", "cola", "coffee", "tea\\b", "drink", "smoothie", "shake", "lemonade", "water\\b",
                   "energy", "milk\\b", "latte", "cappuccino", "kombucha", "cocoa", "punch", "squash", "nectar"] + ALCOHOL),
    ("Sweets & Desserts", ["cake", "cookie", "candy", "chocolate", "ice cream", "pie\\b", "pudding", "syrup", "jam\\b",
                            "jelly", "sugar", "brownie", "donut", "doughnut", "pastry", "dessert", "gelato", "sorbet",
                            "caramel", "fudge", "cupcake", "muffin", "waffle", "pancake", "tart\\b", "cheesecake",
                            "frosting", "marshmallow", "toffee", "lollipop", "gum\\b", "sweet\\b", "custard", "mousse"]),
    ("Fast food & Snacks", ["burger", "pizza", "fries", "nachos", "popcorn", "chips\\b", "chip\\b", "sandwich", "taco",
                             "burrito", "hot dog", "wrap\\b", "nuggets?", "pretzel", "cracker", "mcdonald", "wendys",
                             "burger king", "kfc", "subway", "taco bell", "pringles", "doritos", "lays", "fried",
                             "quesadilla", "wings?\\b", "tenders?", "onion rings", "empanada", "samosa", "pakora"]),
    ("Soups & Prepared meals", ["soup", "stew", "curry", "chowder", "casserole", "lasagna", "risotto", "pasta dish",
                                 "stir fry", "chili con", "gumbo", "stroganoff", "paella", "biryani", "pilaf", "dal\\b",
                                 "hash\\b", "dinner\\b", "lunch\\b", "meal\\b", "bowl\\b", "salad dressing"]),
    ("Fats & Oils", ["oil\\b", "margarine", "shortening", "mayonnaise", "dressing", "lard\\b", "tallow", "ghee"]),
    ("Nuts & Seeds", ["almond", "walnut", "cashew", "pecan", "pistachio", "hazelnut", "macadamia", "peanut", "seeds?\\b",
                       "nuts?\\b", "tahini", "chia", "flax", "sesame", "sunflower", "pumpkin seed", "pine nut", "trail mix"]),
    ("Dairy & Eggs", ["milk", "cheese", "yogurt", "yoghurt", "butter\\b", "cream\\b", "egg\\b", "eggs\\b", "omelet",
                       "paneer", "curd", "kefir", "whey", "ricotta", "cottage"]),
    ("Meat & Poultry", MEAT),
    ("Fish & Seafood", FISH),
    ("Legumes & Pulses", ["bean", "lentil", "chickpea", "garbanzo", "pea\\b", "peas\\b", "tofu", "tempeh", "hummus",
                           "soybean", "edamame", "dal\\b", "rajma", "split pea", "lupin", "falafel", "natto"]),
    ("Grains & Bakery", ["rice", "oat", "wheat", "bread", "pasta", "noodle", "spaghetti", "macaroni", "flour", "cereal",
                          "quinoa", "barley", "corn\\b", "cornmeal", "tortilla", "bagel", "toast", "couscous", "bulgur",
                          "millet", "rye", "granola", "roll\\b", "bun\\b", "pita", "naan", "roti", "chapati", "semolina",
                          "muesli", "porridge", "grits", "polenta", "farro", "buckwheat", "amaranth", "sorghum"]),
    ("Fruits", ["apple", "banana", "orange", "mango", "grape", "berry", "berries", "melon", "peach", "pear\\b", "plum",
                 "cherry", "pineapple", "papaya", "guava", "kiwi", "lemon", "lime\\b", "apricot", "fig\\b", "figs",
                 "date\\b", "dates\\b", "pomegranate", "avocado", "coconut", "fruit", "tangerine", "grapefruit",
                 "nectarine", "persimmon", "currant", "cranberr", "lychee", "plantain", "raisin", "prune", "rhubarb"]),
    ("Vegetables", ["spinach", "broccoli", "carrot", "tomato", "potato", "onion", "cabbage", "lettuce", "cucumber",
                     "pepper", "mushroom", "cauliflower", "zucchini", "squash", "kale", "beet", "celery", "garlic",
                     "pumpkin", "eggplant", "okra", "asparagus", "radish", "turnip", "salad", "greens", "sprouts",
                     "leek", "artichoke", "cress", "chard", "yam\\b", "cassava", "jicama", "kohlrabi", "parsnip",
                     "peppers", "chilli", "chili", "ginger", "herb", "basil", "parsley", "cilantro", "mint\\b", "vegetable"]),
]

SLOTS = {
    "Fruits": ["breakfast", "snack"], "Vegetables": ["lunch", "dinner"], "Grains & Bakery": ["breakfast", "lunch", "dinner"],
    "Legumes & Pulses": ["lunch", "dinner", "snack"], "Dairy & Eggs": ["breakfast", "snack"],
    "Meat & Poultry": ["lunch", "dinner"], "Fish & Seafood": ["lunch", "dinner"], "Nuts & Seeds": ["snack", "breakfast"],
    "Soups & Prepared meals": ["lunch", "dinner"], "Fast food & Snacks": ["snack"], "Sweets & Desserts": ["snack"],
    "Beverages": ["snack", "breakfast"], "Fats & Oils": [], "Other": ["snack"],
}
# categories that make sense as day-to-day recommendations
RECOMMENDABLE = {"Fruits", "Vegetables", "Grains & Bakery", "Legumes & Pulses", "Dairy & Eggs", "Meat & Poultry",
                 "Fish & Seafood", "Nuts & Seeds", "Soups & Prepared meals"}

def classify_diet(name):
    n = name.lower()
    ov = has(n, VEG_OVERRIDE)
    if has(n, FISH) and not ov: return "fish"
    if has(n, MEAT) and not ov and not has(n, ["peanut butter"]): return "nonveg"
    egg = has(n, EGG) and not has(n, ["eggplant"])
    dairy = has(n, DAIRY) and not has(n, NOT_DAIRY)
    baked = has(n, BAKED_VEG) and not has(n, ["vegan", "dairy free", "gluten free"])
    if egg: return "egg"
    if dairy or baked or has(n, HONEY): return "veg"
    return "vegan"

def contains_flags(name, diet):
    n = name.lower(); c = []
    if diet in ("veg", "egg") and (has(n, DAIRY) and not has(n, NOT_DAIRY) or has(n, BAKED_VEG)):
        c.append("dairy")
    if has(n, EGG) and not has(n, ["eggplant"]) or diet == "egg": c.append("egg")
    if has(n, GLUTEN) and not has(n, ["gluten free", "rice noodle", "corn tortilla", "rice cake"]): c.append("gluten")
    if has(n, NUTS): c.append("nuts")
    if has(n, SOY): c.append("soy")
    if diet == "fish": c.append("fish")
    return sorted(set(c))

def categorize(name):
    n = name.lower()
    if has(n, ["peanut butter", "almond butter", "nut butter", "tahini", "sunflower butter"]): return "Nuts & Seeds"
    if has(n, ["noodle", "pasta\\b", "spaghetti", "macaroni"]) and not has(n, ["soup", "sauce", "with", "salad", "dinner", "meal"]):
        return "Grains & Bakery"
    for cat, words in CAT_RULES:
        if has(n, words): return cat
    return "Other"

def health_score(cat, kcal100, p100, f100, fib100, sug100, sat100):
    per100kcal = lambda v: (v / kcal100 * 100) if kcal100 > 5 else 0
    s = 5.0
    s += min(3, per100kcal(p100) * 0.30)
    s += min(2, per100kcal(fib100) * 0.9)
    s -= min(3, per100kcal(sug100) * 0.22)
    s -= min(2, per100kcal(sat100) * 0.28)
    if kcal100 > 450: s -= 1
    if cat in ("Fruits", "Vegetables", "Legumes & Pulses"): s += 1
    if cat in ("Sweets & Desserts", "Fast food & Snacks", "Fats & Oils", "Beverages"): s -= 1.5
    return int(max(1, min(10, round(s))))

def tags_for(cat, diet, kcal100, p100, c100, f100, fib100, kcal_s, p_s):
    t = []
    if diet == "vegan": t.append("Vegan")
    if diet in ("vegan", "veg"): t.append("Vegetarian")
    if diet == "egg": t.append("Eggetarian")
    if diet == "fish": t.append("Pescatarian")
    if kcal100 > 0 and p100 * 4 / kcal100 >= 0.25 and p100 >= 8: t.append("High protein")
    if fib100 >= 3.5: t.append("High fibre")
    if 0 < kcal100 <= 60: t.append("Low calorie")
    if c100 <= 8 and kcal100 > 0: t.append("Low carb")
    if f100 <= 3 and kcal100 > 0: t.append("Low fat")
    return t

def num(row, key):
    try: return max(0.0, float(row.get(key) or 0))
    except ValueError: return 0.0

def title(s): return re.sub(r"\s+", " ", s.strip()).capitalize()

# ingredients / pantry items that are not sensible meal suggestions on their own
NOT_A_MEAL = ["stock\\b", "broth", "bouillon", "flour", "paste\\b", "topping", "puffs", "snacks?\\b", "powder", "starch",
              "pancreas", "lung", "spleen", "brain", "tripe", "feet\\b", "skin\\b", "fat\\b", "drippings", "ostrich", "emu\\b",
              "whale", "seal\\b", "turtle", "frog", "squirrel", "opossum", "raccoon", "beaver", "dehydrated", "freeze dried",
              "infant", "baby ?food", "formula", "imitation", "substitute", "syrup", "frosting", "canned in", "leaves\\b"]
foods, seen = [], set()

# ---- hand-checked starter foods (already per 100 g) -------------------------
SERVING_G = {"Banana": 120, "Apple": 150, "Orange": 130, "Boiled egg": 50, "Whole wheat roti": 40, "Almonds": 30,
             "Chia seeds": 15, "Peanut butter": 16, "Paneer": 100, "Cucumber": 100, "Plain yogurt": 150,
             "Milk, 2%": 200, "Tuna, canned": 100}
for s in json.load(open(STARTER, encoding="utf-8")):
    name = s["name"]; key = name.lower()
    if key in seen: continue
    seen.add(key)
    tags_l = set(s.get("tags", []))
    diet = "vegan" if "vegan" in tags_l else "veg" if "vegetarian" in tags_l else "egg" if "egg" in tags_l else \
        ("fish" if has(key, FISH) else "nonveg" if has(key, MEAT) else "veg")
    if name == "Paneer" or "yogurt" in key or "milk" in key: diet = "veg"
    cat = categorize(name)
    if cat == "Other": cat = {"Breakfast": "Grains & Bakery", "Protein": "Legumes & Pulses", "Fruit": "Fruits"}.get(s["category"], "Vegetables")
    g = SERVING_G.get(name, 100)
    k, p, c, f = s["calories"], s["protein"], s["carbs"], s["fat"]
    fib = 3.0 if "high-fibre" in tags_l else 1.0
    foods.append({
        "id": "s-" + re.sub(r"[^a-z0-9]+", "-", key).strip("-"), "name": name, "category": cat, "diet": diet,
        "contains": contains_flags(name, diet), "servingG": g,
        "kcal": round(k * g / 100), "p": round(p * g / 100, 1), "c": round(c * g / 100, 1), "f": round(f * g / 100, 1),
        "fiber": round(fib * g / 100, 1), "sugar": 0,
        "per100": {"kcal": k, "p": p, "c": c, "f": f, "fiber": fib},
        "score": health_score(cat, k, p, f, fib, 0, 0), "tags": tags_for(cat, diet, k, p, c, f, fib, k * g / 100, p * g / 100),
        "slots": SLOTS.get(cat, ["snack"]), "recommend": True, "quality": "ok", "source": "starter",
    })

# ---- Kaggle CSV --------------------------------------------------------------
dropped = {"dup": 0, "impossible": 0}
with open(SRC, encoding="utf-8-sig", newline="") as fh:
    for row in csv.DictReader(fh):
        raw = (row.get("food") or "").strip()
        if not raw: continue
        key = raw.lower()
        if key in seen: dropped["dup"] += 1; continue
        seen.add(key)
        kcal, p, c, f = num(row, "Caloric Value"), num(row, "Protein"), num(row, "Carbohydrates"), num(row, "Fat")
        fib, sug, sat, water = num(row, "Dietary Fiber"), num(row, "Sugars"), num(row, "Saturated Fats"), num(row, "Water")
        mass = (water + p + c + f) * 1.012
        ok = mass >= 8 and kcal / max(mass, 1) * 100 <= 900 and (p + c + f) <= mass * 1.02
        cat = categorize(raw); diet = classify_diet(raw)
        item = {"id": "k-%d" % len(foods), "name": title(raw), "category": cat, "diet": diet,
                "contains": contains_flags(raw, diet), "kcal": round(kcal), "p": round(p, 1), "c": round(c, 1),
                "f": round(f, 1), "fiber": round(fib, 1), "sugar": round(sug, 1), "source": "kaggle"}
        if ok:
            k100 = kcal * 100 / mass
            per = {"kcal": round(k100), "p": round(p * 100 / mass, 1), "c": round(c * 100 / mass, 1),
                   "f": round(f * 100 / mass, 1), "fiber": round(fib * 100 / mass, 1)}
            item.update({"servingG": int(round(mass)), "per100": per, "quality": "ok",
                         "score": health_score(cat, per["kcal"], per["p"], per["f"], per["fiber"], sug * 100 / mass, sat * 100 / mass),
                         "tags": tags_for(cat, diet, per["kcal"], per["p"], per["c"], per["f"], per["fiber"], kcal, p),
                         "recommend": cat in RECOMMENDABLE and kcal > 0 and not has(key, ALCOHOL) and not has(key, NOT_A_MEAL)
                                      and not (cat in ("Meat & Poultry", "Fish & Seafood") and has(key, [r"raw\\b"]))})
        else:
            dropped["impossible"] += 1
            item.update({"servingG": None, "per100": None, "quality": "serving-only", "score": None,
                         "tags": [], "recommend": False})
        item["slots"] = SLOTS.get(cat, ["snack"])
        foods.append(item)

OUT.parent.mkdir(parents=True, exist_ok=True)
json.dump(foods, open(OUT, "w", encoding="utf-8"), separators=(",", ":"), ensure_ascii=False)
from collections import Counter
print("foods written:", len(foods), "->", OUT.relative_to(ROOT), "| dropped:", dropped)
print("recommendable:", sum(1 for x in foods if x["recommend"]))
print("diet:", dict(Counter(x["diet"] for x in foods)))
print("category:", dict(Counter(x["category"] for x in foods)))
