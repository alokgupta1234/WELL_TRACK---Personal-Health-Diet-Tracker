WELLTRACK – SETUP (Windows / macOS / Linux)

1. Start MongoDB (default: mongodb://127.0.0.1:27017).
2. Terminal 1:   cd server  →  npm install (first time)  →  npm start        (API on :5000)
3. Terminal 2:   project root →  npm install (first time)  →  npm run dev     (app on :5173)
4. Open http://localhost:5173 and sign in with the demo account shown on the login page:
       Email:    demo@welltrack.app
       Password: Demo@12345

Optional: ANTHROPIC_API_KEY in server/.env switches HealthMate to AI mode. Without it the built-in assistant is used.
Password-reset e-mails need the SMTP_* values in server/.env (the demo account cannot be reset).
See README.md for the full documentation, the tests and how the food dataset is built.
