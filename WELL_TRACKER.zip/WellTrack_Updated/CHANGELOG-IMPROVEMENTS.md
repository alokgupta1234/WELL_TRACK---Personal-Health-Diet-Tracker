# Changelog – major update

**Design** – new interface (soft rounded cards, mint accent, framed sidebar, charts drawn in SVG), responsive down to phones, print-ready report.
**Dashboard** – greets the logged-in user ("Welcome, *name*"); water, calories, daily score, next meal, weekly chart, journey.
**Navigation** – Dashboard → Health profile → Diet tracker → Progress → Food library → Meal planner → Health reports → HealthMate.
**Diet tracker** – now a personalised recommendation system: breakfast / lunch / snack / dinner with timings, portions, calories, macros, water schedule and nutrition breakdown generated from the Health profile. Tick meals, swap meals; manual entry still available.
**Progress** – weight journey with start/current/target, goal completion, consistency score, calories vs goal, macro balance, weekly rings, insights, achievements.
**Food library** – dataset cleaned (per-serving → per-100 g), classified, and ranked per user; diet rules for vegetarian, vegan, eggitarian, pescatarian, non-veg, plus exclusions.
**Meal planner** – 7-day plan, swaps, regenerate, prep checklist; shares state with the Diet tracker.
**Health reports** – same content and calculations, new look.
**HealthMate** – conversational assistant with context memory and access to the user's data; optional LLM mode.
**Demo account** – `demo@welltrack.app` / `Demo@12345`, seeded in MongoDB with 90 days of data.
**Fixes** – manual calorie/water targets no longer silently ignored; logged weight updates profile weight/BMI; Express async errors can no longer crash the API; login rate limiting; fresh random JWT secret; date range queries; duplicate/impossible dataset rows removed; dietary rules for vegan/vegetarian now based on food names, not guesses.
