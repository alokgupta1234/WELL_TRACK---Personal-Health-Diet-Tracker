# WellTrack – Personal Health & Diet Tracker

A full-stack health and diet app: **React 18 + Vite** frontend, **Express + MongoDB** API.
It reads the user's Health profile and turns it into a personalised daily diet plan, a food library that follows their diet,
a weekly meal planner, a progress dashboard and a conversational assistant (HealthMate).

## Quick start

```bash
# 1. MongoDB must be running locally (mongodb://127.0.0.1:27017)
# 2. API
cd server
npm install          # first time only
npm start            # http://localhost:5000  (also creates the demo account)

# 3. Frontend (second terminal, project root)
npm install          # first time only
npm run dev          # http://localhost:5173
```

### Demo account (pre-filled, shown on the login page)

| | |
|---|---|
| **Email** | `demo@welltrack.app` |
| **Password** | `Demo@12345` |

It is a normal account stored in MongoDB: a complete Health profile (vegetarian, weight-loss goal), 90 days of meals, water,
activity and weight records, plan swaps, progress history, reports and a working HealthMate. The history is regenerated relative
to *today* when the server starts and on the first demo login of each day. Set `SEED_DEMO=false` in `server/.env` to disable it.

## What is in the app

| Tab | What it does |
|---|---|
| **Dashboard** | "Welcome, *your name*", water / calories / daily-score cards, next meal, weekly calories, journey summary |
| **Health profile** | Age, height, weight, target weight, gender, activity, goal, diet (incl. vegan, eggitarian, pescatarian), exclusions (dairy-, gluten-, nut-free, low-carb, high-protein). Live preview of the calculated targets |
| **Diet tracker** | Personalised plan for the day: breakfast, lunch, evening snack, dinner with **timings, portions, calories and macros**, a water schedule and a nutrition breakdown. One tap to tick a meal as eaten, swap any meal for a matching alternative |
| **Progress** | Weight journey (start → now → target), goal completion, consistency score, calories vs goal, macro balance, weekly rings, water/activity/protein charts, insights and achievements |
| **Food library** | The nutrition dataset ranked for *this* user: diet filter (vegetarian = vegetarian only, non-veg = both, vegan = vegan only, etc.), goal-aware match %, search, category / meal / nutrition filters, "Log this food" |
| **Meal planner** | 7-day plan from the same engine, swap meals, regenerate the week, prep & shopping checklist, print |
| **Health reports** | Printable summary (content and calculations unchanged from the original) |
| **HealthMate** | Conversational assistant that knows the profile, plan, logs and progress and remembers the conversation |

Navigation order: Dashboard → Health profile → Diet tracker → Progress → Food library → Meal planner → Health reports → HealthMate.

### How the numbers are calculated
* **Calories** – Mifflin-St Jeor BMR × activity factor = TDEE, then a goal adjustment (lose ≈ −500, gain ≈ +400, with safety floors). If gender is not specified a neutral constant is used. Switch on *Custom* in Health profile to enter your own calorie / water targets.
* **Protein / carbs / fat / fibre** – protein from body weight and goal, fat ≈ 25–30 % of calories, carbs the rest, fibre 14 g per 1,000 kcal.
* **Water** – ≈ 35 ml per kg plus an activity allowance, shown as a glass-by-glass schedule.
* **Meals** – 25 % breakfast, 33 % lunch, 12 % snack, 30 % dinner, at 08:00 / 13:00 / 17:00 / 20:00.
* **Plans** come from a curated meal database (`shared/meals.mjs`, Indian and international meals with verified diet tags) and are deterministic per user and day; *Swap* and *Regenerate* are stored on the account.
* **Food library** uses the cleaned dataset (`public/datasets/foods-clean.json`).

### Food dataset
`datasets/Food_Nutrition_dataset.csv` reports values **per serving**, not per 100 g. `scripts/build-food-dataset.py` estimates each
serving's weight (protein + carbs + fat + water), converts everything to per-100 g, removes impossible rows, assigns categories,
meal slots, health scores and diet labels (vegan / vegetarian / egg / fish / non-veg) and writes `foods-clean.json`.
Re-run it with `npm run build:foods`. Diet labels are inferred from food names – always check ingredients for allergies.

### HealthMate: on-device assistant + optional AI mode
* Works out of the box with the built-in engine (`shared/chat.mjs`): intent + entity understanding, follow-ups ("what about lunch?", "and protein?"), answers computed from the user's real data and the food database.
* For free-form LLM answers set `ANTHROPIC_API_KEY` in `server/.env` (and optionally `ANTHROPIC_MODEL`). The server then sends the question plus a compact summary of the user's data to the API; if the call fails the chat automatically falls back to the on-device assistant.

## Tests
```bash
npm test                      # render test of every page with several profiles (125 checks)
cd server && npm test         # real API routes against an in-memory MongoDB stand-in (31 checks)
node tests/e2e/serve.mjs      # optional: full stack for the browser test, then:  python tests/e2e/run.py
```

## Project layout
```
shared/    engine.mjs (targets, planner, food ranking, progress)  meals.mjs  chat.mjs  demo.mjs   ← used by API and UI
src/       App.jsx  pages/*  ui.jsx (charts)  Modals.jsx  styles.css
server/    src/server.js  src/seedDemo.js  test/
public/datasets/foods-clean.json     scripts/build-food-dataset.py     tests/
```

## Notes
* This is a wellness tool, not medical advice. Estimates are general; people with medical conditions, pregnancy or a history of disordered eating should consult a professional.
* `server/.env` contains a freshly generated `JWT_SECRET`. Do not publish it; create a new one for any deployment.
