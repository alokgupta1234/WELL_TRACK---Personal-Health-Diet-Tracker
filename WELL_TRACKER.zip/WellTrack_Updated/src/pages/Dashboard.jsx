import React from 'react';
import { Activity, ArrowRight, Droplets, Flame, Gauge, Plus, Scale, Sparkles, Check, Target, TrendingUp } from 'lucide-react';
import { addDays } from '../../shared/engine.mjs';
import { dailySeries, bmiOf, bmiLabel } from '../../shared/engine.mjs';
import { Card, CardHead, PageHead, Pill, ProgressBar, Sparkline, SegGauge, BarChart, n0, clamp } from '../ui.jsx';
import { SLOT_ICON } from '../meta.js';

export default function Dashboard({ app }) {
  const { user, profile, targets, summary, planToday, entries, today, actions, go } = app;
  const t = summary.today, name = (user?.name || '').trim() || 'there';
  const water = t.water, wPct = Math.round(clamp(water / targets.water, 0, 1.5) * 100);
  const kPct = Math.round((t.calories / targets.calories) * 100);
  const score = Math.round(100 * (clamp(t.calories / targets.calories, 0, 1) + clamp(water / targets.water, 0, 1) + clamp(t.activity / 30, 0, 1)) / 3);
  const ticked = new Set(entries.filter(e => e.dateKey === today && e.kind === 'meal' && e.mealRef).map(e => e.mealRef.split(':')[0]));
  const week = dailySeries(entries, addDays(today, -6), today);
  const bmi = bmiOf(profile), j = summary.journey;
  const blocks = Math.round(clamp(t.calories / targets.calories, 0, 1) * 7);
  const next = planToday.slots.find(s => !ticked.has(s.slot));
  return <>
    <PageHead title={`Welcome, ${name}`} subtitle="A quick look at your habits today. Every small step counts."
      right={<div className="head-actions"><button className="btn btn-soft" onClick={() => actions.addWater(250)}><Droplets size={16} /> +250 ml</button><button className="btn btn-soft" onClick={() => actions.openModal('activity')}><Activity size={16} /> Log activity</button><button className="btn btn-primary" onClick={() => go('meals')}>Today's plan <ArrowRight size={16} /></button></div>} />
    {!targets.complete && <div className="alert alert-info">Add your {targets.missing.join(', ')} in <button className="link" onClick={() => go('health')}>Health profile</button> to get calorie and water targets calculated for you.</div>}
    <div className="grid g3">
      <Card className="stat"><div className="stat-top"><span>Water</span><i className="stat-ico ico-blue"><Droplets size={18} /></i></div>
        <div className="stat-val">{(water / 1000).toFixed(1)}<small>Liters</small></div>
        <Sparkline values={week.map(d => d.water)} color="#38bdf8" />
        <div className="stat-foot"><Pill tone="blue">{wPct}%</Pill> of your {(targets.water / 1000).toFixed(1)} L goal</div></Card>
      <Card className="stat"><div className="stat-top"><span>Calories</span><i className="stat-ico ico-orange"><Flame size={18} /></i></div>
        <div className="stat-val">{n0(t.calories)}<small>kcal</small></div>
        <div className="blocks" aria-hidden="true">{Array.from({ length: 7 }, (_, i) => <i key={i} className={i < blocks ? 'on' : ''} />)}</div>
        <div className="stat-foot"><Pill tone="orange">{kPct}%</Pill> of {n0(targets.calories)} kcal target</div></Card>
      <Card className="stat stat-gauge"><div className="stat-top"><span>Daily score</span><i className="stat-ico ico-mint"><Target size={18} /></i></div>
        <SegGauge value={score} label={`${score}%`} size={200} />
        <div className="stat-foot center">{score >= 80 ? 'Fantastic day so far' : score >= 40 ? 'Keep going — you are on your way' : 'Tick your meals and log water to build your score'}</div></Card>
    </div>
    <div className="grid g-main">
      <div className="stack">
        <Card className="hero">
          <div><span className="eyebrow light"><Sparkles size={13} /> YOUR DAILY CHECK-IN</span>
            <h2>{next ? `Next up: ${next.label.toLowerCase()} at ${next.time}` : 'All meals done — well played!'}</h2>
            <p>{next ? `${next.items.map(i => i.name).join(' + ')} · ${next.kcal} kcal` : `You've ticked every meal of today's plan. Keep sipping water and enjoy the evening.`}</p>
            <button className="btn btn-white" onClick={() => go('meals')}>{next ? 'Open today\'s plan' : 'Review the day'} <ArrowRight size={16} /></button></div>
          <div className="hero-art" aria-hidden="true"><i /><i /><i /></div>
        </Card>
        <Card><CardHead title="Calories this week" subtitle="Logged calories against your daily target" right={<Pill>{summary.stats7.onTargetDays}/7 on target</Pill>} />
          <BarChart labels={week.map(d => ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'][new Date(d.date + 'T12:00:00').getDay()])} values={week.map(d => Math.round(d.calories))} goal={targets.calories} unit=" kcal" height={190} /></Card>
      </div>
      <div className="stack">
        <Card><CardHead title="Today's plans" subtitle="Personalised from your health profile" right={<button className="link" onClick={() => go('meals')}>See all</button>} />
          <ul className="plan-list">{planToday.slots.map(s => { const Ico = SLOT_ICON[s.slot]; const done = ticked.has(s.slot);
            return <li key={s.slot} className={done ? 'done' : ''}><i className="plan-ico"><Ico size={17} /></i>
              <div><strong>{s.label}</strong><small>{s.time} · {s.kcal} kcal</small><p>{s.items.map(i => i.name).join(' · ')}</p></div>
              <button className={`tick ${done ? 'on' : ''}`} aria-label={done ? `Unmark ${s.label}` : `Mark ${s.label} as eaten`} onClick={() => actions.toggleSlot(today, s.slot)}><Check size={15} /></button></li>; })}</ul></Card>
        <Card><CardHead title="Your journey" subtitle={j.target ? `Target ${j.target} kg` : 'Set a target weight in your profile'} right={<button className="link" onClick={() => go('progress')}>Progress</button>} />
          <div className="journey-mini"><div><small>BMI</small><strong>{bmi ? bmi.toFixed(1) : '—'}</strong><span>{bmiLabel(bmi)}</span></div>
            <div><small>Weight</small><strong>{j.current || '—'}<em>kg</em></strong><span>{j.changeKg ? `${j.changeKg > 0 ? '+' : ''}${j.changeKg} kg since start` : 'Record your weight'}</span></div></div>
          {j.pct != null && <><ProgressBar value={j.pct} /><div className="split-label"><span>{j.start} kg</span><b>{j.pct}% complete</b><span>{j.target} kg</span></div></>}
          <div className="streak-line"><TrendingUp size={15} /> {summary.streak ? `${summary.streak}-day logging streak` : 'Start a logging streak today'}</div></Card>
      </div>
    </div>
  </>;
}
