import React, { useState, useMemo } from 'react';
import { Check, Gauge, HeartPulse, Info, Save, UserRound } from 'lucide-react';
import { computeTargets, bmiOf, bmiLabel, healthyRange, GOALS, DIET_OPTIONS, EXTRA_OPTIONS, ACTIVITY_FACTORS } from '../../shared/engine.mjs';
import { Card, CardHead, PageHead, Pill, Toggle, n0, clamp } from '../ui.jsx';

const GENDERS = ['Prefer not to say', 'Female', 'Male', 'Other'];
const num = v => (v === '' || v == null ? '' : Number(v));

export default function HealthProfile({ app }) {
  const { profile, user, actions } = app;
  const [d, setD] = useState(() => ({ ...profile, name: user?.name || '', dietExtras: profile.dietExtras || [] }));
  const [base] = useState(() => JSON.stringify({ ...profile, name: user?.name || '', dietExtras: profile.dietExtras || [] }));
  const set = (k, v) => setD(x => ({ ...x, [k]: v }));
  const live = useMemo(() => computeTargets({ ...d, age: num(d.age), heightCm: num(d.heightCm), weightKg: num(d.weightKg), calorieGoal: num(d.calorieGoal), waterGoalMl: num(d.waterGoalMl) }), [d]);
  const bmi = bmiOf({ heightCm: num(d.heightCm), weightKg: num(d.weightKg) }), rng = healthyRange(num(d.heightCm));
  const pos = bmi ? clamp(((bmi - 14) / (40 - 14)) * 100, 2, 98) : 0;
  const toggleExtra = id => set('dietExtras', d.dietExtras.includes(id) ? d.dietExtras.filter(x => x !== id) : [...d.dietExtras, id]);
  const submit = e => { e.preventDefault(); actions.saveProfile(d); };
  const dirty = JSON.stringify(d) !== base;
  return <>
    <PageHead eyebrow="YOUR PERSONAL DETAILS" title="Health profile" subtitle="Everything in WellTrack — your plan, targets, food suggestions and progress — is built from these details." />
    <form className="grid g-profile" onSubmit={submit}>
      <div className="stack">
        <Card><CardHead title="Personal information" subtitle="Used for health calculations" right={<i className="stat-ico ico-mint"><UserRound size={18} /></i>} />
          <div className="form-grid">
            <label className="span2">Full name<input value={d.name} onChange={e => set('name', e.target.value)} required maxLength={100} /><small>Shown in your dashboard greeting.</small></label>
            <label>Age<span className="input-unit"><input type="number" min="10" max="100" value={d.age ?? ''} onChange={e => set('age', e.target.value)} placeholder="e.g. 28" /><em>years</em></span></label>
            <label>Height<span className="input-unit"><input type="number" min="100" max="240" step="0.5" value={d.heightCm ?? ''} onChange={e => set('heightCm', e.target.value)} placeholder="e.g. 172" /><em>cm</em></span></label>
            <label>Current weight<span className="input-unit"><input type="number" min="30" max="350" step="0.1" value={d.weightKg ?? ''} onChange={e => set('weightKg', e.target.value)} placeholder="e.g. 68" /><em>kg</em></span></label>
            <label>Target weight<span className="input-unit"><input type="number" min="30" max="350" step="0.1" value={d.targetWeightKg ?? ''} onChange={e => set('targetWeightKg', e.target.value)} placeholder="optional" /><em>kg</em></span></label>
            <label>Gender<select value={d.gender} onChange={e => set('gender', e.target.value)}>{GENDERS.map(g => <option key={g}>{g}</option>)}</select></label>
            <label>Activity level<select value={d.activityLevel} onChange={e => set('activityLevel', e.target.value)}>{Object.keys(ACTIVITY_FACTORS).map(g => <option key={g}>{g}</option>)}</select></label>
          </div></Card>
        <Card><CardHead title="Goal & diet" subtitle="Drives calories, macros and which foods are suggested" />
          <div className="form-grid">
            <label>Health goal<select value={d.goal} onChange={e => set('goal', e.target.value)}>{GOALS.map(g => <option key={g}>{g}</option>)}</select></label>
            <label>Dietary preference<select value={d.dietaryPreference} onChange={e => set('dietaryPreference', e.target.value)}>{DIET_OPTIONS.map(g => <option key={g}>{g}</option>)}</select></label>
            <div className="span2"><span className="label-text">Other preferences</span>
              <div className="chip-row">{EXTRA_OPTIONS.map(x => <button type="button" key={x.id} className={`chip ${d.dietExtras.includes(x.id) ? 'on' : ''}`} aria-pressed={d.dietExtras.includes(x.id)} onClick={() => toggleExtra(x.id)}>{d.dietExtras.includes(x.id) && <Check size={13} />}{x.label}</button>)}</div></div>
          </div></Card>
        <Card><CardHead title="Daily targets" subtitle="Calculated for you — switch to custom if your dietitian gave you numbers" right={<Toggle checked={!!d.customTargets} onChange={v => set('customTargets', v)} label="Custom" />} />
          {d.customTargets ? <div className="form-grid">
            <label>Daily calorie target<span className="input-unit"><input type="number" min="500" max="10000" value={d.calorieGoal ?? ''} onChange={e => set('calorieGoal', e.target.value)} /><em>kcal</em></span></label>
            <label>Daily water target<span className="input-unit"><input type="number" min="250" max="10000" step="50" value={d.waterGoalMl ?? ''} onChange={e => set('waterGoalMl', e.target.value)} /><em>ml</em></span></label>
          </div> : <p className="muted">Targets are calculated automatically from your age, height, weight, gender, activity level and goal (see the preview on the right).</p>}
          <div className="form-foot"><span className="muted"><HeartPulse size={14} /> Only visible to your account</span><button className="btn btn-primary" disabled={!dirty}><Save size={16} /> Save profile</button></div></Card>
      </div>
      <div className="stack">
        <Card className="bmi-card"><span className="eyebrow light">HEALTH INDICATOR</span><h3>Body Mass Index</h3>
          <div className="bmi-val">{bmi ? bmi.toFixed(1) : '—'}<small>BMI</small></div>
          <Pill tone="white">{bmiLabel(bmi)}</Pill>
          <div className="bmi-scale"><i style={{ left: `${pos}%`, opacity: bmi ? 1 : 0 }} /><span /><span /><span /><span /></div>
          <div className="bmi-legend"><span>Low</span><span>In range</span><span>High</span></div>
          <p>{rng ? `Healthy range for ${d.heightCm} cm: ${rng.min}–${rng.max} kg.` : 'Add height and weight to see your range.'} BMI is a general screening number, not a diagnosis.</p></Card>
        <Card><CardHead title="Your targets preview" subtitle={live.source === 'custom' ? 'Custom targets' : live.complete ? 'Calculated from your details' : 'Using defaults'} />
          {!live.complete && <div className="alert alert-info"><Info size={15} /> Add {live.missing.join(', ')} for personalised numbers.</div>}
          <div className="target-grid">
            <div><small>Calories</small><strong>{n0(live.calories)}</strong><span>kcal / day</span></div>
            <div><small>Water</small><strong>{(live.water / 1000).toFixed(1)}</strong><span>litres / day</span></div>
            <div><small>Protein</small><strong>{live.protein}</strong><span>g / day</span></div>
            <div><small>Carbs · Fat</small><strong>{live.carbs} · {live.fat}</strong><span>g / day</span></div>
          </div>
          {live.complete && live.source === 'auto' && <p className="muted small">BMR {live.bmr} kcal × {ACTIVITY_FACTORS[d.activityLevel]} activity = {live.tdee} kcal; goal adjustment {live.adjustment > 0 ? '+' : ''}{live.adjustment} kcal.</p>}</Card>
        <Card className="note"><strong>Estimates, not diagnoses</strong><p>Daily needs depend on many factors. If you are under 18, pregnant, managing a medical condition or have a history of disordered eating, please get individual advice from a qualified professional.</p></Card>
      </div>
    </form>
  </>;
}
