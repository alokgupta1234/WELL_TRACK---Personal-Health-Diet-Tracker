import React from 'react';
import { Download, HeartPulse } from 'lucide-react';
import { addDays, bmiOf, bmiLabel } from '../../shared/engine.mjs';
import { PageHead, Card } from '../ui.jsx';

// Content and calculations are unchanged from the original report; only the presentation was redesigned.
export default function Reports({ app }) {
  const { user, profile, targets, entries, today } = app;
  const bmi = bmiOf(profile), label = bmiLabel(bmi);
  const day = entries.filter(e => e.dateKey === today);
  const meals = day.filter(e => e.kind === 'meal');
  const calories = Math.round(meals.reduce((a, e) => a + e.calories, 0));
  const water = day.filter(e => e.kind === 'water').reduce((a, e) => a + e.amount, 0);
  const activity = day.filter(e => e.kind === 'activity').reduce((a, e) => a + e.amount, 0);
  // last 30 days, one record per day that has any entry (same as the previous "progress" list)
  const from = addDays(today, -29);
  const byDate = {};
  for (const e of entries) {
    if (e.dateKey < from || e.dateKey > today) continue;
    const d = (byDate[e.dateKey] ||= { calories: 0, weight: null });
    if (e.kind === 'meal') d.calories += e.calories;
    if (e.kind === 'weight') d.weight = e.amount;
  }
  const progress = Object.values(byDate);
  const avg = progress.length ? Math.round(progress.reduce((a, p) => a + p.calories, 0) / progress.length) : 0;
  const weightPoints = progress.filter(p => p.weight !== null && p.weight !== undefined);
  return <>
    <PageHead eyebrow="YOUR WELLNESS SUMMARY" title="Health reports" subtitle="Review your saved profile and tracking trends, then print or save a PDF copy."
      right={<button className="btn btn-primary" onClick={() => window.print()}><Download size={16} /> Print / Save PDF</button>} />
    <Card className="report-paper" id="welltrack-report">
      <div className="report-header"><div><span className="eyebrow">WELLTRACK · PERSONAL REPORT</span><h2>Health &amp; wellness summary</h2><p>Prepared for {user?.name || 'Your account'} · {new Date().toLocaleDateString('en-IN', { dateStyle: 'long' })}</p></div><div className="report-mark"><HeartPulse size={28} /></div></div>
      <div className="report-metrics">
        <div><small>Current BMI</small><strong>{bmi ? bmi.toFixed(1) : '—'}</strong><span>{label}</span></div>
        <div><small>Calorie target</small><strong>{targets.calories.toLocaleString()}</strong><span>kcal / day</span></div>
        <div><small>Water today</small><strong>{(water / 1000).toFixed(2)} L</strong><span>Logged intake</span></div>
        <div><small>Activity today</small><strong>{activity}</strong><span>minutes</span></div>
      </div>
      <h3>Health profile</h3>
      <div className="report-details"><span>Age: {profile.age || 'Not provided'}</span><span>Height: {profile.heightCm || '—'} cm</span><span>Weight: {profile.weightKg || '—'} kg</span><span>Activity: {profile.activityLevel}</span><span>Diet: {profile.dietaryPreference}</span><span>Goal: {profile.goal}</span></div>
      <h3>Recent tracking</h3>
      <div className="report-details"><span>Days with records: {progress.length}</span><span>Average logged calories: {avg} kcal/day</span><span>Meals logged today: {meals.length}</span><span>Weight records in range: {weightPoints.length}</span><span>Today's calories: {calories} kcal</span></div>
      <p className="health-disclaimer">This report summarizes information entered into WellTrack. It is not a diagnosis, medical record, or treatment recommendation. BMI and calorie values are general estimates.</p>
    </Card>
  </>;
}
