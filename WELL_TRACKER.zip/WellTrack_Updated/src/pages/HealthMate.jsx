import React, { useEffect, useRef, useState } from 'react';
import { Bot, Send, Sparkles, Trash2, UserRound } from 'lucide-react';
import { respond, buildChatContext, welcomeMessage, defaultChips } from '../../shared/chat.mjs';
import { request } from '../api.js';
import { Card, PageHead, Pill, Rich } from '../ui.jsx';

const KEY = id => `welltrack_chat_${id || 'guest'}`;
const load = id => { try { const v = JSON.parse(localStorage.getItem(KEY(id)) || 'null'); return v && Array.isArray(v.messages) ? v : null; } catch { return null; } };
const save = (id, v) => { try { localStorage.setItem(KEY(id), JSON.stringify({ messages: v.messages.slice(-60), mem: v.mem })); } catch { /* storage unavailable */ } };

export default function HealthMate({ app }) {
  const { chatCtx, user, go, aiMode } = app;
  const [state, setState] = useState(() => load(user?.id) || { messages: [{ role: 'assistant', ...welcomeMessage(chatCtx) }], mem: {} });
  const [input, setInput] = useState(''), [typing, setTyping] = useState(false), [mode, setMode] = useState(aiMode ? 'ai' : 'local');
  const endRef = useRef(null);
  useEffect(() => { endRef.current?.scrollIntoView?.({ behavior: 'smooth', block: 'end' }); }, [state.messages.length, typing]);
  useEffect(() => { save(user?.id, state); }, [state, user?.id]);
  useEffect(() => { setMode(aiMode ? 'ai' : 'local'); }, [aiMode]);

  async function send(text) {
    const q = String(text ?? input).trim();
    if (!q || typing) return;
    setInput('');
    const withUser = [...state.messages, { role: 'user', text: q }];
    setState(s => ({ ...s, messages: withUser })); setTyping(true);
    let reply = null;
    if (mode === 'ai') {
      try {
        const history = withUser.slice(-14).map(m => ({ role: m.role, content: m.text }));
        const r = await request('/chat', { method: 'POST', body: JSON.stringify({ messages: history, context: buildChatContext(chatCtx) }) });
        reply = { text: r.reply, chips: defaultChips(chatCtx), mem: state.mem };
      } catch { setMode('local'); }
    }
    if (!reply) { await new Promise(r => setTimeout(r, 350)); const r = respond(q, chatCtx, state.mem); reply = { text: r.text, chips: r.chips, mem: r.memory }; }
    setState(s => ({ messages: [...withUser, { role: 'assistant', text: reply.text, chips: reply.chips }], mem: reply.mem || s.mem }));
    setTyping(false);
  }
  const onChip = c => (c.page ? go(c.page) : send(c.send || c.label));
  const clear = () => setState({ messages: [{ role: 'assistant', ...welcomeMessage(chatCtx) }], mem: {} });
  const lastIdx = state.messages.length - 1;
  return <>
    <PageHead eyebrow="YOUR NUTRITION ASSISTANT" title="HealthMate" subtitle="Ask about your plan, calories, foods or progress. HealthMate knows your profile and today's data and remembers what you just asked." />
    <div className="grid g-chat">
      <Card className="chat-side"><div className="bot-art" aria-hidden="true"><Bot size={44} /></div><h3>A little guidance, when you need it.</h3>
        <p>I use your Health profile, Diet tracker, Meal planner, Food library and Progress to give answers that fit <b>you</b>.</p>
        <Pill tone={mode === 'ai' ? 'mint' : 'blue'}><Sparkles size={12} /> {mode === 'ai' ? 'AI mode' : 'Smart assistant (on-device)'}</Pill>
        <div className="try"><small>Try asking</small>{['What should I eat for dinner?', 'Is paneer good for weight loss?', 'How many calories are left today?', 'Banana vs apple', 'How am I doing this week?'].map(q => <button key={q} className="chip" onClick={() => send(q)}>{q}</button>)}</div>
        <small className="muted">General wellness guidance only — not medical advice.</small></Card>
      <Card className="chat">
        <div className="chat-head"><i className="plan-ico big"><Bot size={20} /></i><div><strong>HealthMate</strong><small><span className="live" /> Online</small></div><button className="btn btn-soft btn-sm" onClick={clear}><Trash2 size={14} /> New chat</button></div>
        <div className="chat-body" role="log" aria-live="polite">
          {state.messages.map((m, i) => <div key={i} className={`msg ${m.role}`}>
            <i className="avatar">{m.role === 'user' ? <UserRound size={15} /> : <Bot size={15} />}</i>
            <div className="bubble">{m.role === 'assistant' ? <Rich text={m.text} /> : <p>{m.text}</p>}
              {m.role === 'assistant' && i === lastIdx && m.chips?.length > 0 && !typing && <div className="chips">{m.chips.map(c => <button key={c.label} className="chip" onClick={() => onChip(c)}>{c.label}</button>)}</div>}</div></div>)}
          {typing && <div className="msg assistant"><i className="avatar"><Bot size={15} /></i><div className="bubble typing"><span /><span /><span /></div></div>}
          <div ref={endRef} />
        </div>
        <form className="chat-input" onSubmit={e => { e.preventDefault(); send(); }}>
          <input value={input} onChange={e => setInput(e.target.value)} placeholder="Ask about your meals, calories, foods or progress…" aria-label="Message HealthMate" maxLength={500} />
          <button className="btn btn-primary" disabled={!input.trim() || typing} aria-label="Send"><Send size={17} /></button></form>
      </Card>
    </div>
  </>;
}
