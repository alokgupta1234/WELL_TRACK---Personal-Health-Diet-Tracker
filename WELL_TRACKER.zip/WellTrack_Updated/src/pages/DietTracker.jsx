import React from 'react';
import { Check, ChevronLeft, ChevronRight, Clock, Droplets, Info, Plus, Repeat, Sparkles, Trash2, Utensils } from 'lucide-react';
import { addDays, waterSchedule, parseKey } from '../../shared/engine.mjs';
import { Card, CardHead, PageHead, Pill, ProgressBar, Donut, n0, clamp } from '../ui.jsx';
import { SLOT_ICON } from '../meta.js';

const pretty = (key, today) => key === today ? 'Today' : key === addDays(today, -1) ? 'Yesterday' : key === addDays(today, 1) ? 'Tomorrow' : parseKey(key).toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'short' });

export default function DietTracker({ app }) {
  const { planDay, dateKey, setDateKey, today, targets, entries, actions, profile, go } = app;
  const day = entries.filter(e => e.dateKey === dateKey);
  const meals = day.filter(e => e.kind === 'meal'), extras = meals.filter(e => !e.mealRef);
  const tick = slot => meals.find(e => e.mealRef && e.mealRef.startsWith(`${slot}:`));
  const eaten = meals.reduce((a, e) => a + e.calories, 0), eatenP = meals.reduce((a, e) => a + e.protein, 0), eatenC = meals.reduce((a, e) => a + e.carbs, 0), eatenF = meals.reduce((a, e) => a + e.fat, 0);
  const water = day.filter(e => e.kind === 'water').reduce((a, e) => a + e.amount, 0);
  const future = dateKey > today, sched = waterSchedule(targets.water), filled = Math.floor(water / 250);
  const t = planDay.totals;
  const macroSegs = [{ label: 'Protein', value: t.p * 4, color: 'var(--mint-600)' }, { label: 'Carbs', value: t.c * 4, color: '#fbbf24' }, { label: 'Fat', value: t.f * 9, color: '#fb923c' }];
  const macroRows = [['Protein', t.p, targets.protein, eatenP, 'mint'], ['Carbs', t.c, targets.carbs, eatenC, 'amber'], ['Fat', t.f, targets.fat, eatenF, 'orange'], ['Fibre', t.fiber, targets.fiber, 0, 'blue']];
  return <>
    <PageHead eyebrow="YOUR PERSONALISED PLAN" title="Diet tracker" subtitle="No typing needed — your plan is built from your Health profile. Tick meals as you eat them and sip through the day."
      right={<div className="head-actions"><button className="btn btn-soft" onClick={() => actions.openModal('meal')}><Plus size={16} /> Add my own meal</button></div>} />
    <Card className="date-nav"><button className="icon-btn" aria-label="Previous day" onClick={() => setDateKey(addDays(dateKey, -1))} disabled={dateKey <= addDays(today, -60)}><ChevronLeft size={18} /></button>
      <div><strong>{pretty(dateKey, today)}</strong><small>{parseKey(dateKey).toLocaleDateString('en-IN', { dateStyle: 'long' })}</small></div>
      <button className="icon-btn" aria-label="Next day" onClick={() => setDateKey(addDays(dateKey, 1))} disabled={dateKey >= addDays(today, 6)}><ChevronRight size={18} /></button>
      {dateKey !== today && <button className="btn btn-soft btn-sm" onClick={() => setDateKey(today)}>Back to today</button>}</Card>
    {!targets.complete && <div className="alert alert-info"><Info size={15} /> This plan uses default targets. <button className="link" onClick={() => go('health')}>Add your {targets.missing.join(', ')}</button> to personalise calories, portions and water.</div>}
    <div className="grid g4 targets">
      <Card className="stat mini"><span>Calorie target</span><div className="stat-val">{n0(targets.calories)}<small>kcal</small></div><ProgressBar value={eaten} max={targets.calories} tone="orange" /><small>{n0(eaten)} eaten · plan {n0(t.kcal)}</small></Card>
      <Card className="stat mini"><span>Protein</span><div className="stat-val">{targets.protein}<small>g</small></div><ProgressBar value={eatenP} max={targets.protein} /><small>{Math.round(eatenP)} g eaten · plan {Math.round(t.p)} g</small></Card>
      <Card className="stat mini"><span>Water</span><div className="stat-val">{(targets.water / 1000).toFixed(2)}<small>L</small></div><ProgressBar value={water} max={targets.water} tone="blue" /><small>{(water / 1000).toFixed(2)} L · {filled}/{sched.length} glasses</small></Card>
      <Card className="stat mini"><span>Goal</span><div className="stat-val sm">{profile.goal}</div><small>{profile.dietaryPreference}{(profile.dietExtras || []).length ? ` · ${profile.dietExtras.length} extra` : ''}</small><small>{targets.source === 'custom' ? 'Custom targets' : targets.complete ? `BMR ${targets.bmr} · TDEE ${targets.tdee}` : 'Default targets'}</small></Card>
    </div>
    <div className="grid g-main">
      <div className="stack">
        {planDay.slots.map(s => { const Ico = SLOT_ICON[s.slot], done = tick(s.slot); return <Card key={s.slot} className={`meal-card ${done ? 'is-done' : ''}`}>
          <div className="meal-head"><i className="plan-ico big"><Ico size={20} /></i>
            <div><h3>{s.label}<Pill tone="gray"><Clock size={12} /> {s.time}</Pill></h3><small>{s.short} · aim for ≈ {s.targetKcal} kcal</small></div>
            <div className="meal-kcal"><strong>{s.kcal}</strong><small>kcal</small></div></div>
          {s.items.length ? <ul className="items">{s.items.map((i, k) => <li key={`${i.id}${k}`}><span className={`dot ${i.type}`} /><div><strong>{i.name}</strong><small>{i.type === 'meal' ? `${i.serving}${i.servings !== 1 ? ` × ${i.servings}` : ''} · ≈ ${i.grams} g` : `${i.serving}`}</small></div><em>{i.kcal} kcal</em></li>)}</ul>
            : <div className="alert alert-info">No meal matches all your diet settings for this slot. Relax an exclusion in your Health profile.</div>}
          <div className="macro-chips"><span>Protein <b>{s.p} g</b></span><span>Carbs <b>{s.c} g</b></span><span>Fat <b>{s.f} g</b></span><span>Fibre <b>{s.fiber} g</b></span></div>
          <div className="meal-actions">
            <button className={`btn ${done ? 'btn-done' : 'btn-primary'} btn-sm`} disabled={future || !s.items.length} onClick={() => actions.toggleSlot(dateKey, s.slot)}>{done ? <><Check size={15} /> Eaten — undo</> : <><Check size={15} /> Mark as eaten</>}</button>
            <button className="btn btn-soft btn-sm" onClick={() => actions.openModal('swap', { dateKey, slot: s.slot })}><Repeat size={15} /> Swap meal</button></div>
        </Card>; })}
        {extras.length > 0 && <Card><CardHead title="Other things you logged" subtitle="Items outside the plan count towards today's totals" />
          <ul className="items">{extras.map(e => <li key={e._id}><span className="dot side" /><div><strong>{e.name}</strong><small>{e.category || 'extra'} · P {Math.round(e.protein)} g · C {Math.round(e.carbs)} g · F {Math.round(e.fat)} g</small></div><em>{Math.round(e.calories)} kcal</em><button className="icon-btn" aria-label={`Delete ${e.name}`} onClick={() => actions.removeEntry(e._id)}><Trash2 size={15} /></button></li>)}</ul></Card>}
      </div>
      <div className="stack">
        <Card><CardHead title="Water plan" subtitle={`${sched.length} glasses · tap the next glass after you drink`} right={<Pill tone="blue">{(water / 1000).toFixed(2)} / {(targets.water / 1000).toFixed(2)} L</Pill>} />
          <div className="glasses">{sched.map((g, i) => <button key={i} type="button" className={`glass ${i < filled ? 'on' : ''}`} disabled={future || (i !== filled && i !== filled - 1)} aria-label={i < filled ? `Glass ${i + 1} drunk (tap to undo)` : `Drink glass ${i + 1}`} onClick={() => (i === filled ? actions.addWater(250, dateKey) : actions.undoWater(dateKey))}><Droplets size={16} /><b>{g.time}</b><small>{g.ml} ml</small></button>)}</div>
          <div className="water-actions"><button className="btn btn-soft btn-sm" disabled={future} onClick={() => actions.addWater(500, dateKey)}>+500 ml</button><button className="btn btn-soft btn-sm" disabled={future || !filled} onClick={() => actions.undoWater(dateKey)}>Undo last</button></div></Card>
        <Card><CardHead title="Nutrition breakdown" subtitle="Planned macros for the day" />
          <div className="donut-row"><Donut segments={macroSegs} size={150} thickness={22} center={n0(t.kcal)} sub="kcal planned" />
            <ul className="legend-list">{macroSegs.map(s => <li key={s.label}><i style={{ background: s.color }} />{s.label}<b>{Math.round((s.value / ((t.p * 4 + t.c * 4 + t.f * 9) || 1)) * 100)}%</b></li>)}</ul></div>
          <div className="macro-bars">{macroRows.map(([n, plan, tg, got, tone]) => <div key={n}><div className="split-label"><span>{n}</span><b>{Math.round(plan)} / {tg} g</b></div><ProgressBar value={plan} max={tg} tone={tone} thin /></div>)}</div></Card>
        <Card className="note"><strong><Sparkles size={15} /> Why this plan?</strong><p>Calories are {targets.source === 'custom' ? 'your custom target' : 'your BMR × activity ± goal'}, split 25% / 33% / 12% / 30% across the day. Meals respect your <b>{profile.dietaryPreference.toLowerCase()}</b> preference and favour protein and fibre for <b>{profile.goal.toLowerCase()}</b>.</p></Card>
      </div>
    </div>
  </>;
}
