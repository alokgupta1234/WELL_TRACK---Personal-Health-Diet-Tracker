import React from 'react';
import { ArrowRight, Check, HeartPulse, ShieldCheck, Sparkles, UserRound, KeyRound } from 'lucide-react';
import { DEMO_EMAIL, DEMO_PASSWORD } from '../../shared/demo.mjs';

export default function Login({ mode, setMode, form, setForm, submit, busy, error, notice, apiReady, useDemo }) {
  const title = { login: 'Welcome back', register: 'Create your account', forgot: 'Reset your password', reset: 'Choose a new password' }[mode];
  const sub = { login: 'Sign in to continue your wellness journey.', register: 'Start tracking your health in one simple place.', forgot: 'We will email a secure reset link if the account exists.', reset: 'Enter a new password for your account.' }[mode];
  return <div className="auth">
    <div className="auth-left">
      <div className="brand"><span className="brand-mark"><HeartPulse size={22} /></span><div><strong>welltrack</strong><small>PERSONAL HEALTH</small></div></div>
      <div className="auth-hero">
        <span className="eyebrow"><i /> YOUR HEALTH, IN ONE PLACE</span>
        <h1>Build healthier habits.<br /><em>One day at a time.</em></h1>
        <p>A personal diet and wellness companion: it reads your health profile, plans your meals, tracks your progress and answers your questions.</p>
        <ul>
          <li><span><Check size={14} /></span>Personalised daily meal plan with calories, macros and timings</li>
          <li><span><Check size={14} /></span>Food library that follows your diet and goal</li>
          <li><span><Check size={14} /></span>Progress insights and HealthMate, your nutrition assistant</li>
        </ul>
      </div>
      <div className="auth-rings" aria-hidden="true"><i /><i /></div>
      <small className="auth-foot">A little better, every day.</small>
    </div>
    <div className="auth-right">
      <form className="auth-card" onSubmit={submit}>
        <div className="auth-icon"><UserRound size={22} /></div>
        <h2>{title}</h2><p className="auth-sub">{sub}</p>
        {mode === 'login' && <div className="demo-box" data-testid="demo-box">
          <div className="demo-title"><Sparkles size={15} /> Try the live demo account</div>
          <dl><div><dt>Demo email</dt><dd>{DEMO_EMAIL}</dd></div><div><dt>Demo password</dt><dd>{DEMO_PASSWORD}</dd></div></dl>
          <button type="button" className="btn btn-soft" onClick={useDemo}><KeyRound size={15} /> Use demo credentials</button>
        </div>}
        {error && <div className="alert alert-bad">{error}</div>}
        {notice && <div className="alert alert-good">{notice}</div>}
        {!apiReady && <div className="alert alert-bad">The API is not reachable. Start MongoDB and the backend (<code>npm start</code> in /server) before signing in.</div>}
        {mode === 'register' && <label>Full name<input required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Your name" autoComplete="name" /></label>}
        {mode !== 'reset' && <label>Email address<input required type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} placeholder="you@example.com" autoComplete="email" /></label>}
        {mode !== 'forgot' && <label>{mode === 'reset' ? 'New password' : 'Password'}<input required type="password" minLength="8" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} placeholder="At least 8 characters" autoComplete={mode === 'login' ? 'current-password' : 'new-password'} /></label>}
        <button className="btn btn-primary btn-block" disabled={busy}>{busy ? 'Please wait…' : { login: 'Sign in', register: 'Create account', forgot: 'Send reset link', reset: 'Update password' }[mode]} <ArrowRight size={17} /></button>
        <div className="auth-links">
          {mode === 'login' ? <>Don't have an account? <button type="button" onClick={() => setMode('register')}>Create one</button></> : <button type="button" onClick={() => setMode('login')}>Back to sign in</button>}
          {mode === 'login' && <button type="button" onClick={() => setMode('forgot')}>Forgot password?</button>}
        </div>
        <div className="auth-privacy"><ShieldCheck size={14} /> Personal records are stored under your account.</div>
      </form>
      <small className="auth-foot-r">PERSONAL HEALTH &amp; DIET TRACKER · 2026</small>
    </div>
  </div>;
}
