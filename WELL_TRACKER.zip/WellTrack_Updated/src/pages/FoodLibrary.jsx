import React, { useMemo, useState } from 'react';
import { Info, Plus, Search, Sparkles, X } from 'lucide-react';
import { searchFoods, matchLabel, dietLabel } from '../../shared/engine.mjs';
import { Card, PageHead, Pill, DietDot, EmptyState, n0, cx } from '../ui.jsx';
import { CAT_ICON, FOOD_CATEGORIES } from '../meta.js';

const TAGS = ['Any', 'High protein', 'High fibre', 'Low calorie', 'Low carb', 'Low fat'];
const SORTS = [['match', 'Best match for me'], ['protein', 'Most protein'], ['calories', 'Fewest calories'], ['fibre', 'Most fibre'], ['name', 'Name A–Z']];
const PAGE = 24;
// mix categories round-robin so the default list is varied instead of 100 leafy greens in a row
const interleave = items => { const g = {}; items.forEach(f => (g[f.category] ||= []).push(f)); const keys = Object.keys(g).sort((a, b) => g[b][0].match.score - g[a][0].match.score); const out = []; for (let i = 0; out.length < items.length; i++) for (const k of keys) if (g[k][i]) out.push(g[k][i]); return out; };

function FoodCard({ f, onLog }) {
  const Ico = CAT_ICON[f.category] || Plus, p = f.per100, tone = f.match.score >= 70 ? 'mint' : f.match.score >= 55 ? 'blue' : f.match.score >= 40 ? 'amber' : 'gray';
  return <article className="food-card">
    <div className="food-top"><i className="food-ico"><Ico size={22} /></i><div className="food-title"><h4>{f.name}</h4><small><DietDot diet={f.diet} /> {dietLabel(f.diet)} · {f.category}</small></div><Pill tone={tone}>{f.match.score}%</Pill></div>
    <div className="food-kcal"><strong>{p.kcal}</strong><small>kcal / 100 g</small>{f.servingG ? <span>≈ {Math.round((p.kcal * f.servingG) / 100)} kcal per {f.servingG} g serving</span> : null}</div>
    <div className="macro-chips"><span>Protein <b>{p.p} g</b></span><span>Carbs <b>{p.c} g</b></span><span>Fat <b>{p.f} g</b></span><span>Fibre <b>{p.fiber} g</b></span></div>
    <div className="tag-row"><Pill tone={tone}>{matchLabel(f.match.score)}</Pill>{f.match.reasons.map(r => <Pill key={r} tone="gray">{r}</Pill>)}{f.score >= 8 && !f.match.reasons.includes('Nutrient-dense') && <Pill tone="gray">Health score {f.score}/10</Pill>}</div>
    <button className="btn btn-soft btn-block btn-sm" onClick={() => onLog(f)}><Plus size={15} /> Log this food</button>
  </article>;
}

export default function FoodLibrary({ app }) {
  const { foods, profile, foodQuery, setFoodQuery, actions } = app;
  const [category, setCategory] = useState('All'), [slot, setSlot] = useState('All'), [tag, setTag] = useState('Any'), [sort, setSort] = useState('match'), [mine, setMine] = useState(true), [shown, setShown] = useState(PAGE);
  const filtered = !(foodQuery || category !== 'All' || slot !== 'All' || tag !== 'Any');
  const res = useMemo(() => searchFoods(foods, profile, { query: foodQuery, category, slot, tag, sort, onlyMatching: mine, limit: 600 }), [foods, profile, foodQuery, category, slot, tag, sort, mine]);
  const top = useMemo(() => {
    if (!filtered) return [];
    const per = {}, out = [];
    for (const f of res.items) { per[f.category] = (per[f.category] || 0) + 1; if (per[f.category] <= 2 && f.match.score >= 60) out.push(f); if (out.length >= 6) break; }
    return out;
  }, [res, filtered]);
  const pref = profile.dietaryPreference, extras = (profile.dietExtras || []).length;
  const reset = () => { setFoodQuery(''); setCategory('All'); setSlot('All'); setTag('Any'); setSort('match'); setShown(PAGE); };
  const rest = filtered ? res.items.filter(f => !top.includes(f)) : res.items;
  const list = filtered && sort === 'match' ? interleave(rest) : rest;
  return <>
    <PageHead eyebrow="NUTRITION EXPLORER" title="Food library" subtitle="Foods from the nutrition dataset, ranked for your diet, goal and calorie needs." />
    <Card className="search-card"><Search size={18} /><input value={foodQuery} onChange={e => { setFoodQuery(e.target.value); setShown(PAGE); }} placeholder="Search foods, e.g. paneer, lentils, oats…" aria-label="Search foods" />{foodQuery && <button className="icon-btn" aria-label="Clear search" onClick={() => setFoodQuery('')}><X size={16} /></button>}<span className="count">{n0(res.total)} foods</span></Card>
    <Card className="filters">
      <label>Category<select value={category} onChange={e => { setCategory(e.target.value); setShown(PAGE); }}><option>All</option>{FOOD_CATEGORIES.map(c => <option key={c}>{c}</option>)}</select></label>
      <label>Meal<select value={slot} onChange={e => { setSlot(e.target.value); setShown(PAGE); }}><option value="All">Any meal</option><option value="breakfast">Breakfast</option><option value="lunch">Lunch</option><option value="snack">Snack</option><option value="dinner">Dinner</option></select></label>
      <label>Nutrition<select value={tag} onChange={e => { setTag(e.target.value); setShown(PAGE); }}>{TAGS.map(c => <option key={c} value={c}>{c === 'Any' ? 'Any nutrition' : c}</option>)}</select></label>
      <label>Sort by<select value={sort} onChange={e => setSort(e.target.value)}>{SORTS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></label>
      <div className="filter-pref"><strong>{pref}{extras ? ` + ${extras} exclusion${extras > 1 ? 's' : ''}` : ''}</strong><small>Goal: {profile.goal}</small>
        <button type="button" className={cx('chip', mine && 'on')} aria-pressed={mine} onClick={() => setMine(!mine)}>{mine ? 'Showing only foods that fit me' : 'Showing all diets'}</button></div>
    </Card>
    <div className="alert alert-info"><Info size={15} /> <span>Values are per 100 g, converted from the dataset's per-serving figures. Diet labels come from the food name and are best-effort — always check ingredients, especially for allergies.</span></div>
    {top.length > 0 && <><div className="section-title"><Sparkles size={16} /> Recommended for you <small>best matches for {profile.goal.toLowerCase()} · {pref.toLowerCase()}</small></div><div className="food-grid">{top.map(f => <FoodCard key={f.id} f={f} onLog={actions.logFood} />)}</div></>}
    {list.length === 0 && top.length === 0 ? <Card><EmptyState icon={Search} title="No foods match these filters" text={mine ? 'Try clearing a filter, or switch to "all diets".' : 'Try a different search.'} action={<button className="btn btn-soft" onClick={reset}>Clear filters</button>} /></Card>
      : <>{top.length > 0 && <div className="section-title">All foods <small>{n0(res.total)} results</small></div>}<div className="food-grid">{list.slice(0, shown).map(f => <FoodCard key={f.id} f={f} onLog={actions.logFood} />)}</div>
        {list.length > shown && <div className="center"><button className="btn btn-soft" onClick={() => setShown(shown + PAGE)}>Show more ({list.length - shown} left)</button></div>}</>}
  </>;
}
