import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Check, Printer, RefreshCw, Repeat, ShoppingBasket, Sparkles } from 'lucide-react';
import { buildWeekPlan, shoppingList, addDays, weekStart, parseKey } from '../../shared/engine.mjs';
import { Card, CardHead, PageHead, Pill, BarChart, n0, cx } from '../ui.jsx';
import { SLOT_ICON } from '../meta.js';

const fmt = (k, o) => parseKey(k).toLocaleDateString('en-IN', o);
const groceryKey = wk => `welltrack_grocery_${wk}`;
const loadChecked = wk => { try { return JSON.parse(localStorage.getItem(groceryKey(wk)) || '[]'); } catch { return []; } };

export default function MealPlanner({ app }) {
  const { profile, targets, planPrefs, today, entries, actions } = app;
  const [offset, setOffset] = useState(0);
  const anchor = addDays(today, offset * 7), wk = weekStart(anchor);
  const week = buildWeekPlan(profile, anchor, { seed: planPrefs.seed, picksByDate: planPrefs.picks });
  const [sel, setSel] = useState(() => (week.some(d => d.dateKey === today) ? today : week[0].dateKey));
  const [checked, setChecked] = useState(() => loadChecked(wk));
  const day = week.find(d => d.dateKey === sel) || week[0];
  const list = shoppingList(week);
  const avg = Math.round(week.reduce((a, d) => a + d.totals.kcal, 0) / 7), avgP = Math.round(week.reduce((a, d) => a + d.totals.p, 0) / 7);
  const eatenSlots = new Set(entries.filter(e => e.dateKey === day.dateKey && e.kind === 'meal' && e.mealRef).map(e => e.mealRef.split(':')[0]));
  const move = n => { const o = offset + n, k = weekStart(addDays(today, o * 7)); setOffset(o); setChecked(loadChecked(k)); setSel(o === 0 ? today : k); };
  const toggle = name => { const next = checked.includes(name) ? checked.filter(x => x !== name) : [...checked, name]; setChecked(next); try { localStorage.setItem(groceryKey(wk), JSON.stringify(next)); } catch { /* storage unavailable */ } };
  return <>
    <PageHead eyebrow="PERSONALISED NUTRITION" title="7-day meal planner" subtitle="Built from your Health profile and shared with your Diet tracker — swap any meal and it updates everywhere."
      right={<div className="head-actions"><button className="btn btn-soft" onClick={() => window.print()}><Printer size={16} /> Print plan</button><button className="btn btn-primary" onClick={() => actions.regenerateWeek(week.map(d => d.dateKey))}><RefreshCw size={16} /> Regenerate week</button></div>} />
    <div className="grid g3 planner-top">
      <Card className="stat mini"><span>Daily target</span><div className="stat-val">{n0(targets.calories)}<small>kcal</small></div><small>{profile.goal} · {profile.dietaryPreference}</small></Card>
      <Card className="stat mini"><span>Average planned day</span><div className="stat-val">{n0(avg)}<small>kcal</small></div><small>{avgP} g protein · target {targets.protein} g</small></Card>
      <Card className="stat mini"><span>Week</span><div className="week-nav"><button className="icon-btn" aria-label="Previous week" onClick={() => move(-1)} disabled={offset <= -1}><ChevronLeft size={17} /></button><strong>{fmt(wk, { day: 'numeric', month: 'short' })} – {fmt(addDays(wk, 6), { day: 'numeric', month: 'short' })}</strong><button className="icon-btn" aria-label="Next week" onClick={() => move(1)} disabled={offset >= 2}><ChevronRight size={17} /></button></div><small>{offset === 0 ? 'This week' : offset < 0 ? 'Previous week' : 'Upcoming week'}</small></Card>
    </div>
    <Card><CardHead title="Calories across the week" subtitle="Planned kcal per day against your target" />
      <BarChart labels={week.map(d => fmt(d.dateKey, { weekday: 'short' }))} values={week.map(d => d.totals.kcal)} goal={targets.calories} unit=" kcal" height={160} /></Card>
    <Card className="week-tabs"><div role="tablist" aria-label="Days of the week">{week.map(d => <button key={d.dateKey} role="tab" aria-selected={d.dateKey === sel} className={cx(d.dateKey === sel && 'on', d.dateKey === today && 'is-today')} onClick={() => setSel(d.dateKey)}><small>{fmt(d.dateKey, { weekday: 'short' })}</small><b>{parseKey(d.dateKey).getDate()}</b><span>{d.totals.kcal} kcal</span></button>)}</div></Card>
    <div className="grid g-main">
      <div className="stack">
        <Card><CardHead title={fmt(day.dateKey, { weekday: 'long', day: 'numeric', month: 'long' })} subtitle={`${day.totals.kcal} kcal · ${day.totals.p} g protein · ${day.totals.c} g carbs · ${day.totals.f} g fat`} right={<Pill tone={Math.abs(day.deltaKcal) <= targets.calories * 0.08 ? 'mint' : 'amber'}>{day.deltaKcal > 0 ? '+' : ''}{day.deltaKcal} kcal vs target</Pill>} />
          <ul className="planner-meals">{day.slots.map(s => { const Ico = SLOT_ICON[s.slot]; return <li key={s.slot}>
            <i className="plan-ico big"><Ico size={20} /></i>
            <div className="pm-body"><div className="pm-title"><strong>{s.label}</strong><small>{s.time}</small>{eatenSlots.has(s.slot) && <Pill><Check size={11} /> Eaten</Pill>}{s.userPicked && <Pill tone="blue">Your pick</Pill>}</div>
              <p>{s.items.map(i => i.name).join(' + ') || 'No suitable meal for your settings'}</p>
              <small>{s.items.map(i => i.type === 'meal' ? `${i.serving}${i.servings !== 1 ? ` × ${i.servings}` : ''}` : i.serving).join(' · ')}</small>
              <div className="macro-chips"><span>P <b>{s.p} g</b></span><span>C <b>{s.c} g</b></span><span>F <b>{s.f} g</b></span></div></div>
            <div className="pm-side"><strong>{s.kcal}</strong><small>kcal</small><button className="btn btn-soft btn-sm" onClick={() => actions.openModal('swap', { dateKey: day.dateKey, slot: s.slot })}><Repeat size={14} /> Swap</button></div></li>; })}</ul>
          <p className="muted small">Meal ideas are general wellness suggestions, not a clinical prescription. Adjust portions to your needs and seek a registered dietitian for medical diets or allergies.</p></Card>
      </div>
      <Card className="grocery"><CardHead title="Weekly prep checklist" subtitle="Dishes in this week's plan — tick them as you shop or prepare" right={<Pill><ShoppingBasket size={12} /> {checked.filter(c => list.some(l => l.name === c)).length}/{list.length}</Pill>} />
        <ul className="checklist">{list.map(g => <li key={g.name}><label><input type="checkbox" checked={checked.includes(g.name)} onChange={() => toggle(g.name)} /><span>{g.name}</span><em>×{g.count}</em></label></li>)}</ul></Card>
    </div>
  </>;
}
