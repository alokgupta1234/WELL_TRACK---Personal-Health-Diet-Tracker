import React, { useState } from 'react';
import { Activity, Award, Droplets, Flame, Flag, Lightbulb, Plus, Scale, Target, TrendingDown, TrendingUp, TriangleAlert, CircleCheck, Trophy } from 'lucide-react';
import { addDays, dailySeries, adherence, weekRings, parseKey, buildInsights, buildBadges, loggingStreak } from '../../shared/engine.mjs';
import { Card, CardHead, PageHead, Pill, ProgressBar, Sparkline, AreaChart, BarChart, Donut, Ring, n0, clamp } from '../ui.jsx';

const short = k => parseKey(k).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
const wd = k => ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'][parseKey(k).getDay()];

export default function Progress({ app }) {
  const { entries, targets, profile, today, actions, summary } = app;
  const [range, setRange] = useState(30);
  const from = addDays(today, -(range - 1));
  const series = dailySeries(entries, from, today);
  const stats = adherence(series, targets, targets.goal);
  const j = summary.journey;
  const labels = series.map(d => short(d.date));
  const calVals = series.map(d => (d.meals ? Math.round(d.calories) : null));
  const wVals = series.map(d => d.weight);
  const weightSeries = j.points.filter(p => p.date >= from);
  const streak = loggingStreak(summary.series30, today);
  const rings = weekRings(summary.series30, targets, today);
  const last = n => series.slice(-n);
  const macroKcal = { p: stats.avgProtein * 4, c: stats.avgCarbs * 4, f: stats.avgFat * 9 };
  const mTot = macroKcal.p + macroKcal.c + macroKcal.f;
  const segs = [{ label: 'Protein', value: macroKcal.p, color: 'var(--mint-600)' }, { label: 'Carbs', value: macroKcal.c, color: '#fbbf24' }, { label: 'Fat', value: macroKcal.f, color: '#fb923c' }];
  const dirLabel = j.direction === 'lose' ? 'lose' : j.direction === 'gain' ? 'gain' : 'maintain';
  const toward = j.changeKg != null ? (j.direction === 'lose' ? -j.changeKg : j.direction === 'gain' ? j.changeKg : -Math.abs(j.changeKg)) : null;
  const insights = buildInsights({ profile, targets, journey: j, stats7: summary.stats7, streak, todaySeries: summary.today });
  const badges = summary.badges;
  const sparkW = j.points.slice(-14).map(p => p.kg);
  return <>
    <PageHead eyebrow="YOUR CONSISTENCY, OVER TIME" title="Progress" subtitle="See where you started, where you are, and how close you are to your goal."
      right={<div className="head-actions"><div className="seg" role="tablist" aria-label="Range">{[7, 30, 90].map(r => <button key={r} role="tab" aria-selected={range === r} className={range === r ? 'on' : ''} onClick={() => setRange(r)}>{r}d</button>)}</div><button className="btn btn-primary" onClick={() => actions.openModal('weight')}><Plus size={16} /> Record weight</button></div>} />
    <div className="grid g4">
      <Card className="kpi kpi-hero"><div className="stat-top"><span>Weight change</span><i className="stat-ico"><Scale size={18} /></i></div>
        <div className="stat-val">{j.changeKg != null ? `${j.changeKg > 0 ? '+' : ''}${j.changeKg}` : '—'}<small>kg</small></div>
        <Sparkline values={sparkW} color="#fff" />
        <small>{j.start && j.current ? `${j.start} kg → ${j.current} kg` : 'Record your weight to start'}</small></Card>
      <Card className="kpi"><div className="stat-top"><span>Avg daily calories</span><i className="stat-ico ico-orange"><Flame size={18} /></i></div>
        <div className="stat-val">{n0(stats.avgCalories)}<small>kcal</small></div>
        <Sparkline values={series.slice(-14).map(d => d.calories || null)} color="#fb923c" />
        <small>Target {n0(targets.calories)} kcal · {stats.onTargetDays}/{stats.days} days on target</small></Card>
      <Card className="kpi"><div className="stat-top"><span>Goal completion</span><i className="stat-ico ico-mint"><Target size={18} /></i></div>
        <div className="stat-val">{j.pct != null ? `${j.pct}` : '—'}<small>%</small></div>
        <ProgressBar value={j.pct || 0} />
        <small>{j.target ? (j.reached ? `Target ${j.target} kg reached 🎉` : `${j.remaining} kg to go to ${j.target} kg`) : 'Set a target weight in Health profile'}</small></Card>
      <Card className="kpi"><div className="stat-top"><span>Consistency score</span><i className="stat-ico ico-blue"><Award size={18} /></i></div>
        <div className="kpi-ring"><Ring pct={stats.score / 100} size={74} stroke={8}>{stats.score}</Ring><div><strong>{stats.score >= 75 ? 'Excellent' : stats.score >= 50 ? 'Good' : 'Building up'}</strong><small>last {range} days</small></div></div>
        <small>{streak}-day logging streak</small></Card>
    </div>
    <div className="grid g-main">
      <Card><CardHead title="Weight journey" subtitle={j.target ? `Start ${j.start ?? '—'} kg · now ${j.current ?? '—'} kg · target ${j.target} kg` : 'Your logged weights'} right={j.ratePerWeek != null ? <Pill tone={toward > 0 ? 'mint' : 'amber'}>{j.ratePerWeek > 0 ? '+' : ''}{j.ratePerWeek} kg/week</Pill> : null} />
        <AreaChart labels={labels} height={250} unit=" kg" formatY={v => v}
          series={[{ name: 'Weight', color: 'var(--mint-600)', values: wVals, dots: true }, ...(j.target ? [{ name: 'Target', color: '#f59e0b', values: labels.map(() => j.target), dashed: true, area: false }] : [])]}
          emptyText="Record your weight to see your journey" />
        <div className="timeline"><div><small>Started</small><strong>{j.start ?? '—'} kg</strong><span>{j.startDate ? short(j.startDate) : ''}</span></div>
          <div className="timeline-bar"><ProgressBar value={j.pct || 0} /><b>{j.pct != null ? `${j.pct}% of the way` : ''}</b></div>
          <div><small>Now</small><strong>{j.current ?? '—'} kg</strong><span>{j.etaWeeks ? `≈ ${j.etaWeeks} wk to target` : ''}</span></div>
          <div><small>Goal ({dirLabel})</small><strong>{j.target ?? '—'} kg</strong><span>{j.remaining != null ? `${j.remaining} kg to go` : ''}</span></div></div></Card>
      <Card><CardHead title="Macronutrient balance" subtitle={`Average of logged days · last ${range} days`} />
        {mTot > 0 ? <><div className="donut-center-wrap"><Donut segments={segs} size={190} thickness={28} center={n0(stats.avgCalories)} sub="avg kcal" /></div>
          <ul className="macro-legend">{[['Protein', stats.avgProtein, targets.protein, segs[0].color], ['Carbs', stats.avgCarbs, targets.carbs, segs[1].color], ['Fat', stats.avgFat, targets.fat, segs[2].color]].map(([n, a, tg, c]) => <li key={n}><i style={{ background: c }} /><span>{n}</span><b>{a} / {tg} g</b></li>)}</ul></>
          : <div className="chart-empty">Tick meals in the Diet tracker to see your macros</div>}</Card>
    </div>
    <div className="grid g-main">
      <Card><CardHead title="Calorie intake vs goal" subtitle={`Last ${range} days · kcal logged`} right={<Pill>{stats.calPct}% days on target</Pill>} />
        <AreaChart labels={labels} height={240} unit=" kcal" formatY={v => n0(v)} yMin={0}
          series={[{ name: 'Calories', color: '#fb923c', values: calVals }, { name: 'Goal', color: '#f59e0b', values: labels.map(() => targets.calories), dashed: true, area: false }]} emptyText="No meals logged in this period" /></Card>
      <Card><CardHead title="This week" subtitle="Daily calories vs target" right={<Pill tone="orange"><Flame size={12} /> {streak} day streak</Pill>} />
        <div className="week-rings">{rings.map(r => <div key={r.date} className={r.isToday ? 'today' : ''}><small>{r.label}</small><Ring pct={r.future ? 0 : r.pct} size={46} stroke={5} tone={r.pct >= 0.9 && r.pct <= 1.1 ? 'var(--mint-600)' : r.pct > 1.1 ? '#fb923c' : 'var(--mint-400)'}>{r.day}</Ring></div>)}</div>
        <div className="adh">{[['Calories on target', stats.calPct, 'orange'], ['Hydration', stats.waterPct, 'blue'], ['Activity (150 min/wk)', stats.actPct, 'mint'], ['Meals logged', stats.logPct, 'amber']].map(([n, v, tone]) => <div key={n}><div className="split-label"><span>{n}</span><b>{v}%</b></div><ProgressBar value={v} tone={tone} thin /></div>)}</div></Card>
    </div>
    <div className="grid g3">
      <Card><CardHead title="Water intake" subtitle="ml per day" right={<Pill tone="blue">{stats.waterDays} goal days</Pill>} /><BarChart labels={last(range === 7 ? 7 : 14).map(d => wd(d.date))} values={last(range === 7 ? 7 : 14).map(d => d.water)} goal={targets.water} color="#7dd3fc" unit=" ml" width={300} height={190} /></Card>
      <Card><CardHead title="Active minutes" subtitle="min per day" right={<Pill>{stats.totalActivity} min total</Pill>} /><BarChart labels={last(range === 7 ? 7 : 14).map(d => wd(d.date))} values={last(range === 7 ? 7 : 14).map(d => d.activity)} goal={30} color="var(--mint-400)" unit=" min" width={300} height={190} /></Card>
      <Card><CardHead title="Protein" subtitle="g per day vs goal" right={<Pill tone="amber">avg {stats.avgProtein} g</Pill>} /><BarChart labels={last(range === 7 ? 7 : 14).map(d => wd(d.date))} values={last(range === 7 ? 7 : 14).map(d => Math.round(d.protein))} goal={targets.protein} color="#fcd34d" unit=" g" width={300} height={190} /></Card>
    </div>
    <div className="grid g-main">
      <Card><CardHead title="Insights for you" subtitle="Generated from your logs" right={<Lightbulb size={18} className="muted-ico" />} />
        <ul className="insights">{insights.map((i, k) => <li key={k} className={`tone-${i.tone}`}>{i.tone === 'good' ? <CircleCheck size={17} /> : i.tone === 'warn' ? <TriangleAlert size={17} /> : <Lightbulb size={17} />}<span>{i.text}</span></li>)}</ul></Card>
      <Card><CardHead title="Achievements" subtitle={`${badges.filter(b => b.earned).length} of ${badges.length} earned`} right={<Trophy size={18} className="muted-ico" />} />
        <div className="badges">{badges.map(b => <div key={b.id} className={`badge ${b.earned ? 'on' : ''}`}><i>{b.earned ? <Award size={18} /> : <Flag size={18} />}</i><div><strong>{b.title}</strong><small>{b.desc}</small></div></div>)}</div></Card>
    </div>
    <p className="muted small">Scores count a day as on target when calories are within your goal's range (about 90–110% to maintain, 80–105% to lose, 92–120% to gain), water is at 90%+ of goal, and you reach 150 active minutes a week. They describe your habits — they are not medical advice.</p>
  </>;
}
