import React, { useState } from 'react';
import { Check, Repeat } from 'lucide-react';
import { alternativesFor, foodAtGrams, addDays, parseKey, planForDate, dietLabel, SLOT_META, todayKey } from '../shared/engine.mjs';
import { Modal, DietDot, Pill, n0 } from './ui.jsx';
import { ACTIVITY_PRESETS } from './meta.js';

export function ActivityModal({ onClose, onSave }) {
  const [type, setType] = useState('Walking'), [min, setMin] = useState(30);
  return <Modal title="Log activity" onClose={onClose}><form className="modal-form" onSubmit={e => { e.preventDefault(); onSave({ name: type, amount: Number(min) }); }}>
    <label>Activity<select value={type} onChange={e => setType(e.target.value)}>{ACTIVITY_PRESETS.map(a => <option key={a}>{a}</option>)}</select></label>
    <label>Duration<span className="input-unit"><input type="number" min="1" max="600" required value={min} onChange={e => setMin(e.target.value)} /><em>minutes</em></span></label>
    <button className="btn btn-primary btn-block">Save activity</button></form></Modal>;
}

export function WeightModal({ onClose, onSave, current }) {
  const [kg, setKg] = useState(current || ''), [date, setDate] = useState(todayKey());
  return <Modal title="Record weight" onClose={onClose}><form className="modal-form" onSubmit={e => { e.preventDefault(); onSave(Number(kg), date); }}>
    <label>Weight<span className="input-unit"><input type="number" min="20" max="400" step="0.1" required autoFocus value={kg} onChange={e => setKg(e.target.value)} /><em>kg</em></span></label>
    <label>Date<input type="date" required max={todayKey()} value={date} onChange={e => setDate(e.target.value)} /></label>
    <p className="muted small">Weighing once a week at the same time of day gives the clearest trend. Today's weight also updates your profile, BMI and daily targets.</p>
    <button className="btn btn-primary btn-block">Save weight</button></form></Modal>;
}

export function MealModal({ onClose, onSave, dateKey }) {
  const [f, setF] = useState({ name: '', calories: '', protein: '', carbs: '', fat: '', category: 'snack' });
  const set = (k, v) => setF(x => ({ ...x, [k]: v }));
  return <Modal title="Add my own meal" onClose={onClose}><form className="modal-form" onSubmit={e => { e.preventDefault(); onSave({ ...f, dateKey }); }}>
    <label>What did you eat?<input required maxLength={100} value={f.name} onChange={e => set('name', e.target.value)} placeholder="e.g. Samosa (1 piece)" autoFocus /></label>
    <div className="form-grid">
      <label>Meal<select value={f.category} onChange={e => set('category', e.target.value)}>{Object.entries(SLOT_META).map(([k, m]) => <option key={k} value={k}>{m.label}</option>)}</select></label>
      <label>Calories<span className="input-unit"><input type="number" min="0" max="5000" required value={f.calories} onChange={e => set('calories', e.target.value)} /><em>kcal</em></span></label>
      <label>Protein<span className="input-unit"><input type="number" min="0" step="0.1" value={f.protein} onChange={e => set('protein', e.target.value)} /><em>g</em></span></label>
      <label>Carbs<span className="input-unit"><input type="number" min="0" step="0.1" value={f.carbs} onChange={e => set('carbs', e.target.value)} /><em>g</em></span></label>
      <label>Fat<span className="input-unit"><input type="number" min="0" step="0.1" value={f.fat} onChange={e => set('fat', e.target.value)} /><em>g</em></span></label>
    </div>
    <p className="muted small">Tip: you can also add a food with exact nutrition from the Food library.</p>
    <button className="btn btn-primary btn-block">Add meal</button></form></Modal>;
}

export function SwapModal({ onClose, onPick, ctx }) {
  const { profile, targets, planPrefs, dateKey, slot } = ctx;
  const day = planForDate(profile, dateKey, { seed: planPrefs.seed, picksByDate: planPrefs.picks });
  const cur = day.slots.find(s => s.slot === slot);
  const alts = alternativesFor(profile, slot, targets.slotKcal[slot], cur?.mealId, 8);
  return <Modal title={`Swap ${SLOT_META[slot].label.toLowerCase()}`} onClose={onClose} wide>
    <p className="muted">{parseKey(dateKey).toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })} · target ≈ {targets.slotKcal[slot]} kcal · matches your {profile.dietaryPreference.toLowerCase()} preference</p>
    {cur?.items[0] && <div className="swap-current"><Pill>Current</Pill> <strong>{cur.items[0].name}</strong> <small>{cur.kcal} kcal</small></div>}
    {alts.length === 0 ? <p className="alert alert-info">No other meals match your diet settings for this slot.</p> :
      <ul className="swap-list">{alts.map(a => <li key={a.mealId}><div><strong>{a.name}</strong><small><DietDot diet={a.items[0].diet} /> {dietLabel(a.items[0].diet)} · {a.items.map(i => i.type === 'meal' ? `${i.serving}${i.servings !== 1 ? ` × ${i.servings}` : ''}` : i.serving).join(' + ')}</small>
        <div className="macro-chips"><span><b>{a.kcal}</b> kcal</span><span>P <b>{a.p} g</b></span><span>C <b>{a.c} g</b></span><span>F <b>{a.f} g</b></span></div></div>
        <button className="btn btn-primary btn-sm" onClick={() => onPick(a.mealId)}><Repeat size={14} /> Use this</button></li>)}</ul>}
  </Modal>;
}

export function LogFoodModal({ onClose, onSave, food, today }) {
  const hr = new Date().getHours(), defSlot = hr < 11 ? 'breakfast' : hr < 16 ? 'lunch' : hr < 19 ? 'snack' : 'dinner';
  const [grams, setGrams] = useState(Math.min(500, Math.max(10, food.servingG || 100))), [slot, setSlot] = useState(defSlot), [date, setDate] = useState(today);
  const calc = foodAtGrams(food, Number(grams) || 0);
  return <Modal title="Log this food" onClose={onClose}><form className="modal-form" onSubmit={e => { e.preventDefault(); onSave({ food, grams: Number(grams), slot, dateKey: date, calc }); }}>
    <div className="swap-current"><strong>{food.name}</strong> <small>{food.per100.kcal} kcal per 100 g</small></div>
    <div className="form-grid">
      <label>Amount<span className="input-unit"><input type="number" min="5" max="1500" step="5" required value={grams} onChange={e => setGrams(e.target.value)} /><em>g</em></span></label>
      <label>Meal<select value={slot} onChange={e => setSlot(e.target.value)}>{Object.entries(SLOT_META).map(([k, m]) => <option key={k} value={k}>{m.label}</option>)}</select></label>
      <label className="span2">Day<select value={date} onChange={e => setDate(e.target.value)}>{[0, -1, -2, -3].map(o => { const k = addDays(today, o); return <option key={k} value={k}>{o === 0 ? 'Today' : o === -1 ? 'Yesterday' : parseKey(k).toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'short' })}</option>; })}</select></label>
    </div>
    {calc && <div className="macro-chips big"><span><b>{n0(calc.kcal)}</b> kcal</span><span>Protein <b>{calc.p} g</b></span><span>Carbs <b>{calc.c} g</b></span><span>Fat <b>{calc.f} g</b></span></div>}
    <button className="btn btn-primary btn-block"><Check size={16} /> Add to my log</button></form></Modal>;
}
