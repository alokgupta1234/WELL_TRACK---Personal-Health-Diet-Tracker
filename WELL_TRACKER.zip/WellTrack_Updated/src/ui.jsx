import React, { useState, useEffect } from 'react';
import { X, Check } from 'lucide-react';

export const n0 = v => Math.round(Number(v) || 0).toLocaleString('en-IN');
export const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
export const cx = (...a) => a.filter(Boolean).join(' ');

export function Card({ className = '', children, ...rest }) { return <section className={cx('card', className)} {...rest}>{children}</section>; }
export function CardHead({ title, subtitle, right }) {
  return <div className="card-head"><div><h3>{title}</h3>{subtitle && <p>{subtitle}</p>}</div>{right && <div className="card-head-right">{right}</div>}</div>;
}
export function PageHead({ title, subtitle, right, eyebrow }) {
  return <div className="page-head"><div>{eyebrow && <span className="eyebrow">{eyebrow}</span>}<h1>{title}</h1>{subtitle && <p>{subtitle}</p>}</div>{right && <div className="page-head-right">{right}</div>}</div>;
}
export function Pill({ children, tone = 'mint', className = '' }) { return <span className={cx('pill', `pill-${tone}`, className)}>{children}</span>; }
export function EmptyState({ icon: Icon, title, text, action }) {
  return <div className="empty">{Icon && <div className="empty-icon"><Icon size={22} /></div>}<strong>{title}</strong>{text && <p>{text}</p>}{action}</div>;
}
export function Modal({ title, onClose, children, wide }) {
  useEffect(() => { const h = e => e.key === 'Escape' && onClose(); window.addEventListener('keydown', h); return () => window.removeEventListener('keydown', h); }, [onClose]);
  return <div className="modal-scrim" onMouseDown={e => e.target === e.currentTarget && onClose()}><div className={cx('modal', wide && 'modal-wide')} role="dialog" aria-modal="true" aria-label={title}>
    <div className="modal-head"><h3>{title}</h3><button type="button" className="icon-btn" onClick={onClose} aria-label="Close"><X size={18} /></button></div>{children}</div></div>;
}
export function ProgressBar({ value, max = 100, tone = 'mint', thin }) {
  const pct = clamp(max ? (value / max) * 100 : 0, 0, 100);
  return <div className={cx('bar', thin && 'bar-thin')}><i className={`bar-${tone}`} style={{ width: `${pct}%` }} /></div>;
}
export function DietDot({ diet }) {
  const veg = diet === 'vegan' || diet === 'veg';
  const label = { vegan: 'Vegan', veg: 'Vegetarian', egg: 'Contains egg', fish: 'Contains fish', nonveg: 'Non-vegetarian' }[diet] || diet;
  return <span className={cx('diet-dot', veg ? 'is-veg' : 'is-non')} title={label} aria-label={label}><i /></span>;
}
export function Toggle({ checked, onChange, label }) {
  return <button type="button" role="switch" aria-checked={checked} className={cx('switch', checked && 'on')} onClick={() => onChange(!checked)}><i />{label && <span>{label}</span>}</button>;
}
export function Stepper({ steps, current }) { return <div className="stepper">{steps.map((s, i) => <span key={s} className={cx(i <= current && 'on')}>{i < current ? <Check size={12} /> : i + 1} {s}</span>)}</div>; }

/* ───────────── charts (plain SVG) ───────────── */
function smooth(points) {
  if (points.length < 2) return points.length ? `M${points[0][0]},${points[0][1]}` : '';
  let d = `M${points[0][0]},${points[0][1]}`;
  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[i - 1] || points[i], p1 = points[i], p2 = points[i + 1], p3 = points[i + 2] || p2, t = 0.18;
    d += ` C${p1[0] + (p2[0] - p0[0]) * t},${p1[1] + (p2[1] - p0[1]) * t} ${p2[0] - (p3[0] - p1[0]) * t},${p2[1] - (p3[1] - p1[1]) * t} ${p2[0]},${p2[1]}`;
  }
  return d;
}
export function Sparkline({ values = [], color = 'var(--mint-600)', height = 46, width = 120, fill = true }) {
  const v = values.filter(x => x != null && Number.isFinite(x));
  if (v.length < 2) return <svg className="spark" viewBox={`0 0 ${width} ${height}`} aria-hidden="true"><path d={`M2,${height - 6} H${width - 2}`} stroke="var(--line)" strokeWidth="2" strokeDasharray="3 5" fill="none" /></svg>;
  const lo = Math.min(...v), hi = Math.max(...v), span = hi - lo || 1;
  const pts = v.map((x, i) => [2 + (i * (width - 4)) / (v.length - 1), 4 + (height - 10) * (1 - (x - lo) / span)]);
  const line = smooth(pts), id = `sp${Math.abs(Math.round(v[0] * 7 + v.length * 13 + hi * 3))}`;
  return <svg className="spark" viewBox={`0 0 ${width} ${height}`} aria-hidden="true">
    <defs><linearGradient id={id} x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor={color} stopOpacity=".28" /><stop offset="1" stopColor={color} stopOpacity="0" /></linearGradient></defs>
    {fill && <path d={`${line} L${pts[pts.length - 1][0]},${height} L${pts[0][0]},${height} Z`} fill={`url(#${id})`} />}
    <path d={line} fill="none" stroke={color} strokeWidth="2.2" strokeLinecap="round" />
    <circle cx={pts[pts.length - 1][0]} cy={pts[pts.length - 1][1]} r="3.4" fill="#fff" stroke={color} strokeWidth="2" />
  </svg>;
}

export function AreaChart({ labels = [], series = [], height = 260, formatY = v => v, yMin, yMax, unit = '', ticks = 4, emptyText = 'No data yet' }) {
  const [hover, setHover] = useState(null);
  const W = 820, H = height, pad = { l: 46, r: 14, t: 14, b: 28 };
  const vals = series.flatMap(s => s.values.filter(v => v != null && Number.isFinite(v)));
  if (!labels.length || !vals.length) return <div className="chart-empty" style={{ height }}>{emptyText}</div>;
  let lo = yMin ?? Math.min(...vals), hi = yMax ?? Math.max(...vals);
  if (yMin == null) lo -= (hi - lo) * 0.08 || 1; if (yMax == null) hi += (hi - lo) * 0.08 || 1;
  if (lo === hi) { lo -= 1; hi += 1; }
  const iw = W - pad.l - pad.r;
  const x = i => pad.l + (labels.length === 1 ? iw / 2 : (i * iw) / (labels.length - 1));
  const y = v => pad.t + (H - pad.t - pad.b) * (1 - (v - lo) / (hi - lo));
  const grid = Array.from({ length: ticks + 1 }, (_, i) => lo + ((hi - lo) * i) / ticks);
  const every = Math.max(1, Math.ceil(labels.length / 7));
  const move = e => { const r = e.currentTarget.getBoundingClientRect(); const rel = ((e.clientX - r.left) / r.width) * W; setHover(clamp(Math.round(((rel - pad.l) / iw) * (labels.length - 1)), 0, labels.length - 1)); };
  return <div className="chart-wrap">
    <svg className="chart" viewBox={`0 0 ${W} ${H}`} role="img" onMouseMove={move} onMouseLeave={() => setHover(null)}>
      <defs>{series.map((s, i) => <linearGradient key={i} id={`ag${i}-${s.name}`} x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor={s.color} stopOpacity=".26" /><stop offset="1" stopColor={s.color} stopOpacity="0" /></linearGradient>)}</defs>
      {grid.map((g, i) => <g key={i}><line x1={pad.l} x2={W - pad.r} y1={y(g)} y2={y(g)} stroke="var(--line)" strokeDasharray="4 6" /><text x={pad.l - 8} y={y(g) + 4} textAnchor="end" className="axis">{formatY(Math.round(g * 10) / 10)}</text></g>)}
      {labels.map((l, i) => i % every === 0 && <text key={i} x={x(i)} y={H - 8} textAnchor="middle" className="axis">{l}</text>)}
      {series.map((s, si) => {
        const pts = s.values.map((v, i) => (v == null ? null : [x(i), y(v)])).filter(Boolean);
        if (!pts.length) return null;
        const d = smooth(pts);
        return <g key={si}>
          {s.area !== false && pts.length > 1 && <path d={`${d} L${pts[pts.length - 1][0]},${H - pad.b} L${pts[0][0]},${H - pad.b} Z`} fill={`url(#ag${si}-${s.name})`} />}
          <path d={d} fill="none" stroke={s.color} strokeWidth={s.dashed ? 2 : 2.8} strokeDasharray={s.dashed ? '7 6' : undefined} strokeLinecap="round" />
          {s.dots && pts.map((p, i) => <circle key={i} cx={p[0]} cy={p[1]} r="3.6" fill="#fff" stroke={s.color} strokeWidth="2" />)}
        </g>;
      })}
      {hover != null && <g><line x1={x(hover)} x2={x(hover)} y1={pad.t} y2={H - pad.b} stroke="var(--ink-300)" strokeDasharray="3 4" />
        {series.map((s, si) => s.values[hover] != null && <circle key={si} cx={x(hover)} cy={y(s.values[hover])} r="5" fill="#fff" stroke={s.color} strokeWidth="2.5" />)}</g>}
    </svg>
    {hover != null && <div className="tooltip" style={{ left: `${clamp((x(hover) / W) * 100, 14, 86)}%` }}>
      <b>{labels[hover]}</b>{series.map((s, si) => <div key={si}><i style={{ background: s.color }} />{s.name}<strong>{s.values[hover] == null ? '—' : `${formatY(Math.round(s.values[hover] * 10) / 10)}${unit}`}</strong></div>)}
    </div>}
    {series.length > 1 && <div className="legend">{series.map(s => <span key={s.name}><i style={{ background: s.color }} />{s.name}</span>)}</div>}
  </div>;
}

export function BarChart({ labels = [], values = [], goal, color = 'var(--mint-500)', height = 170, width = 520, unit = '', format = v => n0(v), emptyText = 'No data yet' }) {
  const W = width, H = height, pad = { l: 8, r: 8, t: 14, b: 24 };
  const max = Math.max(goal || 0, ...values, 1) * 1.1;
  if (!labels.length) return <div className="chart-empty" style={{ height }}>{emptyText}</div>;
  const bw = (W - pad.l - pad.r) / labels.length, every = Math.max(1, Math.ceil(labels.length / 8));
  const y = v => pad.t + (H - pad.t - pad.b) * (1 - v / max);
  return <svg className="chart" viewBox={`0 0 ${W} ${H}`} role="img">
    {goal ? <g><line x1={pad.l} x2={W - pad.r} y1={y(goal)} y2={y(goal)} stroke="var(--amber-500)" strokeDasharray="5 5" /><text x={W - pad.r} y={y(goal) - 4} textAnchor="end" className="axis">goal {format(goal)}{unit}</text></g> : null}
    {values.map((v, i) => { const h = Math.max(v > 0 ? 3 : 0, (H - pad.t - pad.b) * (v / max)); return <g key={i}><title>{`${labels[i]}: ${format(v)}${unit}`}</title>
      <rect x={pad.l + i * bw + bw * 0.18} y={H - pad.b - h} width={bw * 0.64} height={h} rx={Math.min(7, bw * 0.3)} fill={goal && v >= goal ? 'var(--mint-600)' : color} opacity={v ? 1 : 0.2} />
      {i % every === 0 && <text x={pad.l + i * bw + bw / 2} y={H - 7} textAnchor="middle" className="axis">{labels[i]}</text>}</g>; })}
  </svg>;
}

export function Donut({ segments = [], size = 190, thickness = 26, center, sub }) {
  const total = segments.reduce((a, s) => a + s.value, 0) || 1, r = (size - thickness) / 2, c = 2 * Math.PI * r;
  let acc = 0;
  return <div className="donut" style={{ width: size, height: size }}>
    <svg viewBox={`0 0 ${size} ${size}`} role="img"><circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--mint-50)" strokeWidth={thickness} />
      {total > 0 && segments.map((s, i) => { const len = (s.value / total) * c, off = acc; acc += len; return <circle key={i} cx={size / 2} cy={size / 2} r={r} fill="none" stroke={s.color} strokeWidth={thickness} strokeDasharray={`${Math.max(0, len - 3)} ${c - Math.max(0, len - 3)}`} strokeDashoffset={-off} transform={`rotate(-90 ${size / 2} ${size / 2})`} strokeLinecap="butt"><title>{`${s.label}: ${Math.round((s.value / total) * 100)}%`}</title></circle>; })}
    </svg><div className="donut-center"><strong>{center}</strong>{sub && <span>{sub}</span>}</div></div>;
}

export function SegGauge({ value = 0, size = 190, ticks = 38, label, sub }) {
  const filled = Math.round((clamp(value, 0, 100) / 100) * ticks), cx0 = size / 2, cy0 = size * 0.58, r1 = size * 0.46, r2 = size * 0.36;
  const start = 210, sweep = 240;
  return <div className="gauge" style={{ width: size, height: size * 0.78 }}>
    <svg viewBox={`0 0 ${size} ${size * 0.78}`} role="img" aria-label={`${Math.round(value)} percent`}>
      {Array.from({ length: ticks }, (_, i) => { const a = ((start + (sweep * i) / (ticks - 1)) * Math.PI) / 180; return <line key={i} x1={cx0 + r2 * Math.cos(a)} y1={cy0 + r2 * Math.sin(a)} x2={cx0 + r1 * Math.cos(a)} y2={cy0 + r1 * Math.sin(a)} stroke={i < filled ? 'var(--mint-500)' : 'var(--ink-100)'} strokeWidth={size * 0.026} strokeLinecap="round" />; })}
    </svg><div className="gauge-center"><strong>{label}</strong>{sub && <span>{sub}</span>}</div></div>;
}

export function Ring({ pct = 0, size = 44, stroke = 5, tone = 'var(--mint-500)', children }) {
  const r = (size - stroke) / 2, c = 2 * Math.PI * r, p = clamp(pct, 0, 1);
  return <span className="ring" style={{ width: size, height: size }}><svg viewBox={`0 0 ${size} ${size}`}><circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--ink-100)" strokeWidth={stroke} />
    <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={tone} strokeWidth={stroke} strokeLinecap="round" strokeDasharray={`${c * p} ${c}`} transform={`rotate(-90 ${size / 2} ${size / 2})`} /></svg><b>{children}</b></span>;
}

/* ───────────── chat rich text (**bold**, _italic_, "- " bullets) ───────────── */
function inline(s, k) {
  return s.split(/(\*\*[^*]+\*\*|_[^_]+_)/g).filter(x => x !== '').map((part, i) => part.startsWith('**') ? <strong key={`${k}${i}`}>{part.slice(2, -2)}</strong> : part.startsWith('_') && part.endsWith('_') && part.length > 2 ? <em key={`${k}${i}`}>{part.slice(1, -1)}</em> : <React.Fragment key={`${k}${i}`}>{part}</React.Fragment>);
}
export function Rich({ text = '' }) {
  const out = []; let list = [];
  const flush = () => { if (list.length) { out.push(<ul key={`u${out.length}`}>{list.map((l, i) => <li key={i}>{inline(l, `l${i}`)}</li>)}</ul>); list = []; } };
  text.split('\n').forEach((line, i) => {
    if (/^\s*[-•]\s+/.test(line)) list.push(line.replace(/^\s*[-•]\s+/, ''));
    else { flush(); if (line.trim()) out.push(<p key={`p${i}`}>{inline(line, `p${i}`)}</p>); }
  });
  flush();
  return <div className="rich">{out}</div>;
}
