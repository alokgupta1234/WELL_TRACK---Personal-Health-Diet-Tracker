import React, { useEffect, useMemo, useState } from 'react';
import { Bell, HeartPulse, LogOut, Menu, Search, CalendarDays, Sparkles, TriangleAlert, Check } from 'lucide-react';
import { request } from './api.js';
import { computeTargets, summarize, planForDate, todayKey, addDays, SLOT_META } from '../shared/engine.mjs';
import { DEMO_EMAIL, DEMO_PASSWORD } from '../shared/demo.mjs';
import { NAV } from './meta.js';
import { Modal } from './ui.jsx';
import { ActivityModal, WeightModal, MealModal, SwapModal, LogFoodModal } from './Modals.jsx';
import Login from './pages/Login.jsx';
import Dashboard from './pages/Dashboard.jsx';
import HealthProfile from './pages/HealthProfile.jsx';
import DietTracker from './pages/DietTracker.jsx';
import Progress from './pages/Progress.jsx';
import FoodLibrary from './pages/FoodLibrary.jsx';
import MealPlanner from './pages/MealPlanner.jsx';
import Reports from './pages/Reports.jsx';
import HealthMate from './pages/HealthMate.jsx';

export const initialProfile = { age: '', gender: 'Prefer not to say', heightCm: '', weightKg: '', targetWeightKg: '', activityLevel: 'Moderately active', dietaryPreference: 'No preference', goal: 'Maintain weight', calorieGoal: 2000, waterGoalMl: 2000, customTargets: false, dietExtras: [] };
const TIPS = ['Small steps add up. Consistency matters more than perfection.', 'A glass of water before each meal helps you pace yourself.', 'Protein and fibre at every meal keep hunger steady.', 'Sleep 7–8 hours: it makes healthy choices easier.'];
const num = v => (v === '' || v == null ? '' : Number(v));

export default function App() {
  const [user, setUser] = useState(null), [profile, setProfile] = useState(initialProfile), [entries, setEntries] = useState([]);
  const [planPrefs, setPlanPrefs] = useState({ seed: 0, picks: {} }), [foods, setFoods] = useState([]), [aiMode, setAiMode] = useState(false);
  const [page, setPage] = useState('overview'), [dateKey, setDateKey] = useState(todayKey()), [modal, setModal] = useState(null);
  const [busy, setBusy] = useState(false), [error, setError] = useState(''), [notice, setNotice] = useState(''), [apiReady, setApiReady] = useState(true), [booting, setBooting] = useState(Boolean(typeof localStorage !== 'undefined' && localStorage.getItem('welltrack_token')));
  const [authMode, setAuthMode] = useState('login'), [authForm, setAuthForm] = useState({ name: '', email: '', password: '' }), [authNotice, setAuthNotice] = useState('');
  const [resetToken] = useState(() => new URLSearchParams(window.location.search).get('reset') || '');
  const [mobileNav, setMobileNav] = useState(false), [foodQuery, setFoodQuery] = useState(''), [search, setSearch] = useState('');
  const today = todayKey();

  const flash = msg => { setNotice(msg); setTimeout(() => setNotice(''), 2600); };
  const safe = async fn => { try { setError(''); return await fn(); } catch (e) { if (e.status === 401) logout(); else setError(e.message); } };

  // food database (cleaned dataset built by scripts/build-food-dataset.py)
  useEffect(() => { fetch('/datasets/foods-clean.json').then(r => (r.ok ? r.json() : [])).then(d => Array.isArray(d) && setFoods(d)).catch(() => {}); }, []);
  useEffect(() => { if (resetToken) setAuthMode('reset'); }, [resetToken]);
  useEffect(() => { request('/health').then(() => setApiReady(true)).catch(() => setApiReady(false)); }, []);

  async function loadAll() {
    const from = addDays(todayKey(), -89), to = todayKey();
    const [e, p, pp] = await Promise.all([request(`/entries?from=${from}&to=${to}`), request('/profile'), request('/plan-prefs')]);
    setEntries(e.entries); setProfile({ ...initialProfile, ...p.profile, dietExtras: p.profile?.dietExtras || [] }); setPlanPrefs(pp.planPrefs);
    request('/chat/status').then(s => setAiMode(Boolean(s.ai))).catch(() => setAiMode(false));
  }
  useEffect(() => {
    if (!localStorage.getItem('welltrack_token')) return;
    request('/auth/me').then(async d => { setUser(d.user); await loadAll(); }).catch(() => localStorage.removeItem('welltrack_token')).finally(() => setBooting(false));
  }, []);

  async function submitAuth(e) {
    e.preventDefault(); setBusy(true); setError(''); setAuthNotice('');
    try {
      if (authMode === 'forgot') { const d = await request('/auth/forgot-password', { method: 'POST', body: JSON.stringify({ email: authForm.email }) }); setAuthNotice(d.message); setAuthMode('login'); }
      else if (authMode === 'reset') { const d = await request('/auth/reset-password', { method: 'POST', body: JSON.stringify({ token: resetToken, password: authForm.password }) }); setAuthNotice(d.message); window.history.replaceState({}, '', window.location.pathname); setAuthMode('login'); }
      else {
        const d = await request(`/auth/${authMode}`, { method: 'POST', body: JSON.stringify(authForm) });
        localStorage.setItem('welltrack_token', d.token); setUser(d.user); setPage('overview'); setDateKey(todayKey()); await loadAll(); setApiReady(true);
      }
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  }
  function logout() { localStorage.removeItem('welltrack_token'); setUser(null); setEntries([]); setProfile(initialProfile); setPlanPrefs({ seed: 0, picks: {} }); setPage('overview'); setDateKey(todayKey()); setError(''); setModal(null); setAuthForm({ name: '', email: '', password: '' }); }

  /* ───────── derived data (single source of truth shared by every tab) ───────── */
  const targets = useMemo(() => computeTargets(profile), [profile]);
  const planOf = d => planForDate(profile, d, { seed: planPrefs.seed, picksByDate: planPrefs.picks });
  const planToday = useMemo(() => planOf(today), [profile, planPrefs, today]);
  const planDay = useMemo(() => planOf(dateKey), [profile, planPrefs, dateKey]);
  const summary = useMemo(() => summarize(profile, entries, today, planToday), [profile, entries, today, planToday]);
  const chatCtx = useMemo(() => ({ user, profile, summary, planDay: planToday, foods, todayEntries: entries.filter(e => e.dateKey === today), dateKey: today, now: new Date() }), [user, profile, summary, planToday, foods, entries, today]);

  /* ───────── actions ───────── */
  const openModal = (name, props = {}) => setModal({ name, ...props });
  const tickOf = (d, slot) => entries.find(e => e.dateKey === d && e.kind === 'meal' && e.mealRef && e.mealRef.startsWith(`${slot}:`));
  const post = async body => { const d = await request('/entries', { method: 'POST', body: JSON.stringify(body) }); setEntries(es => [...es, d.entry]); return d.entry; };
  const del = async id => { await request(`/entries/${id}`, { method: 'DELETE' }); setEntries(es => es.filter(e => e._id !== id)); };
  const savePrefs = async next => { setPlanPrefs(next); const d = await request('/plan-prefs', { method: 'PUT', body: JSON.stringify(next) }); setPlanPrefs(d.planPrefs); };

  const actions = {
    openModal, go: setPage,
    toggleSlot: (d, slot) => safe(async () => {
      if (d > today) return;
      const ex = tickOf(d, slot);
      if (ex) { await del(ex._id); return; }
      const s = planOf(d).slots.find(x => x.slot === slot);
      if (!s || !s.items.length) return;
      await post({ kind: 'meal', dateKey: d, name: s.items.map(i => i.name).join(' + ').slice(0, 100), calories: s.kcal, protein: s.p, carbs: s.c, fat: s.f, fiber: s.fiber, category: slot, mealRef: `${slot}:${s.mealId}` });
      flash(`${s.label} added to your log`);
    }),
    addWater: (ml, d = today) => safe(() => post({ kind: 'water', name: 'Water', amount: ml, dateKey: d })),
    undoWater: (d = today) => safe(async () => { const w = entries.filter(e => e.dateKey === d && e.kind === 'water'); if (w.length) await del(w[w.length - 1]._id); }),
    removeEntry: id => safe(() => del(id)),
    saveProfile: d => safe(async () => {
      setBusy(true);
      try {
        const payload = { ...d, age: num(d.age), heightCm: num(d.heightCm), weightKg: num(d.weightKg), targetWeightKg: num(d.targetWeightKg), calorieGoal: num(d.calorieGoal), waterGoalMl: num(d.waterGoalMl) };
        const r = await request('/profile', { method: 'PUT', body: JSON.stringify(payload) });
        setProfile({ ...initialProfile, ...r.profile, dietExtras: r.profile.dietExtras || [] }); setUser(r.user); flash('Profile saved — your plan has been updated');
      } finally { setBusy(false); }
    }),
    swapMeal: (d, slot, mealId) => safe(async () => {
      const picks = { ...planPrefs.picks, [d]: { ...(planPrefs.picks[d] || {}), [slot]: mealId } };
      const ex = tickOf(d, slot); if (ex) await del(ex._id);
      await savePrefs({ seed: planPrefs.seed, picks }); setModal(null); flash('Meal swapped');
    }),
    regenerateWeek: dates => safe(async () => {
      const picks = { ...planPrefs.picks }; dates.forEach(k => delete picks[k]);
      await savePrefs({ seed: planPrefs.seed + 1, picks }); flash('Fresh meal ideas generated for this week');
    }),
    logFood: food => openModal('food', { food }),
  };
  const modalActions = {
    saveActivity: ({ name, amount }) => safe(async () => { await post({ kind: 'activity', name, amount, dateKey: today }); setModal(null); flash('Activity logged'); }),
    saveWeight: (kg, d) => safe(async () => {
      await post({ kind: 'weight', name: 'Weight', amount: kg, dateKey: d });
      if (d === today) { const r = await request('/profile', { method: 'PUT', body: JSON.stringify({ weightKg: kg }) }); setProfile(p => ({ ...p, ...r.profile, dietExtras: r.profile.dietExtras || [] })); }
      setModal(null); flash('Weight recorded');
    }),
    saveMeal: f => safe(async () => { await post({ kind: 'meal', name: f.name, calories: Number(f.calories) || 0, protein: Number(f.protein) || 0, carbs: Number(f.carbs) || 0, fat: Number(f.fat) || 0, category: f.category, dateKey: f.dateKey }); setModal(null); flash('Meal added'); }),
    saveFood: ({ food, grams, slot, dateKey: d, calc }) => safe(async () => { await post({ kind: 'meal', name: `${food.name} (${grams} g)`.slice(0, 100), calories: calc.kcal, protein: calc.p, carbs: calc.c, fat: calc.f, fiber: calc.fiber, category: slot, dateKey: d }); setModal(null); flash(`${food.name} added to your ${SLOT_META[slot].label.toLowerCase()}`); }),
  };

  const app = { user, profile, targets, entries, summary, planToday, planDay, planPrefs, today, dateKey, setDateKey, foods, foodQuery, setFoodQuery, actions, go: setPage, chatCtx, aiMode };
  const goSearch = e => { e.preventDefault(); if (search.trim()) { setFoodQuery(search.trim()); setPage('foods'); setSearch(''); setMobileNav(false); } };

  if (booting) return <div className="boot"><HeartPulse size={28} /><span>Loading WellTrack…</span></div>;
  if (!user) return <Login mode={authMode} setMode={m => { setAuthMode(m); setError(''); }} form={authForm} setForm={setAuthForm} submit={submitAuth} busy={busy} error={error} notice={authNotice} apiReady={apiReady} useDemo={() => { setAuthMode('login'); setAuthForm({ name: '', email: DEMO_EMAIL, password: DEMO_PASSWORD }); }} />;

  const Page = { overview: Dashboard, health: HealthProfile, meals: DietTracker, progress: Progress, foods: FoodLibrary, planner: MealPlanner, reports: Reports, healthmate: HealthMate }[page];
  const initials = (user.name || '?').trim().split(/\s+/).map(w => w[0]).slice(0, 2).join('').toUpperCase();
  return <div className="shell"><div className="frame">
    <aside className={`sidebar ${mobileNav ? 'open' : ''}`}>
      <div className="brand"><span className="brand-mark"><HeartPulse size={22} /></span><div><strong>welltrack</strong><small>PERSONAL HEALTH</small></div></div>
      <form className="side-search" onSubmit={goSearch}><Search size={17} /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search foods" aria-label="Search foods" /><kbd>↵</kbd></form>
      <nav aria-label="Main">{NAV.map(n => <button key={n.id} className={`nav-link ${page === n.id ? 'active' : ''}`} aria-current={page === n.id ? 'page' : undefined} onClick={() => { setPage(n.id); setMobileNav(false); }}><n.icon size={19} /><span>{n.label}</span>{n.badge && <em>{aiMode ? 'AI' : 'NEW'}</em>}</button>)}</nav>
      <div className="side-bottom">
        <div className="side-tip"><i><Sparkles size={16} /></i><strong>Daily tip</strong><p>{TIPS[new Date().getDate() % TIPS.length]}</p></div>
        <div className="side-user"><span className="avatar-lg">{initials}</span><div><strong>{user.name}</strong><small>{user.email}</small></div><button className="icon-btn" aria-label="Sign out" onClick={logout}><LogOut size={17} /></button></div>
      </div>
    </aside>
    {mobileNav && <div className="scrim" onClick={() => setMobileNav(false)} />}
    <main className="main">
      <header className="topbar"><button className="icon-btn mobile-menu" aria-label="Open menu" onClick={() => setMobileNav(true)}><Menu size={20} /></button><span className="spacer" />
        <span className="date-pill"><CalendarDays size={16} /> {new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })}</span>
        <button className="avatar-btn" aria-label="Open Health profile" onClick={() => setPage('health')}>{initials}</button></header>
      <div className="content">
        {error && <div className="alert alert-bad"><TriangleAlert size={16} /> {error}<button className="link" onClick={() => setError('')}>Dismiss</button></div>}
        {notice && <div className="toast"><Check size={16} /> {notice}</div>}
        {!apiReady && <div className="alert alert-bad">The API is not reachable right now. Changes will not be saved until the backend is running.</div>}
        <Page app={app} key={page} />
      </div>
      <footer className="footer"><span>WellTrack · Personal Health &amp; Diet Tracker</span><span>Your records are tied to your account</span></footer>
    </main>
    {modal?.name === 'activity' && <ActivityModal onClose={() => setModal(null)} onSave={modalActions.saveActivity} />}
    {modal?.name === 'weight' && <WeightModal onClose={() => setModal(null)} onSave={modalActions.saveWeight} current={summary.journey.current || profile.weightKg} />}
    {modal?.name === 'meal' && <MealModal onClose={() => setModal(null)} onSave={modalActions.saveMeal} dateKey={dateKey > today ? today : dateKey} />}
    {modal?.name === 'swap' && <SwapModal onClose={() => setModal(null)} onPick={id => actions.swapMeal(modal.dateKey, modal.slot, id)} ctx={{ profile, targets, planPrefs, dateKey: modal.dateKey, slot: modal.slot }} />}
    {modal?.name === 'food' && <LogFoodModal onClose={() => setModal(null)} onSave={modalActions.saveFood} food={modal.food} today={today} />}
  </div></div>;
}
