// Thin API client. The JWT is kept in localStorage (same behaviour as before).
export const API = `${import.meta.env?.VITE_API_URL || 'http://localhost:5000'}/api`;
export async function request(path, options = {}) {
  const token = typeof localStorage !== 'undefined' ? localStorage.getItem('welltrack_token') : null;
  const response = await fetch(`${API}${path}`, { ...options, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(options.headers || {}) } });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) { const err = new Error(data.message || 'Request failed. Is the backend running?'); err.status = response.status; err.data = data; throw err; }
  return data;
}
