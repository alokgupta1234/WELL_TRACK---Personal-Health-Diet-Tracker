import { Coffee, Sun, Cookie, Moon, Apple, Salad, Wheat, Leaf, Milk, Beef, Fish, Utensils, Home, HeartPulse, TrendingUp, CalendarDays, FileText, Bot, Flame } from 'lucide-react';
export const SLOT_ICON = { breakfast: Coffee, lunch: Sun, snack: Cookie, dinner: Moon };
export const CAT_ICON = { Fruits: Apple, Vegetables: Salad, 'Grains & Bakery': Wheat, 'Legumes & Pulses': Leaf, 'Dairy & Eggs': Milk, 'Meat & Poultry': Beef, 'Fish & Seafood': Fish, 'Nuts & Seeds': Cookie, 'Soups & Prepared meals': Utensils };
export const FOOD_CATEGORIES = ['Fruits', 'Vegetables', 'Grains & Bakery', 'Legumes & Pulses', 'Dairy & Eggs', 'Meat & Poultry', 'Fish & Seafood', 'Nuts & Seeds', 'Soups & Prepared meals'];
// Navigation order: Dashboard → Health profile → Diet tracker → …
export const NAV = [
  { id: 'overview', label: 'Dashboard', icon: Home },
  { id: 'health', label: 'Health profile', icon: HeartPulse },
  { id: 'meals', label: 'Diet tracker', icon: Utensils },
  { id: 'progress', label: 'Progress', icon: TrendingUp },
  { id: 'foods', label: 'Food library', icon: Apple },
  { id: 'planner', label: 'Meal planner', icon: CalendarDays },
  { id: 'reports', label: 'Health reports', icon: FileText },
  { id: 'healthmate', label: 'HealthMate', icon: Bot, badge: 'AI' },
];
export const ACTIVITY_PRESETS = ['Walking', 'Jogging', 'Cycling', 'Yoga', 'Gym workout', 'Swimming', 'Sports'];
export { Flame };
