// WellTrack nutrition engine – pure functions shared by the React app and the API.
import { MEALS, SIDES } from './meals.mjs';

/* ───────────────────────── dates ───────────────────────── */
export const todayKey = (date = new Date()) =>
  `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
export const parseKey = key => { const [y, m, d] = String(key).split('-').map(Number); return new Date(y, m - 1, d, 12); };
export const addDays = (key, n) => { const d = parseKey(key); d.setDate(d.getDate() + n); return todayKey(d); };
export const daysBetween = (a, b) => Math.round((parseKey(b) - parseKey(a)) / 86400000);
export const weekStart = key => { const d = parseKey(key); const dow = (d.getDay() + 6) % 7; return addDays(key, -dow); }; // Monday
export const rangeKeys = (from, to) => { const out = []; for (let k = from; k <= to; k = addDays(k, 1)) out.push(k); return out; };

/* ───────────────────────── helpers ───────────────────────── */
const n = v => { const x = Number(v); return Number.isFinite(x) ? x : 0; };
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const r1 = v => Math.round(v * 10) / 10;
const roundTo = (v, step) => Math.round(v / step) * step;
const sum = (arr, f = x => x) => arr.reduce((a, x) => a + n(f(x)), 0);
const avg = (arr, f) => (arr.length ? sum(arr, f) / arr.length : 0);
export function hashString(str) { let h = 1779033703 ^ String(str).length; for (let i = 0; i < str.length; i++) { h = Math.imul(h ^ str.charCodeAt(i), 3432918353); h = (h << 13) | (h >>> 19); } return () => { h = Math.imul(h ^ (h >>> 16), 2246822507); h = Math.imul(h ^ (h >>> 13), 3266489909); return (h ^= h >>> 16) >>> 0; }; }
export function rngFrom(seed) { let a = hashString(String(seed))(); return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

export const SLOTS = ['breakfast', 'lunch', 'snack', 'dinner'];
export const SLOT_META = {
  breakfast: { label: 'Breakfast', short: 'Morning', time: '08:00', share: 0.25 },
  lunch: { label: 'Lunch', short: 'Afternoon', time: '13:00', share: 0.33 },
  snack: { label: 'Evening snack', short: 'Evening', time: '17:00', share: 0.12 },
  dinner: { label: 'Dinner', short: 'Night', time: '20:00', share: 0.30 },
};
export const ACTIVITY_FACTORS = { 'Sedentary': 1.2, 'Lightly active': 1.375, 'Moderately active': 1.55, 'Very active': 1.725 };
export const GOALS = ['Maintain weight', 'Lose weight', 'Gain weight', 'Build healthier habits'];
export const DIET_OPTIONS = ['No preference', 'Vegetarian', 'Eggitarian', 'Vegan', 'Pescatarian', 'Non-vegetarian'];
export const EXTRA_OPTIONS = [
  { id: 'no-dairy', label: 'Dairy-free' }, { id: 'no-gluten', label: 'Gluten-free' }, { id: 'no-nuts', label: 'Nut-free' },
  { id: 'low-carb', label: 'Low-carb' }, { id: 'high-protein', label: 'High-protein' },
];

/* ───────────────────────── body metrics ───────────────────────── */
export function bmiOf(profile) {
  const h = n(profile?.heightCm), w = n(profile?.weightKg);
  return h > 0 && w > 0 ? w / ((h / 100) ** 2) : null;
}
export const bmiLabel = bmi => (bmi ? (bmi < 18.5 ? 'Below range' : bmi < 25 ? 'In range' : bmi < 30 ? 'Above range' : 'High range') : 'Add your details');
export const healthyRange = heightCm => (n(heightCm) > 0 ? { min: r1(18.5 * (heightCm / 100) ** 2), max: r1(24.9 * (heightCm / 100) ** 2) } : null);

export function missingProfileFields(profile) {
  const miss = [];
  const age = n(profile?.age), h = n(profile?.heightCm), w = n(profile?.weightKg);
  if (!(age >= 10 && age <= 100)) miss.push('age');
  if (!(h >= 100 && h <= 240)) miss.push('height');
  if (!(w >= 30 && w <= 350)) miss.push('weight');
  return miss;
}

/**
 * Daily targets from the health profile (Mifflin-St Jeor + activity factor + goal adjustment).
 * A user can still override calories/water manually by switching on "custom targets".
 */
export function computeTargets(profile = {}) {
  const missing = missingProfileFields(profile);
  const goal = GOALS.includes(profile.goal) ? profile.goal : 'Maintain weight';
  const extras = profile.dietExtras || [];
  const age = n(profile.age), h = n(profile.heightCm), w = n(profile.weightKg);
  const out = { goal, complete: missing.length === 0, missing, source: 'default', minor: age > 0 && age < 18 };
  let calories = n(profile.calorieGoal) || 2000, water = n(profile.waterGoalMl) || 2000;

  if (out.complete) {
    const sexConst = profile.gender === 'Male' ? 5 : profile.gender === 'Female' ? -161 : -78;
    const bmr = 10 * w + 6.25 * h - 5 * age + sexConst;
    const tdee = bmr * (ACTIVITY_FACTORS[profile.activityLevel] || 1.375);
    let adj = goal === 'Lose weight' ? -Math.min(500, tdee * 0.22) : goal === 'Gain weight' ? 400 : 0;
    if (out.minor) adj = 0; // growth years: maintenance only
    const floor = profile.gender === 'Male' ? 1500 : profile.gender === 'Female' ? 1200 : 1350;
    const target = clamp(roundTo(tdee + adj, 50), Math.min(floor, tdee), 4500);
    out.bmr = Math.round(bmr); out.tdee = Math.round(tdee); out.adjustment = Math.round(target - tdee);
    out.source = 'auto';
    calories = target;
    const bonus = { 'Sedentary': 0, 'Lightly active': 250, 'Moderately active': 500, 'Very active': 750 }[profile.activityLevel] ?? 250;
    water = clamp(roundTo(w * 35 + bonus, 50), 1500, 4500);
  }
  if (profile.customTargets) { calories = n(profile.calorieGoal) || calories; water = n(profile.waterGoalMl) || water; out.source = 'custom'; }

  const perKg = goal === 'Lose weight' ? 1.4 : goal === 'Gain weight' ? 1.5 : 1.1;
  let protein = w > 0 ? w * (perKg + (extras.includes('high-protein') ? 0.3 : 0)) : calories * 0.18 / 4;
  protein = clamp(protein, 40, calories * 0.35 / 4);
  const fatShare = extras.includes('low-carb') ? 0.38 : 0.27;
  const fat = (calories * fatShare) / 9;
  const carbs = Math.max(0, (calories - protein * 4 - fat * 9) / 4);
  Object.assign(out, {
    calories: Math.round(calories), water: Math.round(water), protein: Math.round(protein), carbs: Math.round(carbs),
    fat: Math.round(fat), fiber: Math.round((14 * calories) / 1000),
  });
  out.split = { protein: Math.round((protein * 4 / calories) * 100), carbs: Math.round((carbs * 4 / calories) * 100), fat: Math.round((fat * 9 / calories) * 100) };
  out.slotKcal = Object.fromEntries(SLOTS.map(s => [s, Math.round(calories * SLOT_META[s].share)]));
  return out;
}

export function waterSchedule(goalMl) {
  const glasses = Math.max(1, Math.ceil(goalMl / 250));
  const startMin = 7 * 60 + 30, endMin = 21 * 60 + 30;
  return Array.from({ length: glasses }, (_, i) => {
    const m = glasses === 1 ? startMin : Math.round((startMin + ((endMin - startMin) * i) / (glasses - 1)) / 5) * 5;
    return { time: `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`, ml: i === glasses - 1 && goalMl % 250 ? goalMl % 250 : 250 };
  });
}

/* ───────────────────────── diet rules ───────────────────────── */
export function allowedDiets(pref) {
  switch (pref) {
    case 'Vegan': return ['vegan'];
    case 'Vegetarian': return ['vegan', 'veg'];
    case 'Eggitarian': return ['vegan', 'veg', 'egg'];
    case 'Pescatarian': return ['vegan', 'veg', 'egg', 'fish'];
    default: return ['vegan', 'veg', 'egg', 'fish', 'nonveg'];
  }
}
export function isAllowed(item, profile = {}) {
  if (!allowedDiets(profile.dietaryPreference).includes(item.diet)) return false;
  const ex = profile.dietExtras || [], c = item.contains || [];
  if (ex.includes('no-dairy') && c.includes('dairy')) return false;
  if (ex.includes('no-gluten') && c.includes('gluten')) return false;
  if (ex.includes('no-nuts') && c.includes('nuts')) return false;
  return true;
}
export const dietLabel = d => ({ vegan: 'Vegan', veg: 'Vegetarian', egg: 'Contains egg', fish: 'Contains fish', nonveg: 'Non-vegetarian' }[d] || d);

/* ───────────────────────── meal selection & portions ───────────────────────── */
const qScale = (target, kcal) => clamp(roundTo(target / kcal, 0.25), 0.75, 1.5);
function mealScore(meal, target, profile, protSlot = 0) {
  const scale = qScale(target, meal.kcal);
  const err = Math.abs(meal.kcal * scale - target) / target;
  const pd = (meal.p * 4) / meal.kcal, fd = Math.min(3, (meal.fiber / meal.kcal) * 100);
  const ex = profile.dietExtras || [];
  let s = 1 - err * 1.4;
  if (profile.goal === 'Lose weight') s += pd * 1.6 + fd * 0.05;
  else if (profile.goal === 'Gain weight') s += pd * 1.1 + meal.kcal / 1500;
  else s += pd * 0.9 + fd * 0.04;
  if (ex.includes('high-protein')) s += pd * 0.8;
  if (ex.includes('low-carb')) s += (1 - (meal.c * 4) / meal.kcal) * 0.5;
  if (scale > 1.25) s -= 0.15;
  if (protSlot) s -= Math.max(0, (meal.p * scale) / protSlot - 1.5) * 0.35; // do not overshoot the protein target
  if (meal.diet === 'fish' || meal.diet === 'nonveg') s -= 0.12; // keep variety when everything is allowed
  if (scale < 0.8) s -= 0.1;
  return s;
}
// which side items make sense in which meal (no rice with breakfast, no protein shake after dinner …)
const NO_SIDE = { breakfast: ['x10', 'x11', 'x15', 'x20', 'x21', 'x05'], snack: ['x05', 'x10', 'x11', 'x20', 'x21'], lunch: ['x09', 'x18', 'x19'], dinner: ['x09', 'x18', 'x19'] };
const sideFits = (slot, id) => !(NO_SIDE[slot] || []).includes(id);
function portionOf(meal, target, profile, protTarget = 0, used = new Set(), slot = '') {
  let servings = qScale(target, meal.kcal);
  const main = sv => ({ type: 'meal', id: meal.id, name: meal.name, servings: sv, serving: meal.serving, grams: Math.round(meal.grams * sv), kcal: Math.round(meal.kcal * sv),
    p: r1(meal.p * sv), c: r1(meal.c * sv), f: r1(meal.f * sv), fiber: r1(meal.fiber * sv), diet: meal.diet, contains: meal.contains });
  const items = [main(servings)];
  const allowed = SIDES.filter(x => isAllowed(x, profile) && !used.has(x.id) && sideFits(slot, x.id));
  // 1) top up protein when this slot is clearly short of its share of the daily protein target
  if (protTarget && protTarget - sum(items, i => i.p) > 8) {
    const strong = allowed.filter(x => x.p >= 6);
    const foods = strong.filter(x => !/shake/i.test(x.name));
    const pool = foods.length ? foods : strong;
    const prot = pool.sort((a, b) => b.p / b.kcal - a.p / a.kcal || a.kcal - b.kcal)[0];
    if (prot) { items.push(sideItem(prot)); used.add(prot.id); }
  }
  // 2) shrink the main dish if the slot is now over its calorie share
  while (sum(items, i => i.kcal) > target * 1.06 && servings > 0.75) { servings -= 0.25; items[0] = main(servings); }
  // 3) otherwise fill a remaining calorie gap with a small side
  for (let k = 0; k < 2 && items.length < 4; k++) {
    const gap = target - sum(items, i => i.kcal);
    if (gap <= Math.max(90, target * 0.13)) break;
    const protOver = protTarget && sum(items, i => i.p) >= protTarget * 1.1; // already enough protein → fill with energy, not more protein
    const cost = x => Math.abs(x.kcal - gap) + (protOver ? x.p * 8 : 0);
    const side = allowed.filter(x => !items.some(i => i.id === x.id) && x.kcal <= gap + 60).sort((a, b) => cost(a) - cost(b))[0];
    if (!side) break;
    items.push(sideItem(side)); used.add(side.id);
  }
  return items;
}
const sideItem = side => ({ type: 'side', id: side.id, name: side.name, servings: 1, serving: side.name, grams: side.grams, kcal: side.kcal, p: side.p, c: side.c, f: side.f, fiber: side.fiber, diet: side.diet, contains: side.contains });
const totalOf = items => ({ kcal: Math.round(sum(items, i => i.kcal)), p: r1(sum(items, i => i.p)), c: r1(sum(items, i => i.c)), f: r1(sum(items, i => i.f)), fiber: r1(sum(items, i => i.fiber)) });

export function rankMeals(profile, slot, target, { exclude = [], meals = MEALS } = {}) {
  const protSlot = computeTargets(profile).protein * (SLOT_META[slot]?.share || 0.25);
  return meals.filter(m => m.slots.includes(slot) && isAllowed(m, profile) && !exclude.includes(m.id))
    .map(m => ({ meal: m, score: mealScore(m, target, profile, protSlot) })).sort((a, b) => b.score - a.score);
}

/** Build one day's plan. `picks` = {slot: mealId} chosen by the user, `avoid` = {slot: [mealIds]} used earlier this week. */
export function buildDayPlan(profile, dateKey, { seed = 0, picks = {}, avoid = {} } = {}) {
  const targets = computeTargets(profile);
  const usedSides = new Set();
  const slots = SLOTS.map(slot => {
    const target = targets.slotKcal[slot];
    let meal = picks[slot] ? MEALS.find(m => m.id === picks[slot] && m.slots.includes(slot) && isAllowed(m, profile)) : null;
    let userPicked = !!meal;
    if (!meal) {
      let ranked = rankMeals(profile, slot, target, { exclude: avoid[slot] || [] });
      if (ranked.length < 2) ranked = rankMeals(profile, slot, target);
      const pool = ranked.slice(0, 4);
      if (pool.length) { const rng = rngFrom(`${seed}|${dateKey}|${slot}`); meal = pool[Math.floor(rng() * pool.length)].meal; }
    }
    const items = meal ? portionOf(meal, target, profile, targets.protein * SLOT_META[slot].share, usedSides, slot) : [];
    return { slot, ...SLOT_META[slot], targetKcal: target, mealId: meal?.id || null, userPicked, items, ...totalOf(items) };
  });
  const totals = totalOf(slots);
  return { dateKey, targets, slots, totals, deltaKcal: totals.kcal - targets.calories, waterSchedule: waterSchedule(targets.water) };
}

/** Monday-anchored week so that "today's plan" is always identical to the planner's view of today. */
export function buildWeekPlan(profile, anyDateInWeek, { seed = 0, picksByDate = {} } = {}) {
  const start = weekStart(anyDateInWeek), used = Object.fromEntries(SLOTS.map(s => [s, []]));
  return Array.from({ length: 7 }, (_, i) => {
    const dateKey = addDays(start, i);
    const plan = buildDayPlan(profile, dateKey, { seed, picks: picksByDate[dateKey] || {}, avoid: used });
    plan.slots.forEach(s => { if (s.mealId) used[s.slot].push(s.mealId); });
    return plan;
  });
}
export function planForDate(profile, dateKey, opts = {}) {
  const week = buildWeekPlan(profile, dateKey, opts);
  return week.find(d => d.dateKey === dateKey);
}

export function alternativesFor(profile, slot, target, excludeId, count = 6) {
  return rankMeals(profile, slot, target, { exclude: excludeId ? [excludeId] : [] }).slice(0, count).map(({ meal }) => {
    const items = portionOf(meal, target, profile, computeTargets(profile).protein * (SLOT_META[slot]?.share || 0.25), new Set(), slot);
    return { mealId: meal.id, name: meal.name, items, ...totalOf(items) };
  });
}
export const shoppingList = week => {
  const map = new Map();
  week.forEach(d => d.slots.forEach(s => s.items.forEach(i => { const e = map.get(i.name) || { name: i.name, count: 0, slot: s.slot }; e.count += 1; map.set(i.name, e); })));
  return [...map.values()].sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
};
export const mealById = id => MEALS.find(m => m.id === id);

/* ───────────────────────── food library recommendations ───────────────────────── */
export function foodMatch(food, profile = {}) {
  if (!food.per100) return { score: 0, reasons: [] };
  const p = food.per100, kcal = Math.max(1, p.kcal);
  const nutri = (food.score || 5) / 10, prot = clamp(((p.p * 4) / kcal) / 0.4, 0, 1), fibre = clamp(p.fiber / 6, 0, 1);
  const light = clamp(1 - kcal / 400, 0, 1), dense = clamp(kcal / 450, 0, 1);
  const ex = profile.dietExtras || [];
  let s;
  if (profile.goal === 'Lose weight') s = 0.35 * nutri + 0.25 * prot + 0.2 * fibre + 0.2 * light;
  else if (profile.goal === 'Gain weight') s = 0.3 * nutri + 0.25 * prot + 0.15 * fibre + 0.3 * nutri * dense;
  else s = 0.6 * nutri + 0.15 * prot + 0.15 * fibre + 0.1 * light;
  if (ex.includes('high-protein')) s += 0.15 * prot;
  if (ex.includes('low-carb')) s += 0.15 * (1 - clamp(p.c / 40, 0, 1));
  const reasons = [];
  if (prot >= 0.5) reasons.push('High protein');
  if (fibre >= 0.55) reasons.push('Rich in fibre');
  if (profile.goal === 'Lose weight' && light >= 0.6) reasons.push('Light on calories');
  if (profile.goal === 'Gain weight' && dense >= 0.45 && nutri >= 0.6) reasons.push('Energy-dense & nutritious');
  if (nutri >= 0.8) reasons.push('Nutrient-dense');
  if (ex.includes('low-carb') && p.c <= 8) reasons.push('Low carb');
  return { score: Math.round(clamp(s / 1.05, 0, 1) * 100), reasons: reasons.slice(0, 3) };
}
export const matchLabel = score => (score >= 70 ? 'Great match' : score >= 55 ? 'Good match' : score >= 40 ? 'Fair match' : 'Occasional');

export function searchFoods(foods, profile, { query = '', category = 'All', slot = 'All', tag = 'Any', onlyMatching = true, sort = 'match', limit = 60 } = {}) {
  const q = query.trim().toLowerCase(), tokens = q.split(/\s+/).filter(Boolean);
  let list = foods.filter(f => f.quality === 'ok');
  if (!q) list = list.filter(f => f.recommend);
  if (tokens.length) list = list.filter(f => tokens.every(t => f.name.toLowerCase().includes(t)));
  if (category !== 'All') list = list.filter(f => f.category === category);
  if (slot !== 'All') list = list.filter(f => f.slots.includes(slot));
  if (tag !== 'Any') list = list.filter(f => f.tags.includes(tag));
  const rows = list.map(f => ({ ...f, allowed: isAllowed(f, profile), match: foodMatch(f, profile) }));
  let res = onlyMatching ? rows.filter(r => r.allowed) : rows;
  const cmp = {
    match: (a, b) => b.match.score - a.match.score,
    protein: (a, b) => b.per100.p - a.per100.p,
    calories: (a, b) => a.per100.kcal - b.per100.kcal,
    fibre: (a, b) => b.per100.fiber - a.per100.fiber,
    name: (a, b) => a.name.localeCompare(b.name),
  }[sort] || ((a, b) => b.match.score - a.match.score);
  res = res.sort((a, b) => (Number(b.allowed) - Number(a.allowed)) || cmp(a, b));
  return { total: res.length, items: res.slice(0, limit) };
}
export function portionForKcal(food, kcal) {
  if (!food.per100) return null;
  const grams = clamp(roundTo((kcal / food.per100.kcal) * 100, 10), 10, 600);
  return { grams, kcal: Math.round((food.per100.kcal * grams) / 100), p: r1((food.per100.p * grams) / 100), c: r1((food.per100.c * grams) / 100), f: r1((food.per100.f * grams) / 100) };
}
export function foodAtGrams(food, grams) {
  const k = food.per100 ? grams / 100 : 0;
  return food.per100 ? { kcal: Math.round(food.per100.kcal * k), p: r1(food.per100.p * k), c: r1(food.per100.c * k), f: r1(food.per100.f * k), fiber: r1(food.per100.fiber * k) } : null;
}

/* ───────────────────────── progress analytics ───────────────────────── */
export function dailySeries(entries, fromKey, toKey) {
  const map = Object.fromEntries(rangeKeys(fromKey, toKey).map(k => [k, { date: k, calories: 0, protein: 0, carbs: 0, fat: 0, fiber: 0, water: 0, activity: 0, weight: null, meals: 0, planned: 0 }]));
  for (const e of entries) {
    const d = map[e.dateKey]; if (!d) continue;
    if (e.kind === 'meal') { d.calories += n(e.calories); d.protein += n(e.protein); d.carbs += n(e.carbs); d.fat += n(e.fat); d.fiber += n(e.fiber); d.meals += 1; if (e.mealRef) d.planned += 1; }
    else if (e.kind === 'water') d.water += n(e.amount);
    else if (e.kind === 'activity') d.activity += n(e.amount);
    else if (e.kind === 'weight') d.weight = n(e.amount);
  }
  return Object.values(map);
}
export function weightJourney(profile, entries, today = todayKey()) {
  const weights = entries.filter(e => e.kind === 'weight' && n(e.amount) > 0).sort((a, b) => a.dateKey.localeCompare(b.dateKey) || String(a.createdAt || '').localeCompare(String(b.createdAt || '')));
  const byDate = new Map(); weights.forEach(w => byDate.set(w.dateKey, n(w.amount)));
  const points = [...byDate.entries()].map(([date, kg]) => ({ date, kg }));
  const profW = n(profile?.weightKg) || null, target = n(profile?.targetWeightKg) || null;
  const start = points[0]?.kg ?? profW, current = points.length ? points[points.length - 1].kg : profW;
  const out = { points, start, startDate: points[0]?.date || null, current, target, direction: 'maintain', pct: null, remaining: null, changeKg: null, ratePerWeek: null, etaWeeks: null, reached: false };
  if (start && current) out.changeKg = r1(current - start);
  if (start && current && target) {
    out.direction = target < start - 0.05 ? 'lose' : target > start + 0.05 ? 'gain' : 'maintain';
    if (out.direction !== 'maintain') {
      const total = Math.abs(start - target), done = out.direction === 'lose' ? start - current : current - start;
      out.pct = Math.round(clamp((done / total) * 100, 0, 100));
      out.remaining = r1(Math.max(0, out.direction === 'lose' ? current - target : target - current));
      out.reached = out.remaining <= 0.05;
    }
  }
  const recent = points.filter(p => daysBetween(p.date, today) <= 28);
  if (recent.length >= 2 && daysBetween(recent[0].date, recent[recent.length - 1].date) >= 6) {
    const xs = recent.map(p => daysBetween(recent[0].date, p.date)), ys = recent.map(p => p.kg);
    const mx = avg(xs), my = avg(ys); const den = sum(xs, x => (x - mx) ** 2);
    if (den > 0) {
      out.ratePerWeek = r1((sum(xs.map((x, i) => (x - mx) * (ys[i] - my))) / den) * 7);
      if (out.remaining && out.remaining > 0.05) { const towards = out.direction === 'lose' ? -out.ratePerWeek : out.ratePerWeek; if (towards > 0.05) out.etaWeeks = Math.ceil(out.remaining / towards); }
    }
  }
  return out;
}
const calRange = goal => (goal === 'Lose weight' ? [0.8, 1.05] : goal === 'Gain weight' ? [0.92, 1.2] : [0.9, 1.1]);
export function adherence(series, targets, goal) {
  const [lo, hi] = calRange(goal);
  const logged = series.filter(d => d.meals > 0);
  const onTarget = logged.filter(d => d.calories >= targets.calories * lo && d.calories <= targets.calories * hi);
  const waterDays = series.filter(d => d.water >= targets.water * 0.9);
  const activeDays = series.filter(d => d.activity >= 20);
  const len = Math.max(1, series.length);
  const calAdh = onTarget.length / len, waterAdh = avg(series, d => Math.min(1, d.water / targets.water)), actAdh = Math.min(1, sum(series, d => d.activity) / (150 * (len / 7))), logAdh = series.filter(d => d.meals >= 2).length / len;
  const score = Math.round(100 * (0.4 * calAdh + 0.25 * waterAdh + 0.2 * actAdh + 0.15 * logAdh));
  const planned = sum(series, d => d.planned), meals = sum(series, d => d.meals);
  return { score, onTargetDays: onTarget.length, loggedDays: logged.length, waterDays: waterDays.length, activeDays: activeDays.length, days: series.length, avgCalories: Math.round(avg(logged, d => d.calories)),
    avgProtein: Math.round(avg(logged, d => d.protein)), avgCarbs: Math.round(avg(logged, d => d.carbs)), avgFat: Math.round(avg(logged, d => d.fat)),
    avgWater: Math.round(avg(series, d => d.water)), totalActivity: Math.round(sum(series, d => d.activity)), plannedShare: meals ? Math.round((planned / meals) * 100) : 0,
    calPct: Math.round(calAdh * 100), waterPct: Math.round(waterAdh * 100), actPct: Math.round(actAdh * 100), logPct: Math.round(logAdh * 100) };
}
export function loggingStreak(series, today = todayKey()) {
  const byDate = Object.fromEntries(series.map(d => [d.date, d.meals > 0]));
  let k = byDate[today] ? today : addDays(today, -1), streak = 0;
  while (byDate[k]) { streak += 1; k = addDays(k, -1); }
  return streak;
}
export function weekRings(series, targets, today = todayKey()) {
  const start = addDays(today, -parseKey(today).getDay()); // Sunday
  const byDate = Object.fromEntries(series.map(d => [d.date, d]));
  return Array.from({ length: 7 }, (_, i) => { const k = addDays(start, i), d = byDate[k]; return { date: k, label: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][i], day: parseKey(k).getDate(), pct: d ? clamp(d.calories / targets.calories, 0, 1.2) : 0, isToday: k === today, future: k > today }; });
}
export function buildBadges({ journey, stats7, streak, entriesCount }) {
  const toward = journey.direction === 'lose' ? -journey.changeKg : journey.direction === 'gain' ? journey.changeKg : 0;
  return [
    { id: 'start', title: 'First steps', desc: 'Logged your first entry', earned: entriesCount > 0 },
    { id: 'streak', title: '7-day streak', desc: 'Logged meals 7 days in a row', earned: streak >= 7 },
    { id: 'water', title: 'Hydration hero', desc: 'Hit your water goal 5 of the last 7 days', earned: stats7.waterDays >= 5 },
    { id: 'target', title: 'On target', desc: '4+ days within your calorie range this week', earned: stats7.onTargetDays >= 4 },
    { id: 'active', title: 'Active week', desc: '150+ active minutes in 7 days', earned: stats7.totalActivity >= 150 },
    { id: 'plan', title: 'Plan follower', desc: '70%+ of meals came from your plan', earned: stats7.plannedShare >= 70 },
    { id: 'scale', title: 'Moving the scale', desc: '1 kg or more in the right direction', earned: toward >= 1 },
  ];
}
export function buildInsights({ profile, targets, journey, stats7, streak, todaySeries }) {
  const tips = [];
  const T = (tone, text) => tips.push({ tone, text });
  if (journey.pct != null && journey.direction !== 'maintain') {
    if (journey.reached) T('good', 'You reached your target weight — time to switch to maintenance and keep your habits.');
    else T('good', `You are ${journey.pct}% of the way to ${journey.target} kg with ${journey.remaining} kg to go.`);
  }
  if (journey.ratePerWeek != null && journey.direction !== 'maintain' && !journey.reached) {
    const towards = journey.direction === 'lose' ? -journey.ratePerWeek : journey.ratePerWeek;
    if (towards > 1) T('warn', `Your pace (${Math.abs(journey.ratePerWeek)} kg/week) is quicker than the usual 0.25–0.75 kg/week — make sure you are eating enough.`);
    else if (towards > 0.1) T('good', `Steady pace: about ${Math.abs(journey.ratePerWeek)} kg/week${journey.etaWeeks ? ` — roughly ${journey.etaWeeks} weeks to your target at this rate` : ''}.`);
    else T('tip', 'Your weight has been flat recently. Check portion sizes and weigh yourself at the same time each week.');
  }
  if (stats7.loggedDays >= 3) {
    if (stats7.avgCalories > targets.calories * 1.1) T('warn', `You average ${stats7.avgCalories} kcal on logged days, ${stats7.avgCalories - targets.calories} above your ${targets.calories} kcal target.`);
    else if (stats7.avgCalories < targets.calories * 0.8) T('warn', `You average ${stats7.avgCalories} kcal, well under your ${targets.calories} kcal target — eating too little can stall progress.`);
    else T('good', `Calories are on track: ${stats7.avgCalories} kcal/day on average against a ${targets.calories} kcal target.`);
    if (stats7.avgProtein < targets.protein * 0.8) T('tip', `Protein averages ${stats7.avgProtein} g vs a ${targets.protein} g goal — add dal, paneer, eggs, tofu or lean meat to one more meal.`);
  }
  if (stats7.waterPct < 60) T('tip', `Hydration is at ${stats7.waterPct}% of your goal this week. Try one glass with every meal and one on waking.`);
  else if (stats7.waterPct >= 90) T('good', 'Excellent hydration — you are close to your water goal every day.');
  if (stats7.totalActivity < 90) T('tip', `Only ${stats7.totalActivity} active minutes this week — a 20-minute walk after dinner adds ${20 * 5} minutes in 5 days.`);
  else if (stats7.totalActivity >= 150) T('good', `You logged ${stats7.totalActivity} active minutes — you met the 150-minute weekly guideline.`);
  if (streak >= 3) T('good', `${streak}-day logging streak — consistency is the best predictor of results.`);
  if (!tips.length) T('tip', 'Tick off the meals in your Diet Tracker for a few days and personalised insights will appear here.');
  return tips.slice(0, 6);
}

export function summarize(profile, entries, today = todayKey(), planDay = null) {
  const targets = computeTargets(profile);
  const from30 = addDays(today, -29), from7 = addDays(today, -6);
  const s30 = dailySeries(entries, from30, today), s7 = s30.filter(d => d.date >= from7);
  const journey = weightJourney(profile, entries, today);
  const stats7 = adherence(s7, targets, targets.goal), stats30 = adherence(s30, targets, targets.goal);
  const streak = loggingStreak(s30, today);
  const todaySeries = s30[s30.length - 1];
  return { targets, journey, series30: s30, series7: s7, stats7, stats30, streak, today: todaySeries, planDay,
    badges: buildBadges({ journey, stats7, streak, entriesCount: entries.length }),
    insights: buildInsights({ profile, targets, journey, stats7, streak, todaySeries }),
    bmi: bmiOf(profile) };
}
