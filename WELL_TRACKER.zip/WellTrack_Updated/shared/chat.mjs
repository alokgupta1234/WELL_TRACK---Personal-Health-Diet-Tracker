// HealthMate – on-device conversational assistant. Pure functions, no network.
// It understands intents + entities, keeps conversation memory for follow-ups and answers from the member's real data
// (profile, targets, today's plan, logged entries, progress) and from the food database.
import {
  SLOTS, SLOT_META, computeTargets, bmiOf, bmiLabel, healthyRange, waterSchedule, rankMeals, alternativesFor, searchFoods,
  foodMatch, isAllowed, dietLabel, allowedDiets, DIET_OPTIONS, ACTIVITY_FACTORS,
} from './engine.mjs';
import { MEALS } from './meals.mjs';

const r0 = v => Math.round(v);
const cap = s => (s ? s[0].toUpperCase() + s.slice(1) : s);
const first = name => String(name || '').trim().split(/\s+/)[0] || 'there';
const STOP = new Set('a an the of in on at to for is are was were be do does did can could should would will how what which who why when where much many more less my me i you your it its this that these those there any some about tell give show please want need get have has had with and or but so if as than then too very really just also like eat eating food foods meal meals calorie calories kcal protein carbs carb fat fats fibre fiber nutrition nutrients nutrient content amount per 100 g gram grams serving servings healthy good bad best better worst vs versus compare difference between high low rich light snack snacks vegetarian vegan veg nonveg ideas options suggest recommend list'.split(' '));
const words = t => t.toLowerCase().replace(/[^a-z0-9\s&-]/g, ' ').split(/\s+/).filter(Boolean);
const has = (t, re) => re.test(t);

/* ───────────────────────── context summary (also sent to the LLM mode) ───────────────────────── */
export function buildChatContext(ctx) {
  const { user, profile = {}, summary, planDay, dateKey } = ctx;
  const t = summary?.targets || computeTargets(profile);
  const bmi = bmiOf(profile);
  const L = [];
  L.push(`Name: ${first(user?.name)} | date: ${dateKey}`);
  L.push(`Profile: age ${profile.age || '?'}, ${profile.gender || '?'}, ${profile.heightCm || '?'} cm, ${profile.weightKg || '?'} kg${bmi ? `, BMI ${bmi.toFixed(1)} (${bmiLabel(bmi)})` : ''}; activity: ${profile.activityLevel}; goal: ${profile.goal}; target weight: ${profile.targetWeightKg || 'not set'} kg`);
  L.push(`Diet preference: ${profile.dietaryPreference}${(profile.dietExtras || []).length ? `; extras: ${profile.dietExtras.join(', ')}` : ''}`);
  L.push(`Daily targets: ${t.calories} kcal, protein ${t.protein} g, carbs ${t.carbs} g, fat ${t.fat} g, fibre ${t.fiber} g, water ${t.water} ml (${t.source === 'custom' ? 'user-set' : t.complete ? 'calculated from profile' : 'default – profile incomplete'})`);
  if (planDay) {
    L.push(`Today's plan (${planDay.totals.kcal} kcal, ${planDay.totals.p} g protein):`);
    planDay.slots.forEach(s => L.push(`- ${s.label} ${s.time}: ${s.items.map(i => i.name).join(' + ')} (${s.kcal} kcal)`));
  }
  if (summary) {
    const td = summary.today, s7 = summary.stats7, j = summary.journey;
    L.push(`Logged today: ${td.calories} kcal, protein ${r0(td.protein)} g, water ${td.water} ml, activity ${td.activity} min, ${td.meals} meal(s)`);
    L.push(`Last 7 days: avg ${s7.avgCalories} kcal on logged days, ${s7.onTargetDays}/7 days on calorie target, water goal hit ${s7.waterDays}/7 days, ${s7.totalActivity} active min, score ${s7.score}/100, logging streak ${summary.streak} days`);
    if (j.start && j.current) L.push(`Weight journey: start ${j.start} kg, now ${j.current} kg${j.target ? `, target ${j.target} kg, ${j.pct ?? 0}% complete` : ''}${j.ratePerWeek != null ? `, trend ${j.ratePerWeek} kg/week` : ''}`);
    L.push(`Insights: ${summary.insights.map(i => i.text).join(' ')}`);
  }
  return L.join('\n');
}

/* ───────────────────────── knowledge base (general nutrition) ───────────────────────── */
const KB = [
  [/fib(re|er)/, 'Fibre keeps you full, supports digestion and helps steady blood sugar. Aim for about **{fiber} g/day** (14 g per 1,000 kcal). Easy wins: dal and rajma, oats, whole-wheat roti, vegetables with skin, fruit instead of juice, a handful of nuts. Increase slowly and drink enough water.'],
  [/(iron|haemoglobin|hemoglobin|anaemi|anemi)/, 'Plant iron (spinach, lentils, chickpeas, rajma, sesame, jaggery, dates) is absorbed better with vitamin C — add lemon, amla, tomato or fruit to the meal — and worse with tea/coffee right after eating. If you feel unusually tired or are anaemic, get a blood test and ask a doctor before supplementing.'],
  [/calcium|bone/, 'Good calcium sources: milk, curd, paneer, ragi, sesame, almonds, tofu set with calcium and green leafy vegetables. Vitamin D (sunlight, fortified foods) and some strength training also protect bones.'],
  [/b ?12|cobalamin/, 'Vitamin B12 is found mainly in animal foods (milk, curd, paneer, eggs, fish, meat). Vegans need a B12 supplement or fortified foods; vegetarians should check levels occasionally. A blood test and your doctor can guide the dose.'],
  [/omega|dha|epa|flax|walnut/, 'Omega-3 sources: fatty fish (salmon, sardines, mackerel), flax and chia seeds, walnuts and mustard/canola oil. Vegetarians can also consider an algae-based DHA supplement after talking to a professional.'],
  [/\bsugar|sweet|dessert|craving/, 'Added sugar is best kept under ~10% of calories (ideally ~5%) — roughly **{sugarG} g/day** for you. For sweet cravings: have fruit with a few nuts, curd with cinnamon, a square of dark chocolate, or a date. Eating enough protein and fibre at meals and sleeping well reduces cravings.'],
  [/\b(salt|sodium|blood pressure|bp)\b/, 'WHO suggests under **5 g of salt (≈2 g sodium) per day**. Pickles, papad, namkeen, instant noodles and packaged soups are the big hidden sources. Use herbs, lemon and spices for flavour. If you have high blood pressure, follow your doctor\'s advice.'],
  [/cholesterol|ldl|hdl|triglycer/, 'To support healthy cholesterol: more fibre (oats, legumes, fruit), fewer fried and ultra-processed foods, nuts and olive/mustard oil instead of ghee/butter in large amounts, regular exercise. If you have high cholesterol, get it monitored by a doctor.'],
  [/intermittent|fasting|16 ?:? ?8|omad/, 'Intermittent fasting is one way to eat fewer calories, not magic. It can suit some people, but it is **not recommended** if you are pregnant, underweight, have diabetes or a history of disordered eating. Total calories and protein still decide results — your plan already spreads meals through the day.'],
  [/keto|atkins|low carb diet/, 'Very-low-carb/keto diets can reduce weight quickly but are hard to sustain and need medical supervision for some people. A moderate approach — less refined carbs, more protein and fibre — usually works as well and is easier to keep. You can pick "Low-carb" in your Health profile to bias suggestions that way.'],
  [/detox|cleanse|juice fast/, 'Your liver and kidneys already detox your body. Juice cleanses and "detox teas" are not needed and can leave you low on protein and fibre. Better "detox": water, vegetables, fibre, sleep and less alcohol.'],
  [/skip(ping)? breakfast|breakfast important/, 'Skipping breakfast is fine for some people, but a protein-rich breakfast helps many people feel full and avoid snacking later. Your plan includes breakfast at 08:00 — move it earlier or later to suit your routine.'],
  [/night|late (dinner|eating)|after \d+ ?pm|carbs at night/, 'Eating carbs at night does not automatically cause fat gain — total daily calories matter most. A lighter dinner 2–3 hours before bed helps sleep and digestion. Your dinner is planned for about 20:00.'],
  [/protein (powder|shake|supplement)|whey/, 'You can reach your protein target from food: dal, paneer, curd, eggs, tofu, soya, sprouts, fish or chicken. A protein shake is just a convenient top-up (about 20–25 g) if you fall short. People with kidney disease should ask a doctor first.'],
  [/caffeine|coffee|chai|tea\b/, 'Up to ~400 mg caffeine/day (about 3–4 cups of coffee or 5–6 cups of tea) is considered safe for most adults. Avoid it late in the day for better sleep, and watch the sugar in chai and coffee drinks.'],
  [/alcohol|beer|wine|whisky|whiskey|drink(ing)? alcohol/, 'Alcohol adds calories (7 kcal/g) without nutrients and can slow progress, disturb sleep and lower inhibitions around food. If you drink, keep it occasional and count it in your day.'],
  [/eating out|restaurant|takeaway|party|wedding|dhaba/, 'Eating out tips: choose grilled/tandoori or dal-sabzi over creamy gravies, ask for less oil, share a dessert, start with salad or soup, skip sugary drinks, and eat slowly. One restaurant meal will not undo your week.'],
  [/meal prep|batch cook|prepare in advance/, 'Meal prep: cook a pot of dal/rajma/chole and a grain on Sunday, chop vegetables, boil eggs or sprouts and portion into boxes. Use the weekly prep checklist in the Meal planner to organise shopping and cooking.'],
  [/portion|plate method|how much (should i )?eat/, 'Simple plate method: half the plate vegetables/salad, a quarter protein (dal, paneer, egg, fish, chicken), a quarter whole grains (roti, rice, millets). Your plan already sizes portions to your calorie target.'],
  [/glycemic|gi\b|blood sugar|diabet/, 'Foods that raise blood sugar slowly (high fibre, whole grains, legumes, vegetables, nuts) help steady energy. If you have diabetes or pre-diabetes, please follow your doctor\'s or dietitian\'s plan — WellTrack gives general guidance only.'],
  [/vitamin d|sunlight/, 'Vitamin D comes mainly from sunlight (10–20 minutes of midday sun on arms/legs several times a week), plus fortified milk, eggs and fish. Deficiency is common in India — a blood test and your doctor can advise on supplements.'],
  [/probiotic|curd|yogurt|gut/, 'Curd/yogurt, buttermilk and other fermented foods support gut health, and fibre feeds your good bacteria. A daily bowl of curd is a simple habit.'],
  [/millet|ragi|jowar|bajra/, 'Millets (ragi, jowar, bajra) have more fibre and minerals than white rice or refined flour and keep you full longer. Swap one roti or rice portion a day for a millet version.'],
];

/* ───────────────────────── food lookup ───────────────────────── */
const normName = s => s.toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
function foodCandidates(foods) {
  const items = foods.filter(f => f.quality !== 'serving-only').map(f => ({ ...f, kind: 'food', key: normName(f.name) }));
  const meals = MEALS.map(m => ({ id: m.id, name: m.name, kind: 'meal', key: normName(m.name), meal: m }));
  return [...meals, ...items];
}
const stem = w => w.replace(/(ies)$/, 'y').replace(/(es|s)$/, '');
export function findFood(query, foods, { max = 1 } = {}) {
  const toks = words(query).filter(w => !STOP.has(w) && w.length > 2).map(stem);
  if (!toks.length) return [];
  const cands = foodCandidates(foods);
  const scored = [];
  for (const c of cands) {
    const ctoks = c.key.split(' ').map(stem);
    const hits = toks.filter(t => ctoks.some(ct => ct === t || (t.length > 3 && ct.startsWith(t)) || (ct.length > 3 && t.startsWith(ct))));
    if (hits.length < toks.length) continue;
    let s = 100 - Math.min(60, c.key.length) + (c.key === toks.join(' ') ? 50 : 0) + (ctoks[0] === toks[0] ? 12 : 0);
    if (c.source === 'starter') s += 18;
    if (c.recommend) s += 6;
    if (c.kind === 'meal') s += 4;
    scored.push([s, c]);
  }
  return scored.sort((a, b) => b[0] - a[0]).slice(0, max).map(x => x[1]);
}

const per = f => (f.kind === 'meal' ? { kcal: f.meal.kcal, p: f.meal.p, c: f.meal.c, f: f.meal.f, fiber: f.meal.fiber } : f.per100);
function describeFood(f, ctx, nutrient) {
  const { profile } = ctx;
  if (f.kind === 'meal') {
    const m = f.meal;
    return `**${m.name}** — ${dietLabel(m.diet)}\nOne serving (${m.serving}, ≈${m.grams} g): **${m.kcal} kcal**, protein ${m.p} g, carbs ${m.c} g, fat ${m.f} g, fibre ${m.fiber} g.${isAllowed(m, profile) ? '' : `\nThis does not match your ${profile.dietaryPreference} preference.`}`;
  }
  const p = f.per100;
  if (!p) return `**${f.name}** — ${dietLabel(f.diet)}\nPer listed serving: ${f.kcal} kcal, protein ${f.p} g, carbs ${f.c} g, fat ${f.f} g. (The dataset does not give enough detail to convert this to 100 g.)`;
  const m = foodMatch(f, profile);
  const serv = f.servingG ? `\nTypical serving ≈ ${f.servingG} g → **${Math.round((p.kcal * f.servingG) / 100)} kcal**, ${Math.round(((p.p * f.servingG) / 100) * 10) / 10} g protein.` : '';
  const head = nutrient
    ? `**${f.name}** has **${nutrient === 'kcal' ? `${p.kcal} kcal` : `${p[nutrient]} g ${{ p: 'protein', c: 'carbs', f: 'fat', fiber: 'fibre' }[nutrient]}`}** per 100 g.`
    : `**${f.name}** — ${dietLabel(f.diet)} · health score ${f.score}/10`;
  const body = `\nPer 100 g: **${p.kcal} kcal**, protein ${p.p} g, carbs ${p.c} g, fat ${p.f} g, fibre ${p.fiber} g.`;
  const fit = `\nFor your goal (${profile.goal}) this is a **${m.score >= 70 ? 'great' : m.score >= 55 ? 'good' : m.score >= 40 ? 'fair' : 'occasional'} match**${m.reasons.length ? ` — ${m.reasons.join(', ').toLowerCase()}` : ''}.${isAllowed(f, profile) ? '' : ` It does **not** fit your ${profile.dietaryPreference}${(profile.dietExtras || []).length ? ' / exclusion' : ''} settings.`}`;
  return head + body + serv + fit;
}

/* ───────────────────────── entity extraction ───────────────────────── */
function slotIn(t) {
  if (/(breakfast|morning|brunch)/.test(t)) return 'breakfast';
  if (/(lunch|afternoon|midday|noon)/.test(t)) return 'lunch';
  if (/(snack|evening|tea ?time|munch|hungry between)/.test(t)) return 'snack';
  if (/(dinner|supper|night|tonight)/.test(t)) return 'dinner';
  return null;
}
function slotByClock(now) { const h = now.getHours() + now.getMinutes() / 60; return h < 10.5 ? 'breakfast' : h < 15.5 ? 'lunch' : h < 18.5 ? 'snack' : 'dinner'; }
function nutrientIn(t) {
  if (/protein/.test(t)) return 'p';
  if (/carb/.test(t)) return 'c';
  if (/\bfat/.test(t)) return 'f';
  if (/fib(re|er)/.test(t)) return 'fiber';
  if (/(calorie|kcal|energy)/.test(t)) return 'kcal';
  return null;
}
const NUT_NAME = { p: 'protein', c: 'carbs', f: 'fat', fiber: 'fibre', kcal: 'calories' };
function filtersIn(t) {
  const f = { tag: 'Any', category: 'All', diet: null };
  if (/(high|rich in|more|lots of) protein|protein[- ]rich|muscle/.test(t)) f.tag = 'High protein';
  else if (/(low|fewer|less) (calorie|cal)|light|diet food|weight loss food/.test(t)) f.tag = 'Low calorie';
  else if (/(fibre|fiber)/.test(t)) f.tag = 'High fibre';
  else if (/low carb/.test(t)) f.tag = 'Low carb';
  if (/fruit/.test(t)) f.category = 'Fruits';
  else if (/(vegetable|veggie|sabzi|greens)/.test(t)) f.category = 'Vegetables';
  else if (/(dairy|milk|curd|cheese|egg)/.test(t)) f.category = 'Dairy & Eggs';
  else if (/(nuts?|seeds?|dry ?fruit)/.test(t)) f.category = 'Nuts & Seeds';
  else if (/(lentil|dal|pulse|legume|beans?|chickpea)/.test(t)) f.category = 'Legumes & Pulses';
  else if (/(grain|cereal|carb|roti|rice|oats|bread)/.test(t) && f.tag !== 'Low carb') f.category = 'Grains & Bakery';
  else if (/(chicken|mutton|meat|poultry)/.test(t)) f.category = 'Meat & Poultry';
  else if (/(fish|seafood|prawn|salmon)/.test(t)) f.category = 'Fish & Seafood';
  if (/\bvegan\b/.test(t)) f.diet = 'Vegan';
  else if (/\b(vegetarian|veg\b)/.test(t) && !/non[- ]?veg/.test(t)) f.diet = 'Vegetarian';
  else if (/non[- ]?veg/.test(t)) f.diet = 'Non-vegetarian';
  return f;
}
const DAY_WORDS = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];

/* ───────────────────────── formatting helpers ───────────────────────── */
const fmtItem = i => `${i.name}${i.type === 'meal' && i.servings !== 1 ? ` (${i.servings} servings)` : ''}`;
const slotLine = s => `**${s.label}** · ${s.time} · ${s.kcal} kcal\n${s.items.length ? s.items.map(i => `- ${fmtItem(i)}`).join('\n') : '- No suitable meal for your settings'}`;
const bar = (v, max) => `${r0(Math.min(1.5, v / Math.max(1, max)) * 100)}%`;
const tickedSlots = ctx => new Set((ctx.todayEntries || []).filter(e => e.kind === 'meal' && e.mealRef).map(e => e.mealRef.split(':')[0]));
const chip = (label, send) => ({ label, send });
const go = (label, page) => ({ label, page });

/* ───────────────────────── intents ───────────────────────── */
function intentOf(t, mem) {
  const I = [];
  const add = (name, w) => I.push([name, w]);
  if (/^(hi|hello|hey|hii+|namaste|good (morning|afternoon|evening)|yo|sup)\b/.test(t)) add('greet', 8);
  if (/\b(thanks|thank you|thx|great|awesome|nice|perfect|cool)\b/.test(t) && t.split(' ').length < 6) add('thanks', 7);
  if (/^(bye|goodbye|see you|good night|cya)\b/.test(t)) add('bye', 8);
  if (/(what can you do|help me|how can you help|what do you know|your features|who are you|what are you|capabilit)/.test(t)) add('help', 9);
  if (/\bbmi\b|body mass|healthy weight range|ideal weight|am i (overweight|underweight|obese)/.test(t)) add('bmi', 9);
  if (/\b(bmr|tdee|maintenance calories|how (are|is) (my )?(calorie|calories).*(calculated|decided|set)|how many calories (do|should) i|calorie (target|goal|need|requirement)|daily calories|why .*calorie target)/.test(t)) add('calorie_target', 9);
  if (/(protein|carb|fat|fibre|fiber|macro).*(target|goal|need|requirement|should i|per day|daily|how much (do|should) i)|how much (protein|carbs?|fat|fibre|fiber) (do|should)|my macros/.test(t)) add('macro_target', 9);
  if (/(water|hydrat|drink).*(target|goal|need|how much|should|daily|per day|enough|left|so far)|how (much|many) (water|glasses)|am i drinking enough/.test(t)) add('water', 9);
  if (/(today'?s?|my) (diet )?(plan|menu)|what('?s| is| should i have| am i eating) (on )?(today|my plan)|plan for (today|tomorrow)|meal plan|menu/.test(t) && !/week/.test(t)) add('plan_today', 8);
  if (slotIn(t) && /(what|which|show|tell|planned|plan|eat|have|menu|my )/.test(t) && !/(idea|option|suggest|alternativ|swap|replace|instead|another|different|recipe|\bvs\b|calorie|protein|healthy|low |high |vegan|vegetarian)/.test(t)) add('plan_slot', 9.5);
  if (/(what|which).*(eat|have|cook|meal).*(now|next|right now)|what should i eat( now)?$|hungry|next meal/.test(t)) add('eat_now', 9);
  if (/(left|remaining|still (need|have)|can i (still )?eat|how much more)/.test(t) && !/week/.test(t)) add('remaining', 8);
  if (/(what|how much).*(did i|have i|i('?ve)?) (eat|eaten|had|consumed|log)|logged today|so far today|today'?s (intake|calories)|calories (so far|today)/.test(t)) add('eaten', 9);
  if (/(weight|kg|lose|loss|progress|journey|track|how am i doing|on track|doing (well|good|ok)|results?|score|streak|badge|achievement|consisten|adherence)/.test(t) && /(my|am i|how|score|streak|badge|progress|journey|track)/.test(t) && !/lose weight (fast|quick)|how to lose|tips/.test(t)) add('progress', 7);
  if (/\b(plateau|stuck|not losing|no change in weight|stopped losing)\b/.test(t)) add('plateau', 10);
  if (/(lose|losing|loss|reduce|cut).*(weight|fat|belly|kg)|weight loss|burn fat|belly fat|fat loss|slim|lean down/.test(t) && /(how|tips|advice|fast|quick|best|should|way)/.test(t)) add('lose_advice', 8);
  if (/(gain|build|bulk|increase).*(weight|muscle|mass)|muscle gain|bulking|underweight|too thin/.test(t) && /(how|tips|advice|best|should|way|diet)/.test(t)) add('gain_advice', 8);
  if (/(maintain|maintenance|stay (the same|fit)|healthy habits)/.test(t)) add('maintain_advice', 6);
  if (/(workout|exercise|gym|walk|run|jog|steps|cardio|yoga|active|activity|fitness|training|strength)/.test(t)) add('exercise', 7);
  if (/(sleep|stress|anxiety|mental|mood|tired|fatigue|energy levels?|motivat)/.test(t)) add('wellbeing', 7);
  if (/(swap|replace|change|different|another|alternative|instead of|don'?t like|bored of).*(breakfast|lunch|snack|dinner|meal|plan|dish)|(breakfast|lunch|snack|dinner|meal) (alternative|option|swap)/.test(t)) add('swap', 9);
  if (/(suggest|recommend|ideas?|options?|what.*(eat|snack|have|cook|can i)|list|show me|which foods?|any (foods?|snacks?)|best foods?|foods? (for|to|that|rich|high|low)|healthy (breakfast|lunch|dinner|snack))/.test(t)) add('recommend', 7);
  if (/(calories|protein|carbs?|fat|fibre|fiber|nutrition|nutrients?|health(y|ier)|good for|is .* (ok|okay|bad|good|safe)|can i eat|should i eat|how many (calories|kcal))/.test(t)) add('food_info', 6);
  if (/(\bvs\b|versus|compare|difference between|which is better|better than)/.test(t)) add('compare', 10);
  if (/(vegetarian|vegan|non[- ]?veg|eggetarian|pescatarian|diet (type|preference)|my diet|dietary|allerg|gluten|lactose|dairy[- ]free|nut[- ]free)/.test(t) && /(my|why|change|set|what|how|can|am i|preference)/.test(t)) add('diet_pref', 7);
  if (/(how (do|can|to) i|where (do|can|is)|can i (log|add|track|change|edit|delete|print|download)|how does (this|the app|welltrack)|what is (the )?(diet tracker|planner|progress|food library|report))/.test(t)) add('how_to', 8);
  if (/(pain|ache|dizzy|faint|vomit|nausea|fever|infection|diagnos|symptom|medicine|medication|tablet|pregnan|breastfeed|thyroid|pcos|pcod|cancer|kidney|liver disease|eating disorder|anorex|bulimi|binge|depress)/.test(t)) add('medical', 11);
  if (/why (is |are )?(this|my|these|the) (plan|meals?|menu)|how (was|is) (this|my) plan (made|built|created)/.test(t)) add('why_plan', 12);
  if (/^(yes|yeah|yep|sure|ok(ay)?|please|go ahead|do it|show me|why|why\??|how come|more|next|another one|and\??)$/.test(t)) add('followup', 12);
  if (/\b(what about|and for|how about|and what about)\b/.test(t)) add('followup', 9);
  return I.sort((a, b) => b[1] - a[1]);
}

/* ───────────────────────── main entry point ───────────────────────── */
export function respond(message, ctx, memory = {}) {
  const raw = String(message || '').trim();
  const t = raw.toLowerCase().replace(/\s+/g, ' ');
  const mem = { ...memory };
  const { profile = {}, summary, planDay } = ctx;
  const targets = summary?.targets || computeTargets(profile);
  const now = ctx.now || new Date();
  const name = first(ctx.user?.name);
  const out = (text, chips = [], patch = {}) => ({ text, chips, memory: { ...mem, ...patch } });

  if (!t) return out('Ask me anything about your meals, calories, water, progress or the foods in the library.', defaultChips(ctx));
  const intents = intentOf(t, mem);
  let intent = intents[0]?.[0] || null;
  const slot = slotIn(t);
  const nutrient = nutrientIn(t);
  const filt = filtersIn(t);
  const shortFollow = t.split(' ').length <= 5 && filt.tag === 'Any' && filt.category === 'All';

  // follow-ups reuse the previous intent with new entities ("what about dinner?", "and protein?", "why?", "more")
  if (intent === 'followup' || (!intent && mem.lastIntent && (slot || nutrient || /^(it|that|this)\b/.test(t)))) {
    if (/^(yes|yeah|yep|sure|ok(ay)?|please|go ahead|do it|show me)$/.test(t) && mem.pending) return runPending(mem.pending, ctx, mem, out);
    if (/^(why|how come)/.test(t) && mem.lastWhy) return out(mem.lastWhy, [chip('What else can I eat?', 'suggest foods for me')]);
    if (/^(more|next|another one)/.test(t) && mem.lastList?.length) {
      const from = mem.listCursor || 0, chunk = mem.lastList.slice(from, from + 5);
      if (!chunk.length) return out('That was everything I have for that search. Try another filter, e.g. "high protein snacks".', defaultChips(ctx));
      return out(`More options:\n${chunk.join('\n')}`, [chip('Show more', 'more')], { listCursor: from + 5 });
    }
    if (mem.lastIntent === 'food_info' && mem.lastFood && shortFollow && (nutrient || /^(it|that|this)\b/.test(t) || intent === 'followup')) {
      const f = foodCandidates(ctx.foods || []).find(x => x.id === mem.lastFood);
      if (f) return out(describeFood(f, ctx, nutrient && nutrient !== 'kcal' ? nutrient : nutrient === 'kcal' ? 'kcal' : null), foodChips(f), { lastIntent: 'food_info' });
    }
    if (slot && ['plan_slot', 'plan_today', 'swap', 'recommend', 'eat_now'].includes(mem.lastIntent)) intent = mem.lastIntent === 'swap' ? 'swap' : mem.lastIntent === 'recommend' ? 'recommend' : 'plan_slot';
    else if (mem.lastIntent && intent === 'followup') intent = mem.lastIntent;
    else if (intent === 'followup') intent = 'help';
  }

  // a bare food name ("paneer", "banana?") → food info
  const foodHit = findFood(raw, ctx.foods || [], { max: 3 });
  if (!intent || intent === 'food_info' || intent === 'recommend') {
    const q = words(t).filter(w => !STOP.has(w) && w.length > 2);
    if (foodHit.length && q.length && q.length <= 4 && !(intent === 'recommend' && (filt.tag !== 'Any' || filt.category !== 'All' || slot))) intent = 'food_info';
  }
  if ((intent === 'food_info' || !intent) && !foodHit.length && !(mem.lastFood && nutrient && shortFollow) && (filt.tag !== 'Any' || filt.category !== 'All' || (slot && filt.diet))) intent = 'recommend';
  if (!intent) {
    const kb = KB.find(([re]) => re.test(t));
    if (kb) return out(kb[1].replace('{fiber}', targets.fiber).replace('{sugarG}', Math.round((targets.calories * 0.1) / 4)) + '\n\n_General guidance — not medical advice._', [chip('Suggest foods for me', 'suggest foods for me')], { lastIntent: 'kb' });
    return out(`I'm not completely sure what you mean, ${name}. I can help with:\n- **Your plan:** "what should I eat for dinner?", "what's left today?"\n- **Food facts:** "calories in paneer", "banana vs apple"\n- **Targets:** "how are my calories calculated?", "how much water?"\n- **Progress:** "how am I doing?", "am I on track?"\n- **Ideas:** "high protein vegetarian snacks"\nTry one of these or rephrase your question.`, defaultChips(ctx), { lastIntent: 'fallback' });
  }

  switch (intent) {
    case 'greet': {
      const hr = now.getHours(), part = hr < 12 ? 'Good morning' : hr < 17 ? 'Good afternoon' : 'Good evening';
      const left = Math.max(0, targets.calories - (summary?.today?.calories || 0));
      return out(`${part}, ${name}! I'm HealthMate. You're on **${profile.goal?.toLowerCase()}** with a daily target of **${targets.calories} kcal** and **${(targets.water / 1000).toFixed(1)} L** of water.${summary ? ` So far today you've logged **${summary.today.calories} kcal** (${left} kcal left).` : ''}\nWhat would you like to know?`, defaultChips(ctx), { lastIntent: 'greet' });
    }
    case 'thanks': return out(`Happy to help, ${name}! Anything else about your meals or progress?`, defaultChips(ctx));
    case 'bye': return out(`Take care, ${name}! Keep going — small steps add up.`);
    case 'help': return out(`I'm **HealthMate**, built into WellTrack. I use your Health profile, today's plan, your logs and the food database to help with:\n- **Plan:** what to eat now, meal details, swaps, what's left today\n- **Numbers:** BMI, calorie, protein and water targets (and how they're calculated)\n- **Foods:** calories and nutrients of any food, comparisons, suggestions for your diet and goal\n- **Progress:** weight journey, streaks, adherence, personalised tips\n- **Wellness:** exercise, sleep, general nutrition questions\nI keep context, so you can ask follow-ups like "what about lunch?" or "and protein?".`, defaultChips(ctx), { lastIntent: 'help' });

    case 'bmi': {
      const bmi = bmiOf(profile);
      if (!bmi) return out('I need your height and weight to calculate BMI. Add them in your Health profile and I\'ll work it out right away.', [go('Open Health profile', 'health')], { lastIntent: 'bmi' });
      const rng = healthyRange(profile.heightCm);
      return out(`Your **BMI is ${bmi.toFixed(1)}** (${bmiLabel(bmi).toLowerCase()}).\nBMI = weight (kg) ÷ height (m)². For your height of ${profile.heightCm} cm, the 18.5–24.9 range corresponds to **${rng.min}–${rng.max} kg**.\nBMI is only a screening number — it does not see muscle, bone or where fat is stored.${profile.targetWeightKg ? ` Your target is **${profile.targetWeightKg} kg**.` : ''}`, [chip('How many calories should I eat?', 'how are my calories calculated'), go('Update my details', 'health')], { lastIntent: 'bmi' });
    }
    case 'calorie_target': {
      if (!targets.complete) return out(`Right now I'm using a default of **${targets.calories} kcal** because your profile is missing: **${targets.missing.join(', ')}**. Add them in Health profile and I'll calculate a personalised target.`, [go('Open Health profile', 'health')], { lastIntent: 'calorie_target' });
      const adj = targets.adjustment;
      const t1 = `Your target is **${targets.calories} kcal/day**${targets.source === 'custom' ? ' (a custom value you set)' : ''}.\n- **BMR** (calories at rest, Mifflin-St Jeor): **${targets.bmr} kcal**\n- × activity (${profile.activityLevel}, ×${ACTIVITY_FACTORS[profile.activityLevel]}) = **TDEE ${targets.tdee} kcal**\n- Goal adjustment (${profile.goal}): **${adj > 0 ? '+' : ''}${adj} kcal**`;
      const note = profile.goal === 'Lose weight' ? `\nThat deficit is roughly **${(Math.abs(adj) * 7 / 7700).toFixed(2)} kg/week** — a sustainable pace.` : profile.goal === 'Gain weight' ? '\nA modest surplus supports gradual, mostly lean gain when paired with strength training.' : '';
      return out(t1 + note + `\nSplit across the day: breakfast ${targets.slotKcal.breakfast}, lunch ${targets.slotKcal.lunch}, snack ${targets.slotKcal.snack}, dinner ${targets.slotKcal.dinner} kcal.`, [chip('Show today\'s plan', 'what is my plan today'), chip('Protein target?', 'how much protein do I need')], { lastIntent: 'calorie_target' });
    }
    case 'macro_target': {
      const td = summary?.today;
      const lines = [['Protein', targets.protein, td?.protein], ['Carbs', targets.carbs, td?.carbs], ['Fat', targets.fat, td?.fat], ['Fibre', targets.fiber, td?.fiber]];
      const sel = nutrient && nutrient !== 'kcal' ? lines.filter(l => l[0].toLowerCase().startsWith({ p: 'pro', c: 'car', f: 'fat', fiber: 'fib' }[nutrient])) : lines;
      return out(`Your daily targets (${targets.split.protein}% protein · ${targets.split.carbs}% carbs · ${targets.split.fat}% fat):\n${sel.map(([n, tg, got]) => `- **${n}: ${tg} g**${td ? ` — ${r0(got || 0)} g logged today (${bar(got || 0, tg)})` : ''}`).join('\n')}\nProtein is set from your weight and goal (${profile.goal === 'Maintain weight' || profile.goal === 'Build healthier habits' ? '≈1.1' : profile.goal === 'Lose weight' ? '≈1.4' : '≈1.5'} g per kg) to protect muscle and keep you full.`, [chip('High protein foods', 'high protein foods for me'), chip('What\'s left today?', 'what is left today')], { lastIntent: 'macro_target' });
    }
    case 'water': {
      const got = summary?.today?.water || 0, goal = targets.water, sched = waterSchedule(goal);
      const nextI = Math.min(sched.length - 1, Math.floor(got / 250));
      const left = Math.max(0, goal - got);
      return out(`Your water goal is **${(goal / 1000).toFixed(2)} L** (${sched.length} glasses of 250 ml), based on ${profile.weightKg ? `${profile.weightKg} kg body weight and ` : ''}your activity.\nToday: **${(got / 1000).toFixed(2)} L** so far — ${left > 0 ? `**${(left / 1000).toFixed(2)} L** to go. Your next glass is due around **${sched[nextI].time}**.` : 'goal reached, well done! 💧'}\nTip: one glass on waking, one with each meal and one after a walk keeps you on track.`, [go('Open Diet tracker', 'meals')], { lastIntent: 'water' });
    }

    case 'plan_today': {
      if (!planDay) return out('I could not load today\'s plan yet.', [go('Open Diet tracker', 'meals')]);
      const done = tickedSlots(ctx);
      const tx = planDay.slots.map(s => `${done.has(s.slot) ? '✅ ' : ''}${slotLine(s)}`).join('\n\n');
      return out(`Here is your personalised plan for today — **${planDay.totals.kcal} kcal**, ${planDay.totals.p} g protein, ${planDay.totals.c} g carbs, ${planDay.totals.f} g fat:\n\n${tx}\n\nWater: ${(targets.water / 1000).toFixed(1)} L through the day.`, [chip('Why this plan?', 'why this plan'), go('Open Diet tracker', 'meals'), chip('Swap my dinner', 'swap my dinner')], { lastIntent: 'plan_today', lastWhy: planWhy(profile, targets) });
    }
    case 'why_plan': return out(planWhy(profile, targets));
    case 'plan_slot': {
      const sl = slot || mem.lastSlot || slotByClock(now);
      const s = planDay?.slots.find(x => x.slot === sl);
      if (!s) return out('Open the Diet tracker to see that meal.', [go('Open Diet tracker', 'meals')]);
      const done = tickedSlots(ctx).has(sl);
      const meal = MEALS.find(m => m.id === s.mealId);
      const why = `${cap(s.label.toLowerCase())} is planned around **${s.targetKcal} kcal** (${r0(SLOT_META[sl].share * 100)}% of your day)${meal ? ` with **${meal.name}**, chosen for your ${profile.dietaryPreference.toLowerCase()} preference and ${profile.goal.toLowerCase()} goal — ${s.p} g protein and ${s.fiber} g fibre.` : '.'}`;
      return out(`${slotLine(s)}\nMacros: protein ${s.p} g · carbs ${s.c} g · fat ${s.f} g · fibre ${s.fiber} g\n${done ? '✅ You have already ticked this meal.' : ''}\n${why}`, [chip(`Alternatives for ${sl}`, `swap my ${sl}`), go('Open Diet tracker', 'meals')], { lastIntent: 'plan_slot', lastSlot: sl, lastWhy: why });
    }
    case 'eat_now': {
      const sl = slotByClock(now), s = planDay?.slots.find(x => x.slot === sl);
      if (!s) return out('Check your Diet tracker for the next meal.', [go('Open Diet tracker', 'meals')]);
      const done = tickedSlots(ctx).has(sl);
      return out(`Around this time your plan has **${s.label.toLowerCase()}** (${s.time}):\n${s.items.map(i => `- ${fmtItem(i)}`).join('\n')}\n**${s.kcal} kcal** · ${s.p} g protein.${done ? '\nYou have already ticked this one ✅ — if you are still hungry, try fruit, curd or a handful of nuts.' : ''}`, [chip('Other options', `swap my ${sl}`), go('Open Diet tracker', 'meals')], { lastIntent: 'eat_now', lastSlot: sl });
    }
    case 'swap': {
      const sl = slot || mem.lastSlot || slotByClock(now);
      const target = targets.slotKcal[sl];
      const cur = planDay?.slots.find(x => x.slot === sl)?.mealId;
      const alts = alternativesFor(profile, sl, target, cur, 4);
      if (!alts.length) return out('I could not find alternatives that match your diet settings for that meal.', [go('Health profile', 'health')]);
      return out(`Alternatives for **${sl}** (about ${target} kcal) that fit your ${profile.dietaryPreference.toLowerCase()} preference:\n${alts.map(a => `- **${a.name}** — ${a.kcal} kcal, ${a.p} g protein`).join('\n')}\nTo apply one, open the Diet tracker or Meal planner and press **Swap** on that meal.`, [go('Open Meal planner', 'planner'), go('Open Diet tracker', 'meals')], { lastIntent: 'swap', lastSlot: sl });
    }
    case 'remaining': {
      const td = summary?.today || { calories: 0, protein: 0, water: 0 };
      const leftK = targets.calories - td.calories, leftP = targets.protein - td.protein, leftW = targets.water - td.water;
      const done = tickedSlots(ctx);
      const nextS = planDay?.slots.filter(s => !done.has(s.slot));
      let tx = `Today so far: **${td.calories} kcal** of ${targets.calories} — ${leftK >= 0 ? `**${leftK} kcal left**` : `**${-leftK} kcal over**`}.\nProtein: ${r0(td.protein)} / ${targets.protein} g${leftP > 0 ? ` (${r0(leftP)} g to go)` : ' ✅'}.\nWater: ${(td.water / 1000).toFixed(2)} / ${(targets.water / 1000).toFixed(2)} L${leftW > 0 ? ` (${(leftW / 1000).toFixed(2)} L to go)` : ' ✅'}.`;
      if (nextS?.length) tx += `\nStill on your plan: ${nextS.map(s => `${s.label.toLowerCase()} (${s.kcal} kcal)`).join(', ')}.`;
      else tx += '\nYou have ticked every meal of today\'s plan — nice work!';
      if (leftP > 25) tx += '\nTo close the protein gap try curd, paneer, eggs, dal, sprouts or a protein-rich snack.';
      return out(tx, [chip('High protein snack', 'high protein snack'), go('Open Diet tracker', 'meals')], { lastIntent: 'remaining' });
    }
    case 'eaten': {
      const meals = (ctx.todayEntries || []).filter(e => e.kind === 'meal');
      if (!meals.length) return out('You have not logged any meals today yet. Open the Diet tracker and tick the meals as you eat them — it takes one tap.', [go('Open Diet tracker', 'meals')], { lastIntent: 'eaten' });
      const tot = summary.today;
      return out(`Logged today:\n${meals.map(m => `- ${m.name} — ${r0(m.calories)} kcal`).join('\n')}\nTotal **${tot.calories} kcal**, ${r0(tot.protein)} g protein, ${r0(tot.carbs)} g carbs, ${r0(tot.fat)} g fat (${bar(tot.calories, targets.calories)} of your target).`, [chip('What\'s left today?', 'what is left today')], { lastIntent: 'eaten' });
    }

    case 'progress': {
      if (!summary) return out('Open the Progress tab to see your journey.', [go('Open Progress', 'progress')]);
      const j = summary.journey, s7 = summary.stats7;
      const lines = [];
      if (j.start && j.current) lines.push(`- **Weight:** ${j.start} → **${j.current} kg**${j.changeKg ? ` (${j.changeKg > 0 ? '+' : ''}${j.changeKg} kg)` : ''}${j.target ? `, target ${j.target} kg${j.pct != null ? ` — **${j.pct}%** of the way, ${j.remaining} kg to go` : ''}` : ''}`);
      if (j.ratePerWeek != null) lines.push(`- **Trend:** ${j.ratePerWeek > 0 ? '+' : ''}${j.ratePerWeek} kg/week${j.etaWeeks ? ` → about ${j.etaWeeks} weeks to target` : ''}`);
      lines.push(`- **Consistency score (7 days):** ${s7.score}/100 · on-target calorie days ${s7.onTargetDays}/7 · water goal ${s7.waterDays}/7 · active ${s7.totalActivity} min`);
      lines.push(`- **Logging streak:** ${summary.streak} day${summary.streak === 1 ? '' : 's'}`);
      const earned = summary.badges.filter(b => b.earned).map(b => b.title);
      if (earned.length) lines.push(`- **Badges:** ${earned.join(', ')}`);
      const verdict = s7.score >= 75 ? 'You are doing really well.' : s7.score >= 50 ? 'Solid progress — a little more consistency will move the needle.' : 'Plenty of room to improve, and that is okay — start by ticking your meals each day.';
      return out(`Here is how you are doing, ${name}:\n${lines.join('\n')}\n${verdict}\n\n**Tip:** ${summary.insights.find(i => i.tone !== 'good')?.text || summary.insights[0].text}`, [go('Open Progress', 'progress'), chip('How can I improve?', 'how can I improve my progress')], { lastIntent: 'progress', lastWhy: summary.insights.map(i => `- ${i.text}`).join('\n') });
    }
    case 'plateau': return out(`Weight plateaus are normal. Try, in this order:\n- Weigh yourself at the same time 1–2 times a week and look at the **2–3 week trend**, not daily changes.\n- Check portions of oil, rice/roti, snacks and drinks — "tiny extras" add up. Tick your meals so the numbers are honest.\n- Make sure protein is about **${targets.protein} g** and sleep is 7–8 h.\n- Add 10–15 minutes of walking or one strength session.\n- If you are already eating close to your minimum, take a short maintenance break rather than cutting further.\nIf nothing changes for 4+ weeks, a dietitian can personalise it.`, [go('Open Progress', 'progress')], { lastIntent: 'plateau' });
    case 'lose_advice': return out(`For sustainable weight loss (your plan targets **${targets.calories} kcal**${targets.adjustment ? `, a ${Math.abs(targets.adjustment)} kcal deficit` : ''}):\n- Aim for **0.25–0.75 kg per week** — faster loss costs muscle and is hard to keep.\n- Build each meal around **protein + vegetables + a measured grain** (your plan does this).\n- Hit about **${targets.protein} g protein** and **${targets.fiber} g fibre** — both keep hunger low.\n- Drink **${(targets.water / 1000).toFixed(1)} L** water; thirst is often mistaken for hunger.\n- Walk daily and add 2 strength sessions a week.\n- Avoid crash diets, skipping meals and "fat burner" products.\n_Spot reduction (belly fat only) is a myth — fat reduces from the whole body._`, [chip('Show my plan', 'what is my plan today'), chip('Low calorie foods', 'low calorie foods for me')], { lastIntent: 'lose_advice' });
    case 'gain_advice': return out(`For healthy weight gain (target **${targets.calories} kcal**):\n- Eat a **small surplus** (~300–400 kcal) and aim for **0.25–0.5 kg/week**.\n- Eat 4–5 times a day; add calorie-dense, nutritious foods — nuts, nut butter, paneer, curd, banana, dates, whole grains, ghee in moderation.\n- Protein about **${targets.protein} g/day**, spread across meals.\n- **Strength training** 3×/week turns the extra calories into muscle.\n- Sleep 7–9 h — growth happens in recovery.`, [chip('Show my plan', 'what is my plan today'), chip('High protein foods', 'high protein foods for me')], { lastIntent: 'gain_advice' });
    case 'maintain_advice': return out(`To maintain your weight, stay near **${targets.calories} kcal/day**, keep protein around ${targets.protein} g, stay active and weigh yourself weekly. If your weight drifts by more than ~2 kg, adjust portions slightly.`, [chip('Show my plan', 'what is my plan today')], { lastIntent: 'maintain_advice' });
    case 'exercise': {
      const mins = summary?.stats7?.totalActivity;
      const lvl = profile.activityLevel;
      const sug = profile.goal === 'Lose weight' ? 'brisk walking or cycling 30–45 min on most days plus 2 strength sessions' : profile.goal === 'Gain weight' ? '3 progressive strength sessions a week with light cardio' : '150 minutes of moderate activity a week plus 2 strength sessions';
      return out(`${mins != null ? `You logged **${mins} active minutes** in the last 7 days (guideline: 150).\n` : ''}For your goal (${profile.goal.toLowerCase()}) and activity level (${lvl.toLowerCase()}), aim for ${sug}.\nStart where you are, increase gradually and include rest days. Log workouts from the Dashboard so they count in your progress.`, [go('Open Progress', 'progress')], { lastIntent: 'exercise' });
    }
    case 'wellbeing': return out('Sleep, stress and food are closely linked: poor sleep raises hunger hormones and cravings, and stress can drive emotional eating. Try a regular bedtime (7–8 h), a short walk or breathing break during stress, and eat enough protein and fibre so energy stays steady. If low mood, anxiety or exhaustion persist, please talk to a doctor or counsellor.', [chip('Foods for steady energy', 'high fibre foods for me')], { lastIntent: 'wellbeing' });

    case 'recommend': {
      const f = { ...filt };
      const prof = f.diet ? { ...profile, dietaryPreference: f.diet } : profile;
      // meal ideas when a meal slot is mentioned without food-type filters, otherwise foods from the library
      if (slot && f.tag === 'Any' && f.category === 'All' && /(meal|idea|dinner|lunch|breakfast|dish|cook|what can i|suggest)/.test(t)) {
        const target = targets.slotKcal[slot];
        const ranked = rankMeals(prof, slot, target).slice(0, 5);
        const lines = ranked.map(({ meal }) => `- **${meal.name}** — ${meal.kcal} kcal, ${meal.p} g protein (${meal.serving})`);
        return out(`Ideas for **${slot}** that fit your ${prof.dietaryPreference.toLowerCase()} preference and ${profile.goal.toLowerCase()} goal (aim ≈ ${target} kcal):\n${lines.join('\n')}`, [chip('Show my planned ' + slot, `what is my ${slot}`), go('Open Meal planner', 'planner')], { lastIntent: 'recommend', lastSlot: slot, lastWhy: `I rank meals by how well their calories fit your ${slot} share, plus protein and fibre for your goal (${profile.goal}).` });
      }
      const res = searchFoods(ctx.foods || [], prof, { category: f.category, tag: f.tag, slot: slot || 'All', limit: 20 });
      if (!res.items.length) return out('I could not find foods matching all of that for your diet settings. Try a broader request, e.g. "high protein foods".', defaultChips(ctx), { lastIntent: 'recommend' });
      const rows = res.items.map(x => `- **${x.name}** — ${x.per100.kcal} kcal, ${x.per100.p} g protein per 100 g${x.match.reasons.length ? ` · ${x.match.reasons[0].toLowerCase()}` : ''}`);
      const label = [f.tag !== 'Any' ? f.tag.toLowerCase() : '', f.category !== 'All' ? f.category.toLowerCase() : 'foods', slot ? `for ${slot}` : ''].filter(Boolean).join(' ');
      return out(`Top ${label} for you (${prof.dietaryPreference.toLowerCase()}, ${profile.goal.toLowerCase()}):\n${rows.slice(0, 5).join('\n')}`, [chip('Show more', 'more'), go('Open Food library', 'foods')], { lastIntent: 'recommend', lastSlot: slot || mem.lastSlot, lastList: rows, listCursor: 5, lastWhy: `I rank the food database by nutrition quality, protein, fibre and calories for your goal (${profile.goal}), then filter by your ${prof.dietaryPreference.toLowerCase()} preference.` });
    }
    case 'compare': {
      const parts = raw.split(/\bvs\.?\b|\bversus\b|\bor\b|\band\b|,|compare|difference between|better than/i).map(x => x.trim()).filter(Boolean);
      const hits = parts.map(p => findFood(p, ctx.foods || [])[0]).filter(Boolean);
      const uniq = [...new Map(hits.map(h => [h.id, h])).values()];
      if (uniq.length < 2) return out('Tell me two foods to compare, e.g. "banana vs apple" or "paneer vs tofu".', [chip('Paneer vs tofu', 'paneer vs tofu'), chip('Roti vs rice', 'roti vs rice')]);
      const [a, b] = uniq, pa = per(a), pb = per(b);
      const unit = a.kind === 'meal' || b.kind === 'meal' ? 'serving' : '100 g';
      const row = (lbl, k, u) => `- ${lbl}: **${pa[k]}** vs **${pb[k]}**${u}`;
      const better = profile.goal === 'Lose weight' ? (pa.kcal / Math.max(1, pa.p) < pb.kcal / Math.max(1, pb.p) ? a : b) : profile.goal === 'Gain weight' ? (pa.kcal > pb.kcal ? a : b) : ((a.score || 6) >= (b.score || 6) ? a : b);
      return out(`**${a.name}** vs **${b.name}** (per ${unit}):\n${row('Calories', 'kcal', ' kcal')}\n${row('Protein', 'p', ' g')}\n${row('Carbs', 'c', ' g')}\n${row('Fat', 'f', ' g')}\n${row('Fibre', 'fiber', ' g')}\nFor your goal (${profile.goal.toLowerCase()}), **${better.name}** has the edge — but portion size matters more than the swap.`, [chip(`Tell me about ${a.name}`, `calories in ${a.name}`)], { lastIntent: 'compare' });
    }
    case 'food_info': {
      if (!foodHit.length && mem.lastFood && nutrient && shortFollow) {
        const lf = foodCandidates(ctx.foods || []).find(x => x.id === mem.lastFood);
        if (lf) return out(describeFood(lf, ctx, nutrient), foodChips(lf), { lastIntent: 'food_info' });
      }
      if (!foodHit.length) {
        const kb = KB.find(([re]) => re.test(t));
        if (kb) return out(kb[1].replace('{fiber}', targets.fiber).replace('{sugarG}', Math.round((targets.calories * 0.1) / 4)) + '\n\n_General guidance — not medical advice._', [chip('Suggest foods for me', 'suggest foods for me')], { lastIntent: 'kb' });
        return out('I could not find that food in my database. Try the Food library search, or ask about a similar food — e.g. "calories in rajma" or "paneer".', [go('Open Food library', 'foods')], { lastIntent: 'food_info' });
      }
      const f = foodHit[0];
      const extra = foodHit.length > 1 ? `\n\nSimilar: ${foodHit.slice(1).map(x => x.name).join(', ')}.` : '';
      return out(describeFood(f, ctx, nutrient) + extra, foodChips(f), { lastIntent: 'food_info', lastFood: f.id, lastWhy: `Scores combine nutrient density, protein, fibre and calories for your goal (${profile.goal}).` });
    }
    case 'diet_pref': {
      const ex = (profile.dietExtras || []).map(x => ({ 'no-dairy': 'dairy-free', 'no-gluten': 'gluten-free', 'no-nuts': 'nut-free', 'low-carb': 'low-carb', 'high-protein': 'high-protein' }[x] || x));
      return out(`Your dietary preference is **${profile.dietaryPreference}**${ex.length ? ` with: ${ex.join(', ')}` : ''}.\n- Allowed food groups: ${allowedDiets(profile.dietaryPreference).map(d => dietLabel(d).toLowerCase()).join(', ')}.\n- The Diet tracker, Meal planner and Food library only suggest foods that fit this.\nYou can change it any time (options: ${DIET_OPTIONS.join(', ')}).`, [go('Change in Health profile', 'health')], { lastIntent: 'diet_pref' });
    }
    case 'how_to': return out(howTo(t), [go('Open Diet tracker', 'meals'), go('Open Meal planner', 'planner')], { lastIntent: 'how_to' });
    case 'medical': return out('I can share general nutrition information, but I cannot diagnose or treat medical conditions, and diet changes for conditions, pregnancy, medicines or eating disorders should be guided by a doctor or registered dietitian. If you feel unwell or this is urgent, please contact a healthcare professional. If thoughts about food or weight are distressing, speaking to a professional or someone you trust can really help.\nI\'m happy to help with general questions in the meantime.', [chip('Foods for steady energy', 'high fibre foods for me')], { lastIntent: 'medical' });
    default: return out('I can help with your plan, targets, foods and progress. What would you like to know?', defaultChips(ctx));
  }
}

function runPending(p, ctx, mem, out) {
  if (p.type === 'swap') return respond(`swap my ${p.slot}`, ctx, mem);
  return out('Okay!', defaultChips(ctx));
}
function planWhy(profile, targets) {
  return `Your plan is built from your Health profile: **${targets.calories} kcal** (${targets.source === 'custom' ? 'your custom target' : 'BMR × activity ± goal'}), split 25% breakfast, 33% lunch, 12% snack, 30% dinner. Meals are chosen from a curated database that fits your **${profile.dietaryPreference.toLowerCase()}** preference${(profile.dietExtras || []).length ? ' and exclusions' : ''}, favouring protein and fibre for **${profile.goal.toLowerCase()}** and avoiding repeats during the week.`;
}
function howTo(t) {
  if (/(log|add|track|tick).*(meal|food|eat)/.test(t)) return 'Open the **Diet tracker**: your personalised meals are already listed — just tap **Mark as eaten** when you have a meal. Ate something else? Use **Add my own meal** (calories and macros) or add a food from the **Food library**.';
  if (/(water|glass)/.test(t)) return 'In the **Diet tracker** (or the Dashboard) tap a water glass or **+250 ml** each time you drink. Tap the last filled glass to undo.';
  if (/(weight|weigh)/.test(t)) return 'Go to **Progress → Record weight**. Weekly entries are enough; the chart and your progress percentage update instantly.';
  if (/(change|set|update).*(goal|diet|preference|calorie|target)|(goal|diet).*(change|set)/.test(t)) return 'Open **Health profile**, change your goal, dietary preference or targets and press **Save profile**. Your plan, planner and food suggestions update automatically.';
  if (/(print|download|pdf|report)/.test(t)) return 'Open **Health reports** and press **Print / Save PDF**. Choose "Save as PDF" in the print dialog.';
  if (/(swap|replace|regenerate|new plan)/.test(t)) return 'In the **Meal planner**, choose a day and press **Swap** on any meal, or **Regenerate week** for a fresh set of meals. Swapped meals respect your diet preferences.';
  if (/(grocery|shopping|checklist)/.test(t)) return 'The **Meal planner** builds a weekly prep checklist from your planned meals. Tick dishes off as you shop or cook.';
  if (/demo/.test(t)) return 'The demo account (demo@welltrack.app) has a full 90-day history so you can explore every tab.';
  return 'WellTrack tabs: **Dashboard** (today at a glance), **Health profile** (your details → targets), **Diet tracker** (today\'s personalised plan), **Progress**, **Food library**, **Meal planner**, **Health reports** and **HealthMate** (me).';
}
function foodChips(f) { return [chip('Protein in it?', `how much protein in ${f.name}`), chip('Healthier alternatives', 'suggest foods for me'), go('Open Food library', 'foods')]; }
export function defaultChips(ctx) {
  const slot = slotByClock(ctx?.now || new Date());
  return [chip(`What's my ${slot}?`, `what is my ${slot}`), chip("What's left today?", 'what is left today'), chip('How am I doing?', 'how am I doing'), chip('High protein foods', 'high protein foods for me')];
}
export function welcomeMessage(ctx) {
  const name = first(ctx.user?.name), t = ctx.summary?.targets || computeTargets(ctx.profile);
  return { text: `Hi ${name}! I'm **HealthMate** 👋 I know your profile (**${ctx.profile.goal.toLowerCase()}**, ${ctx.profile.dietaryPreference.toLowerCase()}), today's plan (**${t.calories} kcal**) and your progress. Ask me anything — for example "what should I eat for dinner?" or "is paneer good for weight loss?".`, chips: defaultChips(ctx) };
}
