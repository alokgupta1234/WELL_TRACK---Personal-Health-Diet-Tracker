// Demo account definition + a deterministic generator of 90 days of realistic history.
// Used by the API (to seed MongoDB) – the demo user is a normal account in the database.
import { computeTargets, planForDate, addDays, rngFrom, SLOTS, SLOT_META, waterSchedule } from './engine.mjs';

export const DEMO_EMAIL = 'demo@welltrack.app';
export const DEMO_PASSWORD = 'Demo@12345';
export const DEMO_NAME = 'Aarav Sharma';
export const DEMO_PROFILE = {
  age: 29, gender: 'Male', heightCm: 176, weightKg: 78.4, targetWeightKg: 74, activityLevel: 'Moderately active',
  dietaryPreference: 'Vegetarian', goal: 'Lose weight', dietExtras: ['high-protein'], customTargets: false,
  calorieGoal: 2000, waterGoalMl: 2000,
};

const OFF_PLAN = [
  { name: 'Samosa (1 piece)', calories: 260, protein: 4, carbs: 28, fat: 14, fiber: 2 },
  { name: 'Masala chai with 2 biscuits', calories: 170, protein: 3, carbs: 26, fat: 6, fiber: 0.5 },
  { name: 'Gulab jamun (1 piece)', calories: 150, protein: 2, carbs: 22, fat: 6, fiber: 0 },
  { name: 'Fruit juice (1 glass)', calories: 120, protein: 1, carbs: 28, fat: 0, fiber: 0.3 },
];
const ACTIVITIES = [['Walking', 25, 50], ['Yoga', 20, 40], ['Cycling', 30, 60], ['Gym workout', 35, 60], ['Jogging', 20, 35]];

/**
 * @param {string} today  YYYY-MM-DD
 * @param {number} hour   current hour (0-23) – today's log only contains what a real user would have done by now
 * @returns {{profile, entries, planPrefs}}
 */
export function buildDemoData(today, hour = 12) {
  const profile = { ...DEMO_PROFILE };
  const targets = computeTargets(profile);
  const entries = [];
  const DAYS = 90;
  const startW = 84.2, endW = profile.weightKg;
  const at = (dateKey, h, m = 0) => { const [y, mo, d] = dateKey.split('-').map(Number); return new Date(y, mo - 1, d, h, m); };
  const push = (dateKey, h, m, e) => entries.push({ dateKey, mealRef: '', category: '', notes: '', amount: 0, calories: 0, protein: 0, carbs: 0, fat: 0, fiber: 0, name: '', createdAt: at(dateKey, h, m), ...e });

  for (let i = 0; i < DAYS; i++) {
    const dateKey = addDays(today, -(DAYS - 1 - i));
    const isToday = dateKey === today;
    const rng = rngFrom(`demo|${dateKey}`);
    const recent = i >= DAYS - 14;
    const logged = recent || rng() < 0.9;

    // weight: every third day + today, steady downward trend with noise
    if (i % 3 === 0 || isToday) {
      const t = i / (DAYS - 1);
      const kg = isToday ? endW : Math.round((startW - (startW - endW) * t + (rng() - 0.5) * 0.5) * 10) / 10;
      push(dateKey, 7, 10, { kind: 'weight', name: 'Weight', amount: kg });
    }
    // meals – ticked from the personalised plan
    if (logged) {
      const day = planForDate(profile, dateKey, { seed: 0 });
      const prob = { breakfast: 0.95, lunch: 0.96, snack: 0.88, dinner: 0.94 };
      for (const slot of day.slots) {
        const done = isToday ? hour >= { breakfast: 9, lunch: 14, snack: 18, dinner: 21 }[slot.slot] : rng() < prob[slot.slot];
        if (!done || !slot.items.length) continue;
        const h = +SLOT_META[slot.slot].time.slice(0, 2);
        push(dateKey, h, 20, { kind: 'meal', name: slot.items.map(x => x.name).join(' + ').slice(0, 100), calories: slot.kcal, protein: slot.p, carbs: slot.c, fat: slot.f, fiber: slot.fiber, category: slot.slot, mealRef: `${slot.slot}:${slot.mealId}` });
      }
      if (!isToday && rng() < 0.18) {
        const o = OFF_PLAN[Math.floor(rng() * OFF_PLAN.length)];
        push(dateKey, 16, 30, { kind: 'meal', category: 'snack', ...o });
      }
    }
    // water – 250 ml glasses spread through the day
    const frac = isToday ? Math.min(1, Math.max(0, (hour - 7) / 14)) * (0.9 + rng() * 0.15) : rng() < 0.12 ? 0.5 + rng() * 0.2 : 0.78 + rng() * 0.3;
    const glasses = Math.round((targets.water * frac) / 250);
    const sched = waterSchedule(targets.water);
    for (let g = 0; g < glasses; g++) {
      const [hh, mm] = (sched[g % sched.length]?.time || '12:00').split(':').map(Number);
      push(dateKey, hh, mm, { kind: 'water', name: 'Water', amount: 250 });
    }
    // activity
    if (rng() < (isToday ? (hour >= 8 ? 0.7 : 0) : 0.62)) {
      const [name, lo, hi] = ACTIVITIES[Math.floor(rng() * ACTIVITIES.length)];
      push(dateKey, 18, 0, { kind: 'activity', name, amount: Math.round(lo + rng() * (hi - lo)) });
    }
  }
  return { profile, entries, planPrefs: { seed: 0, picks: {} } };
}
