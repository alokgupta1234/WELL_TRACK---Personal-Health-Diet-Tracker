// Curated meal database used by the diet engine, meal planner and HealthMate.
// Nutrition values are typical, rounded estimates for ONE serving (home-style portions).
// Slots: B breakfast · L lunch · S snack · D dinner
// Diet:  V vegan · G vegetarian (dairy/honey) · E eggetarian · F fish · N non-vegetarian
// Row:   name, slots, diet, kcal, protein g, carbs g, fat g, fibre g, grams, serving description, allergens

const DIET = { V: 'vegan', G: 'veg', E: 'egg', F: 'fish', N: 'nonveg' };
const SLOT = { B: 'breakfast', L: 'lunch', S: 'snack', D: 'dinner' };

const ROWS = [
  // ---------------- breakfast ----------------
  ['Vegetable poha with peanuts', 'B', 'V', 280, 7, 46, 8, 4, 220, '1 plate', 'nuts'],
  ['Besan chilla with mint chutney', 'B', 'V', 270, 13, 30, 11, 5, 180, '2 chillas', ''],
  ['Paneer-stuffed moong dal chilla', 'B', 'G', 330, 20, 28, 15, 5, 190, '2 chillas', 'dairy'],
  ['Idli with sambar', 'B', 'V', 290, 10, 54, 3, 5, 330, '3 idlis + 1 bowl sambar', ''],
  ['Masala oats with vegetables', 'B', 'V', 240, 9, 38, 6, 6, 250, '1 bowl', 'gluten'],
  ['Vegetable upma', 'B', 'V', 260, 6, 42, 8, 4, 230, '1 bowl', 'gluten'],
  ['Aloo paratha with curd', 'B', 'G', 390, 11, 52, 15, 5, 230, '1 paratha + 100 g curd', 'dairy,gluten'],
  ['Greek yogurt parfait with fruit & nuts', 'B', 'G', 290, 18, 33, 9, 4, 250, '1 glass', 'dairy,nuts'],
  ['Overnight oats with milk, chia & banana', 'B', 'G', 340, 14, 50, 9, 8, 300, '1 jar', 'dairy,gluten'],
  ['Overnight oats with almond milk & chia', 'B', 'V', 310, 10, 46, 10, 9, 300, '1 jar', 'gluten,nuts'],
  ['Peanut butter banana toast', 'B', 'V', 350, 12, 48, 13, 7, 190, '2 slices', 'gluten,nuts'],
  ['Berry banana smoothie bowl with seeds', 'B', 'V', 290, 8, 50, 8, 9, 350, '1 bowl', ''],
  ['Tofu scramble with whole-wheat toast', 'B', 'V', 310, 21, 26, 14, 5, 230, '1 plate + 1 toast', 'gluten,soy'],
  ['Dalia (broken wheat) porridge with vegetables', 'B', 'V', 240, 8, 44, 3, 7, 250, '1 bowl', 'gluten'],
  ['Ragi dosa with coconut chutney', 'B', 'V', 260, 6, 44, 7, 5, 200, '2 dosas', ''],
  ['Sprouts moong salad with lemon', 'BS', 'V', 200, 13, 30, 2, 8, 200, '1 bowl', ''],
  ['Vegetable omelette with toast', 'B', 'E', 340, 19, 28, 17, 4, 240, '2-egg omelette + 2 toast', 'egg,gluten'],
  ['Egg bhurji with roti', 'B', 'E', 380, 20, 34, 18, 5, 250, '2-egg bhurji + 2 roti', 'egg,gluten'],
  ['Boiled eggs with fruit & toast', 'B', 'E', 320, 17, 31, 13, 4, 280, '2 eggs + 1 toast + 1 fruit', 'egg,gluten'],
  ['Egg-white omelette with oats porridge', 'B', 'E', 300, 24, 30, 7, 5, 300, '4 whites + 1 bowl oats', 'egg,gluten'],
  ['Smoked salmon & cucumber toast', 'B', 'F', 330, 22, 26, 14, 3, 180, '2 open toasts', 'fish,gluten'],
  ['Chicken & vegetable sandwich', 'B', 'N', 360, 26, 38, 10, 5, 220, '1 whole-wheat sandwich', 'gluten'],

  // ---------------- lunch ----------------
  ['Dal tadka with roti & cucumber salad', 'L', 'V', 440, 18, 70, 10, 11, 420, '1 bowl dal + 2 roti + salad', 'gluten'],
  ['Rajma chawal with salad', 'L', 'V', 490, 17, 82, 8, 12, 400, '1 bowl rajma + 1 cup rice', ''],
  ['Chole with roti & onion salad', 'L', 'V', 480, 18, 72, 12, 13, 400, '1 bowl chole + 2 roti', 'gluten'],
  ['Paneer bhurji with roti & salad', 'L', 'G', 530, 26, 44, 25, 7, 380, '1 bowl + 2 roti', 'dairy,gluten'],
  ['Mixed vegetable curry, roti & curd', 'L', 'G', 450, 15, 62, 15, 8, 420, '1 bowl + 2 roti + curd', 'dairy,gluten'],
  ['Vegetable quinoa pulao with raita', 'L', 'G', 430, 15, 66, 11, 8, 380, '1 plate + raita', 'dairy'],
  ['Soya chunk curry with brown rice', 'L', 'V', 490, 31, 62, 12, 10, 380, '1 bowl + 1 cup rice', 'soy'],
  ['Palak paneer with roti', 'L', 'G', 520, 24, 46, 26, 8, 380, '1 bowl + 2 roti', 'dairy,gluten'],
  ['Masoor dal soup with multigrain toast & salad', 'L', 'V', 380, 20, 58, 7, 14, 400, '1 bowl + 2 toast', 'gluten'],
  ['Curd rice with vegetable thoran', 'L', 'G', 390, 12, 62, 10, 4, 380, '1 plate', 'dairy'],
  ['Chickpea quinoa salad bowl', 'L', 'V', 410, 16, 56, 14, 12, 350, '1 large bowl', ''],
  ['Tofu & vegetable stir-fry with brown rice', 'L', 'V', 460, 25, 56, 15, 8, 380, '1 plate', 'soy'],
  ['Moong dal khichdi with curd', 'LD', 'G', 400, 16, 62, 9, 7, 380, '1 bowl + curd', 'dairy'],
  ['Veg burrito bowl (rajma, rice, salsa)', 'L', 'V', 470, 16, 80, 9, 13, 400, '1 bowl', ''],
  ['Aloo gobi with dal & roti', 'L', 'V', 470, 14, 76, 12, 10, 450, '1 plate', 'gluten'],
  ['Egg curry with roti', 'L', 'E', 490, 24, 48, 21, 7, 400, '2-egg curry + 2 roti', 'egg,gluten'],
  ['Grilled chicken with brown rice & vegetables', 'L', 'N', 520, 42, 55, 12, 6, 420, '1 plate', ''],
  ['Chicken curry with roti & salad', 'L', 'N', 540, 38, 50, 20, 7, 430, '1 bowl + 2 roti', 'gluten'],
  ['Chicken tikka salad bowl', 'L', 'N', 400, 38, 20, 18, 5, 350, '1 large bowl', ''],
  ['Fish curry with steamed rice', 'L', 'F', 500, 32, 56, 15, 3, 400, '1 bowl + 1 cup rice', 'fish'],
  ['Grilled fish with quinoa & greens', 'L', 'F', 460, 38, 40, 14, 6, 380, '1 plate', 'fish'],
  ['Light chicken biryani with raita', 'L', 'N', 560, 30, 70, 16, 4, 420, '1 plate + raita', 'dairy'],
  ['Tandoori chicken with roti & salad', 'L', 'N', 430, 40, 28, 16, 5, 350, '2 pieces + 1 roti + salad', 'gluten'],
  ['Tuna salad sandwich', 'L', 'F', 420, 30, 38, 14, 6, 280, '1 whole-wheat sandwich', 'fish,gluten'],

  // ---------------- snacks ----------------
  ['Roasted chana', 'S', 'V', 150, 8, 23, 3, 7, 40, '1 small bowl (40 g)', ''],
  ['Seasonal fruit bowl (apple, papaya, orange)', 'S', 'V', 130, 2, 31, 0.5, 6, 250, '1 bowl', ''],
  ['Almonds & walnuts', 'S', 'V', 190, 6, 6, 17, 4, 30, '1 handful (30 g)', 'nuts'],
  ['Sprouts chaat', 'S', 'V', 160, 10, 26, 2, 8, 150, '1 bowl', ''],
  ['Greek yogurt with berries', 'S', 'G', 150, 14, 16, 3, 2, 180, '1 cup', 'dairy'],
  ['Buttermilk with roasted makhana', 'S', 'G', 140, 5, 21, 3, 2, 250, '1 glass + 1 small bowl', 'dairy'],
  ['Apple slices with peanut butter', 'S', 'V', 220, 6, 24, 12, 5, 180, '1 apple + 1 tbsp', 'nuts'],
  ['Hummus with carrot & cucumber sticks', 'S', 'V', 170, 6, 17, 9, 5, 150, '1 bowl', ''],
  ['Banana-milk protein smoothie', 'S', 'G', 250, 12, 34, 8, 3, 300, '1 large glass', 'dairy'],
  ['Grilled paneer cubes', 'S', 'G', 170, 11, 3, 13, 0, 60, '60 g', 'dairy'],
  ['Roasted makhana', 'S', 'V', 110, 4, 22, 0.5, 2, 30, '1 bowl (30 g)', ''],
  ['Date & nut energy balls', 'S', 'V', 200, 4, 28, 9, 3, 50, '2 balls', 'nuts'],
  ['Soy milk with banana', 'S', 'V', 190, 8, 33, 4, 4, 380, '1 glass + 1 banana', 'soy'],
  ['Roasted peanuts', 'S', 'V', 170, 7, 5, 14, 3, 30, '1 handful (30 g)', 'nuts'],
  ['Masala corn cup', 'S', 'V', 150, 5, 27, 3, 4, 150, '1 cup', ''],
  ['Clear vegetable soup', 'S', 'V', 90, 3, 14, 2, 4, 250, '1 bowl', ''],
  ['Cucumber-tomato whole-wheat sandwich', 'S', 'V', 190, 7, 33, 3, 5, 150, '1 sandwich', 'gluten'],
  ['Boiled eggs with black pepper', 'S', 'E', 155, 13, 1, 11, 0, 100, '2 eggs', 'egg'],
  ['Chicken tikka bites', 'S', 'N', 190, 30, 4, 6, 1, 130, '5 pieces', ''],
  ['Tuna & cucumber bites', 'S', 'F', 140, 22, 5, 3, 1, 120, '1 plate', 'fish'],

  // ---------------- dinner ----------------
  ['Vegetable daliya khichdi', 'D', 'V', 340, 12, 60, 5, 9, 350, '1 bowl', 'gluten'],
  ['Moong dal, roti & seasonal sabzi', 'D', 'V', 410, 17, 66, 8, 10, 400, '1 bowl + 2 roti + sabzi', 'gluten'],
  ['Paneer tikka with grilled vegetables & roti', 'D', 'G', 440, 27, 31, 22, 6, 320, '5 pieces + 1 roti', 'dairy,gluten'],
  ['Tofu & vegetable stir-fry with quinoa', 'D', 'V', 400, 22, 44, 14, 8, 360, '1 plate', 'soy'],
  ['Lauki sabzi, dal & roti', 'D', 'V', 380, 15, 62, 8, 10, 420, '1 plate', 'gluten'],
  ['Palak dal with roti & salad', 'D', 'V', 350, 17, 52, 8, 12, 380, '1 bowl + 1 roti', 'gluten'],
  ['Soya keema with roti', 'D', 'V', 430, 30, 48, 12, 10, 360, '1 bowl + 2 roti', 'soy,gluten'],
  ['Mushroom-peas pulao with raita', 'D', 'G', 430, 13, 70, 11, 6, 380, '1 plate + raita', 'dairy'],
  ['Sweet potato & chickpea curry with rice', 'D', 'V', 430, 13, 74, 8, 11, 380, '1 bowl + 1/2 cup rice', ''],
  ['Vegetable omelette with roti', 'D', 'E', 390, 22, 36, 18, 6, 300, '2-egg omelette + 2 roti', 'egg,gluten'],
  ['Egg & vegetable fried brown rice', 'D', 'E', 440, 18, 60, 14, 5, 320, '1 plate', 'egg'],
  ['Grilled chicken with sautéed veg & sweet potato', 'D', 'N', 450, 42, 40, 11, 7, 400, '1 plate', ''],
  ['Chicken & vegetable stew with toast', 'D', 'N', 390, 32, 36, 11, 6, 400, '1 bowl + 1 toast', 'gluten'],
  ['Fish tikka with salad & roti', 'D', 'F', 400, 36, 28, 15, 5, 320, '4 pieces + 1 roti', 'fish,gluten'],
  ['Chicken keema with roti', 'D', 'N', 480, 36, 46, 17, 7, 340, '1 bowl + 2 roti', 'gluten'],
  ['Prawn stir-fry with vegetables & rice', 'D', 'F', 430, 30, 52, 10, 5, 380, '1 plate', 'fish'],
  ['Baked salmon with roasted vegetables', 'D', 'F', 470, 36, 24, 26, 6, 330, '1 fillet + vegetables', 'fish'],
  ['Chicken & vegetable soup with toast', 'D', 'N', 330, 28, 32, 8, 5, 400, '1 bowl + 1 toast', 'gluten'],
];

export const MEALS = ROWS.map(([name, slots, d, kcal, p, c, f, fiber, grams, serving, allergens], i) => ({
  id: 'm' + String(i + 1).padStart(3, '0'),
  name, slots: [...slots].map(s => SLOT[s]), diet: DIET[d], kcal, p, c, f, fiber, grams, serving,
  contains: allergens ? allergens.split(',') : [],
}));

// Small add-ons used to top up a slot when one serving of the main meal is not enough.
const SIDE_ROWS = [
  ['1 banana', 'V', 100, 1.2, 26, 0.3, 3, 120, ''],
  ['1 glass of milk', 'G', 125, 6.5, 10, 6.5, 0, 200, 'dairy'],
  ['1 glass of soy milk', 'V', 100, 7, 6, 4, 1, 200, 'soy'],
  ['A handful of almonds', 'V', 90, 3, 3, 8, 2, 15, 'nuts'],
  ['1 whole-wheat roti', 'V', 100, 3.5, 18, 2, 3, 40, 'gluten'],
  ['1 bowl of curd', 'G', 75, 4, 5, 4, 0, 100, 'dairy'],
  ['1 boiled egg', 'E', 78, 6.3, 0.6, 5.3, 0, 50, 'egg'],
  ['1 apple', 'V', 80, 0.4, 21, 0.3, 3.5, 150, ''],
  ['1 tbsp peanut butter', 'V', 95, 4, 3, 8, 1, 16, 'nuts'],
  ['Half cup cooked rice', 'V', 120, 2.5, 26, 0.3, 0.5, 90, ''],
  ['Grilled chicken (60 g)', 'N', 100, 19, 0, 2, 0, 60, ''],
  ['Seasonal fruit bowl', 'V', 90, 1, 22, 0.3, 3, 200, ''],
  ['A bowl of Greek yogurt', 'G', 100, 10, 6, 3, 0, 150, 'dairy'],
  ['Paneer cubes (50 g)', 'G', 130, 9, 2, 10, 0, 50, 'dairy'],
  ['A bowl of boiled chickpeas', 'V', 140, 7.5, 23, 2, 6, 100, ''],
  ['A bowl of sprouts', 'V', 100, 8, 17, 0.5, 4, 100, ''],
  ['2 egg whites', 'E', 34, 7, 0.5, 0, 0, 66, 'egg'],
  ['Plant-protein shake (1 scoop)', 'V', 120, 20, 4, 2, 1, 250, 'soy'],
  ['Whey protein shake (1 scoop)', 'G', 130, 24, 3, 2, 0, 250, 'dairy'],
  ['Boiled soya chunks (50 g dry)', 'V', 170, 26, 12, 0.5, 6, 150, 'soy'],
  ['A small tin of tuna (80 g)', 'F', 90, 20, 0, 1, 0, 80, 'fish'],
];
export const SIDES = SIDE_ROWS.map(([name, d, kcal, p, c, f, fiber, grams, allergens], i) => ({
  id: 'x' + String(i + 1).padStart(2, '0'), name, diet: DIET[d], kcal, p, c, f, fiber, grams,
  contains: allergens ? allergens.split(',') : [],
}));
