// Creates / refreshes the demo account in MongoDB. The demo user is a normal account: same schema, same API.
import bcrypt from 'bcryptjs';
import { buildDemoData, DEMO_EMAIL, DEMO_PASSWORD, DEMO_NAME } from '../../shared/demo.mjs';
import { todayKey } from '../../shared/engine.mjs';

export async function seedDemo({ User, Entry }) {
  const now = new Date();
  const today = todayKey(now);
  const { profile, entries, planPrefs } = buildDemoData(today, now.getHours());
  let user = await User.findOne({ email: DEMO_EMAIL });
  const passwordHash = await bcrypt.hash(DEMO_PASSWORD, 10);
  if (!user) user = new User({ name: DEMO_NAME, email: DEMO_EMAIL, passwordHash, profile });
  user.name = DEMO_NAME; user.passwordHash = passwordHash; user.profile = profile; user.planPrefs = planPrefs;
  user.isDemo = true; user.demoSeededOn = today; user.passwordResetTokenHash = null; user.passwordResetExpires = null;
  await user.save();
  await Entry.deleteMany({ userId: user._id });
  const stamped = entries.map(e => ({ ...e, userId: user._id, updatedAt: e.createdAt }));
  // native insert keeps the historical createdAt timestamps
  await Entry.collection.insertMany(stamped);
  return { userId: user._id.toString(), entries: stamped.length };
}
