Nutrition data is currently supplied by the frontend sample file at src/data/foods.json. Replace it with a curated/licensed Kaggle dataset as required by your final submission.
