// API integration test – runs the REAL Express routes against an in-memory stand-in for MongoDB (no database needed).
// Run:  node test/api.test.mjs
import mongoose from 'mongoose';

import { installFakeMongoose } from './fakeMongoose.mjs';
installFakeMongoose();

process.env.PORT = '5055'; process.env.MONGO_URI = 'mongodb://x/x'; process.env.JWT_SECRET = 'test-secret-test-secret-test-secret'; process.env.SEED_DEMO = 'true'; process.env.ANTHROPIC_API_KEY = '';
await import('../src/server.js');
await new Promise(r => setTimeout(r, 2500)); // let the demo seeding finish

const base = 'http://localhost:5055/api';
let failures = 0, checks = 0;
const ok = (c, m) => { checks++; if (!c) { failures++; console.error('  ✗ FAIL:', m); } };
const call = async (path, { method = 'GET', body, token } = {}) => {
  const r = await fetch(base + path, { method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  return { status: r.status, data: await r.json().catch(() => ({})) };
};
const key = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const today = key(new Date()); const ago = n => key(new Date(Date.now() - n * 864e5));

ok((await call('/health')).status === 200, 'health endpoint');
ok((await call('/entries')).status === 401, 'entries require auth');
ok((await call('/auth/login', { method: 'POST', body: { email: 'demo@welltrack.app', password: 'wrong-pass' } })).status === 401, 'wrong password rejected');

const login = await call('/auth/login', { method: 'POST', body: { email: 'demo@welltrack.app', password: 'Demo@12345' } });
ok(login.status === 200 && login.data.token, 'demo account can sign in with the published credentials');
ok(login.data.user?.name === 'Aarav Sharma', `demo user name is returned (${login.data.user?.name})`);
const token = login.data.token;

const prof = await call('/profile', { token });
ok(prof.data.profile?.dietaryPreference === 'Vegetarian' && prof.data.profile?.goal === 'Lose weight' && prof.data.profile?.targetWeightKg === 74, 'demo profile is pre-filled in the database');

const range = await call(`/entries?from=${ago(89)}&to=${today}`, { token });
const kinds = range.data.entries.reduce((m, e) => ((m[e.kind] = (m[e.kind] || 0) + 1), m), {});
ok(range.data.entries.length > 500, `demo has 90 days of history (${range.data.entries.length} records)`);
ok(kinds.meal > 200 && kinds.water > 300 && kinds.activity > 30 && kinds.weight >= 30, `all record types present ${JSON.stringify(kinds)}`);
ok(range.data.entries.some(e => e.mealRef), 'plan meals carry a mealRef');
ok((await call('/entries?from=bad&to=worse', { token })).status === 400, 'bad range dates rejected');
ok((await call(`/entries?from=${today}&to=${ago(3)}`, { token })).status === 400, 'inverted range rejected');
ok((await call(`/entries?date=${today}`, { token })).data.entries.every(e => e.dateKey === today), 'single-day query works');

const created = await call('/entries', { method: 'POST', token, body: { kind: 'meal', name: 'Test meal', calories: 321, protein: 12, carbs: 40, fat: 9, fiber: 3, category: 'lunch', mealRef: 'lunch:m001', dateKey: today } });
ok(created.status === 201 && created.data.entry.mealRef === 'lunch:m001', 'meal entry with mealRef is stored');
ok((await call('/entries', { method: 'POST', token, body: { kind: 'meal', name: '', calories: 1 } })).status === 400, 'meal without name rejected');
ok((await call('/entries', { method: 'POST', token, body: { kind: 'weight', amount: 5 } })).status === 400, 'implausible weight rejected');
ok((await call('/entries', { method: 'POST', token, body: { kind: 'water', amount: -5 } })).status === 400, 'negative amount rejected');
ok((await call(`/entries/${created.data.entry._id}`, { method: 'DELETE', token })).status === 200, 'entry can be deleted');
ok((await call('/entries/not-an-id', { method: 'DELETE', token })).status === 400, 'invalid id rejected');

const put = await call('/profile', { method: 'PUT', token, body: { goal: 'Maintain weight', dietExtras: ['no-nuts', 'hacker'], customTargets: true, calorieGoal: 2100, name: 'Aarav S' } });
ok(put.status === 200 && put.data.profile.goal === 'Maintain weight', 'profile update saved');
ok(JSON.stringify(put.data.profile.dietExtras) === '["no-nuts"]', 'unknown diet extras are filtered out');
ok(put.data.profile.customTargets === true && put.data.user.name === 'Aarav S', 'custom targets + name updated');

const pp = await call('/plan-prefs', { method: 'PUT', token, body: { seed: 3, picks: { [today]: { lunch: 'm012', brunch: 'm001', dinner: '<script>' }, 'not-a-date': { lunch: 'm001' } } } });
ok(pp.data.planPrefs.seed === 3 && pp.data.planPrefs.picks[today]?.lunch === 'm012', 'plan preferences saved');
ok(!pp.data.planPrefs.picks[today].brunch && !pp.data.planPrefs.picks[today].dinner && !pp.data.planPrefs.picks['not-a-date'], 'plan preferences are sanitised');
ok((await call('/plan-prefs', { token })).data.planPrefs.seed === 3, 'plan preferences persist');

ok((await call('/chat/status', { token })).data.ai === false, 'chat status: AI off without API key');
const chat = await call('/chat', { method: 'POST', token, body: { messages: [{ role: 'user', content: 'hi' }] } });
ok(chat.status === 501 && chat.data.mode === 'local', 'chat endpoint tells the client to use the on-device assistant');

const reg = await call('/auth/register', { method: 'POST', body: { name: 'New Person', email: 'new@x.com', password: 'longenough1' } });
ok(reg.status === 201 || reg.status === 200, `registration works (${reg.status})`);
const t2 = reg.data.token;
ok((await call(`/entries?from=${ago(89)}&to=${today}`, { token: t2 })).data.entries.length === 0, 'new account starts empty and cannot see demo data');
ok((await call('/plan-prefs', { token: t2 })).data.planPrefs.seed === 0, 'new account has default plan prefs');
const fp = await call('/auth/forgot-password', { method: 'POST', body: { email: 'demo@welltrack.app' } });
ok(fp.status < 500 || fp.status === 503, 'demo account is excluded from password reset');

let limited = 0; for (let i = 0; i < 14; i++) { const r = await call('/auth/login', { method: 'POST', body: { email: 'nobody@x.com', password: 'badpassword' } }); if (r.status === 429) limited++; }
ok(limited >= 1, 'login rate limit kicks in after repeated failures');

console.log(`\n${checks - failures}/${checks} API checks passed`);
process.exit(failures ? 1 : 0);
