// In-memory stand-in for the parts of Mongoose that WellTrack uses (tests only – never used in production).
import mongoose from 'mongoose';
export function installFakeMongoose() {
const stores = {};
const matches = (doc, q) => Object.entries(q).every(([k, v]) => {
  const val = doc[k];
  if (v && typeof v === 'object' && !(v instanceof Date) && !(v instanceof mongoose.Types.ObjectId)) {
    if ('$gte' in v && !(val >= v.$gte)) return false; if ('$lte' in v && !(val <= v.$lte)) return false; return true;
  }
  return String(val) === String(v);
});
const chain = (get) => { const c = { select() { return c; }, sort(s) { c._sort = s; return c; }, limit(n) { c._limit = n; return c; }, then(res, rej) { return Promise.resolve(get(c)).then(res, rej); } }; return c; };
mongoose.connect = async () => mongoose;
mongoose.model = (name, schema) => {
  const store = (stores[name] ||= []);
  const defaults = () => name === 'User'
    ? { profile: { age: null, gender: 'Prefer not to say', heightCm: null, weightKg: null, activityLevel: 'Moderately active', dietaryPreference: 'No preference', goal: 'Maintain weight', calorieGoal: 2000, waterGoalMl: 2000, customTargets: false, targetWeightKg: null, dietExtras: [] }, planPrefs: { seed: 0, picks: {} }, isDemo: false, demoSeededOn: '', passwordResetTokenHash: null, passwordResetExpires: null }
    : { name: '', amount: 0, calories: 0, protein: 0, carbs: 0, fat: 0, fiber: 0, category: '', mealRef: '', notes: '' };
  class M {
    constructor(doc = {}) { Object.assign(this, defaults(), doc); this._id ||= new mongoose.Types.ObjectId(); this.createdAt ||= new Date(); }
    async save() { const i = store.findIndex(d => String(d._id) === String(this._id)); if (i >= 0) store[i] = this; else store.push(this); return this; }
    markModified() {}
    static async create(doc) { const m = new M(doc); await m.save(); return m; }
    static findOne(q) { return chain(() => store.find(d => matches(d, q)) || null); }
    static findById(id) { return chain(() => store.find(d => String(d._id) === String(id)) || null); }
    static find(q) { return chain(c => { let r = store.filter(d => matches(d, q)); if (c._sort) r = r.sort((a, b) => String(a.dateKey).localeCompare(String(b.dateKey)) || a.createdAt - b.createdAt); return r.slice(0, c._limit || 1e9); }); }
    static async findOneAndDelete(q) { const i = store.findIndex(d => matches(d, q)); return i >= 0 ? store.splice(i, 1)[0] : null; }
    static async deleteMany(q) { for (let i = store.length - 1; i >= 0; i--) if (matches(store[i], q)) store.splice(i, 1); }
    static collection = { insertMany: async docs => { docs.forEach(d => store.push({ ...d })); } };
  }
  return M;
};

  return stores;
}
